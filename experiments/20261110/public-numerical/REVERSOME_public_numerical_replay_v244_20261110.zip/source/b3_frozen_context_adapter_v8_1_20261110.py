"""CPU-capable context-domain adapter; no test-label fitting or GPU quota bypass."""
from pathlib import Path
import importlib.util,json,pickle,hashlib,datetime,time,sys,os,random,collections
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,balanced_accuracy_score,confusion_matrix
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';P=E/'b3_context_verifier_v7_20261110';B=E/'b3_frozen_context_adapter_v8_1_20261110';BASE=E/'b3_musciclaims_nli_clause_v13_13_20261109/models/deberta-v3-base-mnli-fever-anli';H=E/'b3_healthver_locked_transport_v1_20261110';L=['SUPPORT','NOT_ENOUGH_INFO','CONTRADICT'];POL=['fixed2','fixed6','fixed_full','active','random_active']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def jl(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()]
def put(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2)
def write(p,x):
 with Path(p).open('x') as f:
  for r in x:f.write(json.dumps(r)+'\n')
def quality(y,h):
 n=sum(x=='SUPPORT' for x in h);bad=sum(a!='SUPPORT' and b=='SUPPORT' for a,b in zip(y,h));return {'accuracy':float(accuracy_score(y,h)),'BA':float(balanced_accuracy_score(y,h)),'FDR':bad/n if n else 1.,'retention':sum(a==b=='SUPPORT' for a,b in zip(y,h))/list(y).count('SUPPORT') if 'SUPPORT' in y else None,'support_n':n,'false_support_n':bad,'CM':confusion_matrix(y,h,labels=L).tolist()}
def setup():
 B.mkdir(exist_ok=False)
 for s in ['protocol','models','results']:(B/s).mkdir()
 proto={'schema':'REVERSOME.B3.FrozenContextAdapterProtocol.v8_1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'GPU DeBERTa upgrade is blocked by user GPU quota/queue. Verified CPU fallback freezes the original context encoder and fits a regularized source-domain adapter; no quota circumvention or test tuning.','encoder':'Pinned original MoritzDeBERTa CPUfloat32 eval; concatenate finalCLS768 and original NLI logits3. No foundation-weight updates.','decoder_selection':'Before test inference: compare native NLI head vs trained adapter using only full-source official dev BA; highest BA wins, native tie; freeze one global head for all policies and test cases.','adapter':'StandardScaler + balanced multinomial LogisticRegression C=.1,max_iter1500,seed20261110, fit5974 full-abstract training pairs only.','data_parent_input_freeze_sha256':sha(P/'protocol/input_freeze_v7.json'),'training_and_test_splits_unchanged':True,'calibration':'Official HealthVer dev940 pairs230 claims, select confidence threshold on2-sentence prefix versus full; safety/BA relative to dev-best fixed, no test labels.','thresholds':[.5,.6,.7,.8,.85,.9,.95,.98,1.01],'dominated_policy_rule':'If an active policy merely equals fixed quality but has >=fixed token-squared proxy cost, use the fixed fallback; never force an active route for branding.','fresh_transport':'CovidFact317 source pairs313 claims remains unscored by either V7 or V8 at this freeze. Report both candidates if run; no choice of winning model by transport-test scores.','real_execution':'Five physically independent CPU routes, NN calls/tokens and actual CPU/wall timings.','fallback_not_lower_acceptance':True,'code_sha256':sha(__file__),'encoder_sha256':sha(BASE/'model.safetensors'),'source_context_scope':'Provided-source NLI acquisition, not a full requirements/source-search planner or human judgment study.'};put(B/'protocol/protocol_v8_1.json',proto);print(json.dumps(proto,indent=2))
class Encoder:
 def __init__(self):
  import torch
  from transformers import AutoTokenizer,AutoModelForSequenceClassification
  from sklearn.feature_extraction.text import TfidfVectorizer
  self.torch=torch;torch.set_num_threads(int(os.environ.get('SLURM_CPUS_PER_TASK','16')));self.tok=AutoTokenizer.from_pretrained(str(BASE),local_files_only=True);self.model=AutoModelForSequenceClassification.from_pretrained(str(BASE),local_files_only=True).cpu().eval();assert self.model.config.id2label=={0:'entailment',1:'neutral',2:'contradiction'};self.vec=TfidfVectorizer(ngram_range=(1,2),stop_words='english',sublinear_tf=True,max_features=200000);docs=jl(H/'raw/corpus.jsonl');self.vec.fit([d.get('title','')+' '+' '.join(d['abstract']) for d in docs]);self.head=None;self.mode='adapted'
 def text(self,r,n=None,rnd=False):
  ss=r['sentences'];q=self.vec.transform([r['claim']]);sim=(self.vec.transform(ss)@q.T).toarray().ravel();order=sorted(range(len(ss)),key=lambda i:(-sim[i],i))
  if rnd:random.Random(int(hashlib.sha256((r['case_id']+'|20261110').encode()).hexdigest()[:12],16)).shuffle(order)
  chosen=sorted(order[:n] if n is not None else order);return ' '.join(ss[i] for i in chosen),chosen
 def embed(self,rows,n=None,rnd=False):
  texts=[];chosen=[]
  for r in rows:t,c=self.text(r,n,rnd);texts.append(t);chosen.append(c)
  x=self.tok(texts,[r['claim'] for r in rows],truncation=True,max_length=384,padding=True,return_tensors='pt');tokens=x['attention_mask'].sum(1).numpy().tolist()
  with self.torch.inference_mode():
   hidden=self.model.deberta(**x,return_dict=True).last_hidden_state;logits=self.model.classifier(self.model.pooler(hidden));f=self.torch.cat([hidden[:,0,:],logits],dim=1).numpy()
  return f,tokens,chosen
 def predict(self,r,n=None,rnd=False):
  f,tokens,idx=self.embed([r],n,rnd);p0=self.head.predict_proba(f)[0];pa=np.array([p0[list(self.head.classes_).index(k)] for k in L]);logits=f[0,-3:];pn=np.exp(logits-logits.max());pn=pn/pn.sum();p=pn if self.mode=='native' else pa
  return {'label':L[int(p.argmax())],'probabilities':p.tolist(),'tokens':tokens[0],'sentence_indices':idx[0],'base_logits':logits.tolist(),'adapted_label':L[int(pa.argmax())],'native_label':L[int(pn.argmax())],'decoder':self.mode}

def smoke():
 enc=Encoder();rows=jl(P/'inputs/train.jsonl')[:32];t=time.perf_counter();f,tokens,c=enc.embed(rows);out={'status':'PASS','n':len(rows),'feature_shape':list(f.shape),'finite':bool(np.isfinite(f).all()),'elapsed32_context_seconds':time.perf_counter()-t,'CPU_threads':enc.torch.get_num_threads(),'no_test_inputs_opened':True};assert out['finite'] and f.shape==(32,771);put(B/'results/smoke_v8_1.json',out);print(json.dumps(out,indent=2))
def fit():
 enc=Encoder();rows=jl(P/'inputs/train.jsonl');features=[];start=time.perf_counter()
 for i in range(0,len(rows),16):
  f,_,_=enc.embed(rows[i:i+16]);features.append(f)
  if (i//16+1)%50==0:print('FROZEN_ENCODER_TRAIN',i+len(f),len(rows),flush=True)
 X=np.vstack(features);np.save(B/'results/train_features_v8_1.npy',X);head=make_pipeline(StandardScaler(),LogisticRegression(C=.1,class_weight='balanced',max_iter=1500,random_state=20261110)).fit(X,[r['label'] for r in rows])
 with (B/'models/domain_adapter_v8_1.pkl').open('xb') as f:pickle.dump(head,f)
 put(B/'results/fit_receipt_v8_1.json',{'train_n':len(rows),'train_features_sha256':sha(B/'results/train_features_v8_1.npy'),'head_sha256':sha(B/'models/domain_adapter_v8_1.pkl'),'encoder_sha256':sha(BASE/'model.safetensors'),'elapsed_seconds':time.perf_counter()-start,'train_sha256':sha(P/'inputs/train.jsonl'),'test_labels_used':False,'code_sha256':sha(__file__),'frozen_encoder':True})
def calibration():
 enc=Encoder();enc.head=pickle.load((B/'models/domain_adapter_v8_1.pkl').open('rb'));rows=jl(P/'inputs/calibration.jsonl');by_decoder={d:{k:[] for k in ['fixed2','fixed6','fixed_full']} for d in ['adapted','native']}
 for key,n in [('fixed2',2),('fixed6',6),('fixed_full',None)]:
  for i in range(0,len(rows),16):
   batch=rows[i:i+16];X,tokens,indices=enc.embed(batch,n);pp=enc.head.predict_proba(X);pp=pp[:,[list(enc.head.classes_).index(k) for k in L]]
   for j,p in enumerate(pp):
    by_decoder['adapted'][key].append({'label':L[int(p.argmax())],'probabilities':p.tolist(),'tokens':tokens[j]});logits=X[j,-3:];p0=np.exp(logits-logits.max());p0=p0/p0.sum();by_decoder['native'][key].append({'label':L[int(p0.argmax())],'probabilities':p0.tolist(),'tokens':tokens[j]})
 y=[r['label'] for r in rows];decoder_metrics={d:quality(y,[s['label'] for s in states['fixed_full']]) for d,states in by_decoder.items()};decoder=max(['native','adapted'],key=lambda d:decoder_metrics[d]['BA']);allstates=by_decoder[decoder];out=[{'case_id':r['case_id'],'label':r['label'],'states':{k:allstates[k][i] for k in allstates}} for i,r in enumerate(rows)];write(B/'results/calibration_predictions_v8_1.jsonl',out);fixed={k:quality(y,[x['label'] for x in states]) for k,states in allstates.items()};strong=max(fixed,key=lambda k:(fixed[k]['BA'],-['fixed2','fixed6','fixed_full'].index(k)));base=fixed[strong];basecost=sum(x['tokens']**2 for x in allstates[strong]);options=[]
 for t in json.load((B/'protocol/protocol_v8_1.json').open())['thresholds']:
  selected=[a if max(a['probabilities'])>=t else z for a,z in zip(allstates['fixed2'],allstates['fixed_full'])];q=quality(y,[x['label'] for x in selected]);q.update(threshold=t,proxy=sum(a['tokens']**2+(0 if max(a['probabilities'])>=t else z['tokens']**2) for a,z in zip(allstates['fixed2'],allstates['fixed_full'])),feasible=q['BA']>=base['BA']-1e-12 and q['FDR']<=base['FDR']+1e-12 and q['retention']>=base['retention']-1e-12);options.append(q)
 feasible=[q for q in options if q['feasible']];best=max(feasible,key=lambda q:(q['BA'],-q['proxy'])) if feasible else None
 if best and best['BA']<=base['BA']+1e-12 and best['proxy']>=basecost:best=None
 put(B/'results/policy_freeze_v8_1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixed':fixed,'strong_fixed':strong,'decoder':decoder,'decoder_full_dev_metrics':decoder_metrics,'decoder_rule':'Highest full-source dev BA, tie native; no test-label choice','candidates':options,'selected':best,'fallback':best is None,'head_sha256':sha(B/'models/domain_adapter_v8_1.pkl'),'code_sha256':sha(__file__),'no_test_selection':True});print(json.dumps({'fixed':fixed,'selected':best,'strong_fixed':strong},indent=2))
def live():
 rec=json.load((B/'results/policy_freeze_v8_1.json').open());assert rec['code_sha256']==sha(__file__) and rec['head_sha256']==sha(B/'models/domain_adapter_v8_1.pkl');enc=Encoder();enc.head=pickle.load((B/'models/domain_adapter_v8_1.pkl').open('rb'));enc.mode=rec['decoder']
 for name in ['healthver_test','covidfact_test']:
  rows=jl(P/'inputs'/f'{name}_label_free.jsonl');out=[]
  for i,r in enumerate(rows):
   routes={};order=POL[i%5:]+POL[:i%5]
   for policy in order:
    t=time.perf_counter();ct=time.process_time()
    if policy.startswith('fixed') or rec['fallback']:
     k=policy if policy.startswith('fixed') else rec['strong_fixed'];trace=[enc.predict(r,2 if k=='fixed2' else 6 if k=='fixed6' else None)]
    else:
     first=enc.predict(r,2,policy=='random_active');trace=[first]
     if max(first['probabilities'])<rec['selected']['threshold']:trace.append(enc.predict(r))
    routes[policy]={'label':trace[-1]['label'],'wall_seconds':time.perf_counter()-t,'CPU_seconds':time.process_time()-ct,'neural_calls':len(trace),'tokens':sum(x['tokens'] for x in trace),'trace':trace}
   out.append({'case_id':r['case_id'],'claim_group':r['claim_group'],'doc_id':r['doc_id'],'execution_order':order,'routes':routes})
   if (i+1)%100==0:print('FROZEN_CONTEXT_TEST',name,i+1,len(rows),flush=True)
  p=B/'results'/f'{name}_predictions_v8_1.jsonl';write(p,out);put(B/'results'/f'{name}_prediction_freeze_v8_1.json',{'prediction_sha256':sha(p),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'test_keys_opened':False})
def score():
 for name in ['healthver_test','covidfact_test']:
  p=B/'results'/f'{name}_predictions_v8_1.jsonl';assert sha(p)==json.load((B/'results'/f'{name}_prediction_freeze_v8_1.json').open())['prediction_sha256'];rows=jl(p);keys={r['case_id']:r for r in jl(P/'keys'/f'{name}.jsonl')};y=[keys[r['case_id']]['label'] for r in rows];metrics={};checks={'all_test_pairs':len(rows)==len(keys),'unique_case_ids':len(rows)==len({r['case_id'] for r in rows})}
  for policy in POL:
   m=quality(y,[r['routes'][policy]['label'] for r in rows]);m.update({k:sum(r['routes'][policy][k] for r in rows) for k in ['wall_seconds','CPU_seconds','tokens','neural_calls']});metrics[policy]=m;checks[policy+'_trace']=all(all(L[int(np.argmax(x['probabilities']))]==x['label'] for x in r['routes'][policy]['trace']) and r['routes'][policy]['label']==r['routes'][policy]['trace'][-1]['label'] for r in rows)
  zero=quality(y,[L[int(np.argmax(r['routes']['fixed_full']['trace'][-1]['base_logits']))] for r in rows]);groups={}
  for i,r in enumerate(rows):groups.setdefault(r['claim_group'],[]).append(i)
  names=list(groups);mat=np.array([[np.mean([rows[i]['routes'][pol]['label']==y[i] for i in groups[g]]) for pol in POL] for g in names]);rng=np.random.default_rng(20261110);boot=np.array([mat[rng.integers(0,len(names),len(names))].mean(0) for _ in range(2000)]);a=POL.index('active');out={'schema':'REVERSOME.B3.FrozenContextEvaluation.v8_1','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'dataset':name,'source_pairs':len(rows),'natural_claims':len(names),'metrics':metrics,'pretrained_zero_shot_full_replay':zero,'zero_shot_cost_scope':'Decision-only same-encoder replay; not separately timed.','equal_claim_accuracy':dict(zip(POL,map(float,mat.mean(0)))),'paired_claim_accuracy_difference95CI':{p:np.quantile(boot[:,a]-boot[:,j],[.025,.975]).tolist() for j,p in enumerate(POL) if p!='active'},'prediction_sha256':sha(p),'scope':'Published source-bound labels, CPU real context verification; public-dev model design and frozen external transport. Statistical group unit is claim conditional on fixed sources, not human-researcher benefit.'};put(B/'results'/f'{name}_score_v8_1.json',out);print(json.dumps(out,indent=2));assert all(checks.values())
if __name__=='__main__':{'setup':setup,'smoke':smoke,'fit':fit,'calibration':calibration,'live':live,'score':score}[sys.argv[1]]()
