import json,hashlib,re,datetime,csv
from pathlib import Path
import h5py
B=Path(__file__).resolve().parents[1]; P=B/'protocol/frozen_protocol_v1.json'; A=B/'protocol/addenda/analysis_parameters_v1.json'; D=B/'results/download_receipt_v1.json'; M=B/'model_payload'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads(P.read_text());a=json.loads(A.read_text());d=json.loads(D.read_text());man=json.loads((M/'manifest_v1.json').read_text()); ph=sha(P)
assert ph==a['parent_protocol_sha256']==d['protocol_sha256']; assert sha(M/'manifest_v1.json')==p['model']['manifest_sha256']; assert man['files']==p['model']['payload_file_sha256']
for n,h in man['files'].items(): assert sha(M/n)==h
fs=list(csv.DictReader((M/'frozen_model_features_v1.tsv').open(),delimiter='\t')); genes={r['feature'] for r in fs if r['modality']=='RNA'}; bins={r['feature'] for r in fs if r['modality']=='ATAC_10kb'}; assert len(genes)==len(bins)==64
by={x['name']:x for x in d['files']}; out=[]
for e in p['source']['files']:
 f=B/'data'/e['filename']; z=by[e['filename']]; assert f.stat().st_size==z['bytes'] and sha(f)==z['sha256']
 with h5py.File(f,'r') as h:
  g=h['matrix']; shape=tuple(map(int,g['shape'][:])); bars=[x.decode() for x in g['barcodes'][:]]; names=[x.decode() for x in g['features/name'][:]]; types=[x.decode() for x in g['features/feature_type'][:]]; iv=[x.decode() for x in g['features/interval'][:]]
  assert shape==(len(names),len(bars)) and len(set(bars))==len(bars) and len(names)==len(types)==len(iv) and len(bars)>=50
  assert g['data'].dtype.kind in 'iu' and g['indices'].dtype.kind in 'iu' and g['indptr'].dtype.kind in 'iu'
  ge=[n for n,t in zip(names,types) if t=='Gene Expression']; from collections import Counter; gc=Counter(ge); assert all(gc.get(x,0)==1 for x in genes)
  cov=set()
  for s,t in zip(iv,types):
   m=re.match(r'^(.+):([0-9]+)-([0-9]+)$',s)
   if t=='Peaks' and m:cov.add(f'{m.group(1)}-{int(m.group(2))//10000*10000}')
  assert bins<=cov
  out.append({'sample_label':e['sample_label'],'filename':f.name,'bytes':f.stat().st_size,'sha256':z['sha256'],'shape':list(shape),'n_cells':len(bars),'n_gene_features':len(ge),'n_peak_features':sum(t=='Peaks' for t in types),'exact_frozen_genes':64,'frozen_bins_covered':64,'count_values_read':False})
assert len(out)==4
r={'schema':'REVERSOME.GSE281482.StructuralPreflight.v1','protocol_sha256':ph,'status':'PASS_STRUCTURAL_PREFLIGHT','groups':out,'count_values_scanned':False,'cell_level_scores_created':False,'clinical_covariates_read':False,'hospital_expert_or_clinical_records_accessed':False,'manuscript_or_rebuttal_changed':False,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
o=B/'results/object_preflight_v1.json';o.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(r['status'],[x['n_cells'] for x in out],sha(o))
