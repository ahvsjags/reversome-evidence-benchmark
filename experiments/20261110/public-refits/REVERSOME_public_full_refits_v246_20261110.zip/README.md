# Public GSE241468 full-refit reproduction

Input: https://ftp.ncbi.nlm.nih.gov/geo/series/GSE241nnn/GSE241468/suppl/GSE241468_share_seur.rds
The revised public RDS was deposited21February2025. Verify the complete file
SHA25698c542ab238a9df25b0e98f568bacb392276f8a5b5fa385541e5e53e2e680fac.
The file is about20GB. Already downloaded public input can be reused after hashing.

Runtime used for the archived reference: R4.3.0, Matrix, SeuratObject, jsonlite;
single-thread BLAS. Install those packages in a normal R library and record versions.
Python numerical verification requires NumPy and SciPy. Raw input and dependency
rights remain with their original distributors; no hospital files are required.

Run `REV_REPEATS=20 Rscript --vanilla reproduce_refits.R PUBLIC_RDS NEW_OUTPUT golden`.
Then run `python verify_public_refits.py NEW_OUTPUT .`.
The script independently refits feature selection, scaling, PCA and ridge on each
of20 complementary8/8 released-unit splits, with5 pairing seeds per split.
It writes complete per-cell vectors and all20 fitted model artifacts. The first2
splits are checked against public frozen model coefficients to1e-10 predictions
and1e-12 scalers. External verification checks all800 unit/seed rows, complete
per-cell summaries and the corrected repeated-holdout statistic.

Units:16 released assays/specimen pools. Published source methods include tissue
pooling. They are not16 established independent individual donors. Historical
checkpoint field names containing `donor` are compatibility aliases only.
The repeated8/8 sensitivity analysis does not replace the original primary15/1
design. Do not reinterpret repeat counts as independent subjects or studies.
