"""Independent numerical replay of public live-inference vectors; no model calls."""
from pathlib import Path
import argparse,json,hashlib,itertools
import numpy as np
A=argparse.ArgumentParser();A.add_argument('--bundle-dir',required=True);A.add_argument('--output-dir',required=True);a=A.parse_args();B=Path(a.bundle_dir);D=Path(a.output_dir);D.mkdir(exist_ok=False);manifest=json.load((B/'manifest.json').open());checks={'all_manifest_hashes':all(hashlib.sha256((B/k).read_bytes()).hexdigest()==h for k,h in manifest['files'].items())};assert checks['all_manifest_hashes'];source=json.load((B/'primary_reference.json').open());stability=json.load((B/'stability_reference.json').open());rows=[json.loads(x) for x in (B/'predictions.jsonl').open()];gold=json.load((B/'gold_evidence.json').open());sel=json.load((B/'selection_protocol.json').open());order=[json.loads(x)['case_id'] for x in (B/'primary_claim_ids.jsonl').open()];primary={r['case_id']:r for r in rows if r['seed']==20261111};checks['96primary_unique160runs']=len(primary)==96 and len(rows)==160;P=['fixed3','source_active','qwen_react_same_tools'];V=['shared_NLI','fresh_Qwen_only','Qwen_NLI_source_consensus'];L=['SUPPORT','CONTRADICT','NOT_ENOUGH_INFO'];vec={};maxerr=0.
def aggregate(labels):
 s=set(labels)-{L[-1]};return next(iter(s)) if len(s)==1 else L[-1]
def nli(xs):
 z=np.array([[x['prob_support'],x['prob_neutral'],x['prob_contradict']] for x in xs],float).reshape(-1,3);s=np.any((z[:,0]>=.7)&(z[:,0]-z[:,1]>=.2)&(z[:,0]-z[:,2]>=.1));c=np.any((z[:,2]>=.7)&(z[:,2]-z[:,1]>=.2)&(z[:,2]-z[:,0]>=.1));return L[-1] if s==c else L[0] if s else L[1]
for r in rows:
 for p,z in r['routes'].items():
  nn={d:nli([x for x in z['scored_candidates'] if x['doc_id']==d]) for d in z['read_document_ids']};ll=z['verifier_source_labels']['fresh_Qwen_only'];cc={d:nn[d] if nn[d]==ll[d] else L[-1] for d in nn};checks[str(r['seed'])+'_'+r['case_id']+'_'+p+'_NLI_consensus_and_global']=nn==z['verifier_source_labels']['shared_NLI'] and cc==z['verifier_source_labels']['Qwen_NLI_source_consensus'] and all(aggregate(z['verifier_source_labels'][v].values())==z['verifier_global_decisions'][v] for v in V)
for p,v in itertools.product(P,V):
 x=[]
 for cid in order:
  r=primary[cid];z=r['routes'][p];g=gold[cid];labs={a['label'] for a in g.values()};truth=next(iter(labs)) if len(labs)==1 else L[-1];pred={d:k for d,k in z['verifier_source_labels'][v].items() if k!=L[-1]};t=sum(d in g and g[d]['label']==k for d,k in pred.items());label=z['verifier_global_decisions'][v];x.append([t,len(pred),len(g),int(label==truth),int(label=='SUPPORT' and truth!='SUPPORT'),int(label=='SUPPORT'),int(label==truth=='SUPPORT'),int(truth=='SUPPORT'),int(z['inference_failure'])])
 vec[p,v]=np.array(x);a=vec[p,v].sum(0);old=source['metrics'][p][v];computed={'ECAP_TP':int(a[0]),'predicted_ECAPs':int(a[1]),'gold_ECAPs':int(a[2]),'ECAP_F1':2*a[0]/(a[1]+a[2]),'claim_accuracy':a[3]/96,'support_release_error_count_under_strict_benchmark_label':int(a[4]),'support_release_count':int(a[5]),'valid_support_retention':a[6]/a[7],'inference_failure_claims':int(a[8])}
 for k,value in computed.items():e=abs(float(value)-float(old[k]));maxerr=max(maxerr,e);checks[p+'_'+v+'_'+k]=e<1e-12
ix=np.random.default_rng(20261111).integers(0,96,size=(5000,96))
for p,q in [('source_active','fixed3'),('source_active','qwen_react_same_tools'),('qwen_react_same_tools','fixed3')]:
 for v in V:
  aa=vec[p,v][ix].sum(1);bb=vec[q,v][ix].sum(1);f=2*aa[:,0]/np.maximum(aa[:,1]+aa[:,2],1)-2*bb[:,0]/np.maximum(bb[:,1]+bb[:,2],1);acc=(vec[p,v][:,3]-vec[q,v][:,3])[ix].mean(1);old=source['paired_comparisons'][p+' minus '+q+' | '+v];checks[p+'_'+q+'_'+v+'_paired5000bootstrap']=np.allclose(np.quantile(f,[.025,.975]),old['component_bootstrap95CI'],rtol=0,atol=1e-12) and np.allclose(np.quantile(acc,[.025,.975]),old['claim_accuracy_difference95CI'],rtol=0,atol=1e-12)
by={(r['seed'],r['case_id']):r for r in rows};ids=sel['sampling']['stability_claims']
for p,v in itertools.product(P,V):
 count=sum(len({by[s,c]['routes'][p]['verifier_global_decisions'][v] for s in [20261111,20261129,20261207]})==1 for c in ids);checks[p+'_'+v+'_32case_three_seed_stability']=count==stability['decision_stability'][p+' | '+v]['unanimous_cases']
out={'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'max_metric_difference':maxerr,'primary_claims':96,'actual_case_runs_in_reference':160,'scope':'Public prediction-vector and statistical replay only. Does not execute Qwen, NLI, retrieval or a new benchmark. Full trace binding/token-prefix checks are separately archived proofs; exact fine-tuned NLI checkpoint not included in this numerical release.'};(D/'reproduction_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2));assert out['status']=='PASS'
