"""Acquire an untouched official test collection after freezing the V6 policy."""
from pathlib import Path
import json,hashlib,datetime,urllib.request,tarfile,shutil
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';B=E/'b3_scifact_open_locked_v1_20261110';V=E/'b3_incremental_sourceguard_v6_20261110';P=E/'b3_sourceheldout_utility_v3_20261110'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def put(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2)
def jl(p):return [json.loads(s) for s in p.open() if s.strip()]
B.mkdir(exist_ok=False)
for n in ['protocol','source','inputs','keys','results']:(B/n).mkdir()
url='https://scifact.s3.us-west-2.amazonaws.com/scifact-open/latest/scifact_open.tar.gz'
put(B/'protocol/protocol_v1.json',{'schema':'REVERSOME.B3.SciFactOpenLockedTransport.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_url':url,'source_documentation':'https://github.com/dwadden/scifact-open/blob/main/doc/data.md','models_frozen':{'source_model':sha(V/'models_v6.pkl'),'NLI':sha(P/'models/scifact_finetuned_v1/model.safetensors')},'policy':'Unchanged V6 initial depth, source threshold, NLI guard; acquire only source-aligned new documents, stop on resolved relation. No fitting or threshold selection on SciFact-Open.','retrieval':'Full500K official corpus. Preserve original5183-corpus fitted word and character TFIDF transforms; apply frozen transforms to new corpus. Top20 word retrieval, same top2 sentences per document. Character/source features computed only for retrieved documents.','comparators':['fixed1','fixed3','fixed20','source_fixed_all','source_active'],'endpoints':['Official abstract-level evidence-label precision/recall/F1 (published pooling annotations are not exhaustive).','First released source certificate: at least one selected source is gold annotated with the released relation; unannotated sources are unverified, not scientifically proved false.','Claim-level strict release: SUPPORT only if gold SUPPORT exists and no gold CONTRADICT; CONTRADICT symmetric; mixed cases require withholding. This is a conservative scoped secondary endpoint.'],'cost':'Actual independent wall/CPU/neural-pair counts per arm; count feature/retrieval cost explicitly. No oracle lookahead.','overlap':'Before inference remove and disclose exact normalized claim matches to any prior SciFact fit/calibration/exposed dev claim; retain separate counts. Source corpus may overlap older unlabelled corpus.','uncertainty':'Claim bootstrap conditional on fixed corpus, with source-sharing component bootstrap sensitivity. Not independent studies or human-researcher outcomes.','success_not_assumed':True,'no_test_tuning':True})
a=B/'source/scifact_open.tar.gz'
with urllib.request.urlopen(url,timeout=180) as f,a.open('xb') as out:shutil.copyfileobj(f,out)
chosen=[]
with tarfile.open(a,'r:gz') as t:
 for member in t:
  n=Path(member.name).name
  if member.isfile() and n in ['claims.jsonl','claims_metadata.jsonl','corpus.jsonl','corpus_candidates.jsonl'] and '/data/' in '/'+member.name:
   dest=B/'source'/n
   if dest.exists():raise RuntimeError('Ambiguous archive member '+member.name)
   with t.extractfile(member) as f,dest.open('xb') as out:shutil.copyfileobj(f,out)
   chosen.append({'member':member.name,'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size})
assert (B/'source/claims.jsonl').exists() and (B/'source/corpus.jsonl').exists()
norm=lambda s:' '.join(s.lower().split());seen=set()
for f in ['inputs/claims_train.jsonl','inputs/calibration_claims_label_free.jsonl','inputs/label_free_claims_v1.jsonl']:
 seen|={norm(r['claim']) for r in jl(P/f)}
claims=jl(B/'source/claims.jsonl');keep=[r for r in claims if norm(r['claim']) not in seen];removed=[r['id'] for r in claims if norm(r['claim']) in seen]
for p,rows in [(B/'inputs/claims_label_free.jsonl',[{'case_id':str(r['id']),'claim':r['claim']} for r in keep]),(B/'keys/claims_key.jsonl',keep)]:
 with p.open('x') as f:
  for row in rows:f.write(json.dumps(row)+'\n')
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'members':chosen,'total_official_claims':len(claims),'new_exact_disjoint_claims':len(keep),'removed_previously_exposed_claim_ids':removed,'label_free_claims_sha256':sha(B/'inputs/claims_label_free.jsonl'),'key_sha256':sha(B/'keys/claims_key.jsonl'),'no_policy_or_model_updates':True}
put(B/'protocol/input_freeze_v1.json',receipt);print(json.dumps(receipt,indent=2),flush=True)
