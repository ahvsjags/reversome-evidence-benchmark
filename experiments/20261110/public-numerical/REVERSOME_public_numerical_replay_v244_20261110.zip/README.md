# REVERSOME public numerical replay snapshot — 2026-11-10

This snapshot contains public-benchmark decision vectors and measured costs,
two compact model artifacts, the archived scientific runners, and all800
released-unit repeated-refit results. It includes no hospital data, individual
expert records, manuscript, reviewer correspondence or unpublished author files.

## Quick numerical replay
Create a fresh Python environment, install `requirements-numerical.txt`, then run
`python verify_public_numerical_evidence.py .`.
The verifier reconstructs confusion matrices, support error fractions/retention,
cost sums and corrected20-split statistics from the complete released vectors.
It also verifies every bundled checksum. This does not rerun a neural model.

## Model/source provenance and inference scope
The context adapter is a StandardScaler + balanced logistic head over771 frozen
DeBERTa features. The base encoder is publicly hosted at
https://huggingface.co/MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli,
revision6f5cf0a2b59cabb106aca4c287eed12e357e90eb,
model SHA25606d6fd89edd4f97816831626daafbdb0b029cf63bae8edc0bccab1d64e2e7707.
The compact source-alignment artifact was fit only to603 SciFact training claims;
the preserved artifact includes its original source threshold and initial depth.
Load trusted pickle files only after checking the bundled hashes. Archived source
runners retain their original IBEX paths and input provenance; they are not
advertised as an already portable, one-command end-to-end neural training release.
Original benchmark inputs must be obtained from their linked official sources,
subject to their original licenses. No new rights to third-party data are asserted.

## Interpret results correctly
HealthVer903 source pairs correspond to230 claims; CovidFact317 source pairs to313
benchmark claims. They are not1220 independent studies or researcher judgments.
Fixed-full fallback is explicitly retained when active policies fail dev criteria.
Do not relabel matching fallback performance as active-policy improvement.
The20 biological refits operate on16 released assay/specimen-pool units, not16
established independent donors, and do not replace the original primary design.
Earlier failed development routes and their audits remain in the server evidence
history; this numerical snapshot does not claim all reviewer requests are closed,
complete95-artifact reproduction, or a repository DOI.
