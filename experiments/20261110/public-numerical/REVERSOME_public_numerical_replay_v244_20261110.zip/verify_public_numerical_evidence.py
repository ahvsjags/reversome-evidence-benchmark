"""Portable numerical replay. Usage: python verify_public_numerical_evidence.py BUNDLE_DIR."""
from pathlib import Path
import csv,json,hashlib,sys,math
import numpy as np
from scipy.stats import t
B=Path(sys.argv[1]);manifest=json.loads((B/'MANIFEST.json').read_text());checks={};results={}
for r in manifest['files']:
 p=B/r['path'];checks['hash:'+r['path']]=p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
for f in sorted((B/'tables').glob('*_predictions.csv')):
 rows=list(csv.DictReader(f.open()));truth={r['case_id']:r['truth'] for r in rows};policies=sorted({r['policy'] for r in rows});stats={};labels=['SUPPORT','NOT_ENOUGH_INFO','CONTRADICT'];case_ids=set(truth)
 for pol in policies:
  rr=[r for r in rows if r['policy']==pol];checks[f.stem+':'+pol+':cases']=len(rr)==len(case_ids)==len({r['case_id'] for r in rr});cm=np.zeros((3,3),int)
  for r in rr:cm[labels.index(r['truth']),labels.index(r['prediction'])]+=1
  active=cm.sum(1)>0;n=int(cm[:,0].sum());stats[pol]={'accuracy':float(cm.trace()/cm.sum()),'BA':float(np.mean(cm.diagonal()[active]/cm.sum(1)[active])),'FDR':float((n-cm[0,0])/n) if n else 1.,'retention':float(cm[0,0]/cm[0].sum()) if cm[0].sum() else None,'support_n':n,'false_support_n':int(n-cm[0,0]),'CM':cm.tolist()}
  for k in ['wall_seconds','CPU_seconds','neural_items','tokens']:
   if k in rr[0]:stats[pol][k]=sum(float(r[k]) for r in rr)
 expected=json.loads((B/'expected'/f'{f.stem}.json').read_text())
 for pol in stats:
  for k,v in expected[pol].items():
   if k not in stats[pol]:continue
   z=stats[pol][k];checks[f.stem+':'+pol+':'+k]=z==v if isinstance(v,(list,int)) or v is None else math.isclose(z,v,abs_tol=1e-9)
 results[f.stem]=stats
p=B/'tables/gse241468_20_refits.csv'
if p.exists():
 rows=list(csv.DictReader(p.open()));splits={}
 for row in rows:splits.setdefault(row['split'],[]).append(float(row['delta']))
 x=np.array([np.mean(v) for v in splits.values()]);mu=float(x.mean());se=float(np.sqrt((1/20+1)*np.var(x,ddof=1)));ci=[mu-t.ppf(.975,19)*se,mu+t.ppf(.975,19)*se];pv=float(2*t.sf(abs(mu/se),19));expected=json.loads((B/'expected/gse241468_20_refits.json').read_text());checks.update(refit_rows800=len(rows)==800,refit_splits20=len(splits)==20,refit_mean=math.isclose(mu,expected['mean_delta'],abs_tol=1e-12),refit_CI=bool(np.allclose(ci,expected['CI'],atol=1e-12,rtol=0)),refit_p=math.isclose(pv,expected['p'],abs_tol=1e-12));results['gse241468_20_refits']={'mean_delta':mu,'CI':ci,'p':pv,'unit':'Released assay/specimen-pool units; not16 established independent donors.'}
out={'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v],'results':results,'scope':'Checks arithmetic and released vectors, not independent labels, neural rerun or human judgment.'};print(json.dumps(out,indent=2));(B/'numerical_replay_receipt.json').write_text(json.dumps(out,indent=2));assert all(checks.values())
