import json,os,subprocess,sys
from pathlib import Path
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'software/site'))
from reversome.specs.contract_guard import canonical_sha256
m=json.loads((B/'decision/source_manifest_v1.json').read_text())
h=canonical_sha256(m)
env=os.environ.copy();env['PYTHONPATH']=str(B/'software/site')
cmd=[sys.executable,'-m','reversome.specs.cli','--contract',str(B/'decision/claim_contract_v1.json'),'--source-manifest',str(B/'decision/source_manifest_v1.json'),'--expected-source-manifest-sha256',h,'--profile',str(B/'protocol/reversome_v9_spec_integrity_profile.json'),'--output',str(B/'decision/contract_audit_v1.json'),'--overwrite']
r=subprocess.run(cmd,env=env,capture_output=True,text=True)
(B/'results/contract_audit_cli.log').write_text(r.stdout+'\n'+r.stderr)
print('EXIT',r.returncode,'CANONICAL_MANIFEST_SHA',h)
print((B/'decision/contract_audit_v1.json').read_text())
sys.exit(0 if r.returncode==0 else 1)
