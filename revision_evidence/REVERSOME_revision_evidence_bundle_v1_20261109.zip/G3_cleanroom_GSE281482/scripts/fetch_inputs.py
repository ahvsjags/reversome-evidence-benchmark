#!/usr/bin/env python3
import hashlib,json,urllib.request,sys
from pathlib import Path
B=Path(__file__).resolve().parents[1]
manifest=json.loads((B/'protocol/download_receipt_v1.json').read_text())
(B/'data').mkdir(exist_ok=True)
rows=[]
for item in manifest['files']:
    p=B/'data'/item['name']
    def digest(path):
        h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(1<<20),b''):h.update(block)
        return h.hexdigest()
    if not p.exists() or p.stat().st_size!=item['bytes'] or digest(p)!=item['sha256']:
        tmp=p.with_suffix(p.suffix+'.part')
        if tmp.exists(): tmp.unlink()
        urllib.request.urlretrieve(item['url'],tmp)
        if tmp.stat().st_size!=item['bytes'] or digest(tmp)!=item['sha256']:
            tmp.unlink(missing_ok=True); raise SystemExit('SOURCE_HASH_MISMATCH:'+item['name'])
        tmp.replace(p)
    rows.append({'name':item['name'],'bytes':p.stat().st_size,'sha256':digest(p),'url':item['url']})
out={'schema':'REVERSOME.GSE281482.ReplayDownloadReceipt.v1','source':'official NCBI GEO FTP','files':rows,'status':'PASS'}
q=B/'results/download_receipt_replay_v1.json'; q.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('FETCH_HASH_VERIFY_PASS',len(rows))
