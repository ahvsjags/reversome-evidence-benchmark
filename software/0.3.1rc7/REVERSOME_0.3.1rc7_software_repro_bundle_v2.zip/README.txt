REVERSOME 0.3.1rc7 software reproducibility bundle

This bundle contains the data-free source archive, built wheel, pinned Python 3.9.18 test/build dependency closure, and clean source/wheel test and CLI smoke evidence. All 408 tests passed from the clean source extraction and from the separately installed wheel; the installed-wheel pytest startup hook confirms the wheel import path.

Scope: software package reproducibility only. This is not complete manuscript figure/table regeneration, public repository deposit, or reproduction of hospital/clinical analyses.

Integrity: see BUNDLE_MANIFEST.json and SHA256SUMS.

Reproduction entry point: run ./reproduce.sh from this extracted directory. It verifies bundle hashes, creates two clean Python 3.9.18 environments from lock v2 (including the SciPy MILP solver), and reruns the source and installed-wheel test suites.
