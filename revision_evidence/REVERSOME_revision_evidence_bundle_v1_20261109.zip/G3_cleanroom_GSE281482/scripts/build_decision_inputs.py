#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
B=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
prot='protocol/frozen_protocol_v1.json'; res='results/primary_analysis_v1.json'; pre='verification/preflight_independent_verification_v1.json'; ver='verification/independent_recompute_v1.json'
manifest={x:sha(B/x) for x in [prot,res,pre,ver,'model_payload/manifest_v1.json']}; manifest[prot+'#frozen_analysis_and_boundaries']=sha(B/prot); manifest[res+'#observed_execution_summary']=sha(B/res)
(B/'decision/source_manifest_v1.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
values={
'source':'GSE281482',
'independent_unit':'four source matrix groups; donor independence not assumed',
'split':'GSE241468 frozen model; GSE281482 external test source; no refit',
'comparator':'100 within-matrix target permutations per sample',
'metric':'mean native paired cosine minus mean shuffled-target cosine per source matrix',
'uncertainty':'descriptive resampling interval over four matrices; no inferential p-value',
'scope':'four public BAL mesenchymal-cell multiome matrices; source-domain-shift stress test only',
'falsifier':'the all-four-matrices claim is falsified if any matrix effect is less than or equal to zero'}
req=[]
for category,value in values.items():
 req.append({'requirement_id':'REQ_'+category.upper(),'category':category,'statement':'Predeclared structural and reporting condition for the retrospective public case packet.','value':value,'provenance':{'reference':prot+'#frozen_analysis_and_boundaries','sha256':sha(B/prot)}})
facts=[]
for category in ['independent_unit','split','comparator','metric','uncertainty','scope']:
 facts.append({'category':category,'value':values[category],'provenance':{'reference':res+'#observed_execution_summary','sha256':sha(B/res)}})
contract={'schema':'REVERSOME.PublicCase.ClaimContract.v1','case_id':'GSE281482_PUBLIC_RETROSPECTIVE_CASE_V1','claim_type':'predictive','claim_text':'The unchanged GSE241468-trained mapping shows above-shuffled same-cell RNA-to-ATAC latent correspondence in all four GSE281482 source matrices.','requirements':req,'design_facts':facts,'authorship_and_timing':'Analyst-specified retrospective worked-example contract after public-source evaluation; not independent expert adjudication or prospective preregistration.'}
(B/'decision/claim_contract_v1.json').write_text(json.dumps(contract,indent=2,sort_keys=True)+'\n')
result=json.loads((B/res).read_text()); preflight=json.loads((B/'results/object_preflight_v1.json').read_text()); iv=json.loads((B/ver).read_text()); s=result['summary']
observations={'R_SOURCE_PROVENANCE':'PASS' if json.loads((B/pre).read_text())['status']=='PASS' else 'FAIL','R_FROZEN_EXTERNAL_MODEL':'PASS' if result['model_refit'] is False and result['external_feature_selection'] is False and result['external_scaling_fit'] is False else 'FAIL','R_PAIRED_MODALITY_AND_BARCODE_PREFLIGHT':'PASS' if preflight['status']=='PASS_STRUCTURAL_PREFLIGHT' else 'FAIL','R_SHUFFLE_CONTROL_AND_RECOMPUTATION':'PASS' if iv['status']=='PASS' and iv['checks_passed']==iv['checks_total'] else 'FAIL','R_ALL_FOUR_SOURCE_MATRICES_POSITIVE':'PASS' if s['positive_matrix_count']==s['n_source_matrices'] else 'FAIL','R_DESCRIPTIVE_INTERVAL_EXCLUDES_ZERO':'PASS' if s['descriptive_sample_resampling_95_percentile_interval'][0]>0 else 'FAIL'}
request={'protocol_id':'REVERSOME-V8-MILP-RESIDUAL-COVER','protocol_sha256':sha(B/'protocol/reversome_v8_milp_residual_cover.yaml'),'requirements':list(observations),'observations':observations,'actions':[],'budget':0}
(B/'decision/planner_request_v1.json').write_text(json.dumps(request,indent=2,sort_keys=True)+'\n')
record={'schema':'REVERSOME.GSE281482.PublicEndToEndCase.v1','case_id':contract['case_id'],'claim_contract':'decision/claim_contract_v1.json','source_manifest':'decision/source_manifest_v1.json','planner_request':'decision/planner_request_v1.json','claim_text':contract['claim_text'],'observations':observations,'observed_summary':s,'independent_recompute_status':iv['status'],'independent_recompute_checks':[iv['checks_passed'],iv['checks_total']],'timing_and_scope':contract['authorship_and_timing'],'no_hospital_expert_or_clinical_records_accessed':True,'no_manuscript_or_rebuttal_changed':True}
(B/'decision/case_record_v1.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('CASE_INPUTS_BUILT',len(req),'requirements',len(facts),'cross-source facts',sum(x=='FAIL' for x in observations.values()),'failed decision predicates')
