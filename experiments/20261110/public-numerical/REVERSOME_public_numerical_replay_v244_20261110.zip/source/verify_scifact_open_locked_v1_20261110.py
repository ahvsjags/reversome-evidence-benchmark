"""Independent numerical/action verification of both frozen Open candidates."""
from pathlib import Path
import json,hashlib,datetime,sys,pickle,math
import numpy as np
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';O=E/'b3_scifact_open_locked_v1_20261110';C=E/'b3_source_context_v10_20261110';V=E/'b3_incremental_sourceguard_v6_20261110';L=['SUPPORT','NOT_ENOUGH_INFO','CONTRADICT'];POL=['fixed1','fixed3','fixed20','source_fixed_all','source_active'];mode=sys.argv[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:[json.loads(s) for s in Path(p).open() if s.strip()]
def assign(doc,t=.7,margin=.2):
 if mode=='v6':
  s=any(z['prob_support']>=.7 and z['prob_support']-z['prob_neutral']>=.2 and z['prob_support']-z['prob_contradict']>=.1 for z in doc);c=any(z['prob_contradict']>=.7 and z['prob_contradict']-z['prob_neutral']>=.2 and z['prob_contradict']-z['prob_support']>=.1 for z in doc)
 else:
  labels=[]
  for z in doc:
   p=z['probabilities'];k=int(np.argmax(p));labels.append(L[k] if k!=1 and p[k]>=t and p[k]-max(p[j] for j in range(3) if j!=k)>=margin else L[1])
  s=L[0] in labels;c=L[2] in labels
 return L[1] if s==c else L[0] if s else L[2]
def summary(x):
 z=x.sum(0);tp,pn,gn,rel,ok,strict,cost=z
 return {'ECAP_TP':int(tp),'predicted_ECAPs':int(pn),'gold_ECAPs':int(gn),'ECAP_precision':tp/pn if pn else None,'ECAP_recall':tp/gn if gn else None,'ECAP_F1':2*tp/(pn+gn) if pn+gn else None,'released_claims':int(rel),'released_source_verified':int(ok),'released_source_unverified':int(rel-ok),'release_source_precision':ok/rel if rel else None,'strict_global_release_correct':int(strict),'strict_global_release_precision':strict/rel if rel else None,'neural_items':int(cost)}
if mode=='v6':
 B=O;rows=read(O/'results/predictions_v1.jsonl');pf=json.load((O/'results/prediction_freeze_v1.json').open());rec=json.load((O/'protocol/runner_freeze_v1.json').open());cut=rec['threshold'];initial=rec['initial_depth'];t=.7;margin=.2;path=O/'results/predictions_v1.jsonl';rawfile=O/'results/score_v1.json';outname='independent_verification_v1.json';itemkey='scored_candidates';costkey='NLI_pairs';checks={'runner_hash':sha(E/'run_scifact_open_locked_v1_20261110.py')==rec['runner_sha256'],'frozen_source_model':sha(V/'models_v6.pkl')==json.load((O/'protocol/protocol_v1.json').open())['models_frozen']['source_model']}
else:
 B=C;rows=read(C/'results/open_predictions_v10.jsonl');pf=json.load((C/'results/open_prediction_freeze_v10.json').open());rec=json.load((C/'results/policy_freeze_v10.json').open());cut=rec['selected']['source_threshold'] if rec['selected'] else 1.01;initial=rec['initial_depth'];t=rec['guard']['confidence'];margin=rec['guard']['margin'];path=C/'results/open_predictions_v10.jsonl';rawfile=C/'results/open_score_v10.json';outname='independent_open_verification_v10.json';itemkey='documents';costkey='document_checks';proto=json.load((C/'protocol/protocol_v10.json').open());checks={'runner_hash':sha(E/'b3_source_context_v10_20261110.py')==rec['code_sha256']==proto['code_sha256'],'frozen_before_open_predictions':not proto['open_predictions_present_at_freeze'],'frozen_context_head':sha(E/'b3_frozen_context_adapter_v8_1_20261110/models/domain_adapter_v8_1.pkl')==proto['frozen_head_sha256']}
keys={str(r['id']):r for r in read(O/'keys/claims_key.jsonl')};inputrows=read(O/'inputs/claims_label_free.jsonl');checks.update(all_claims=len(rows)==len(keys)==len(inputrows)==len({r['case_id'] for r in rows}),prediction_hash=sha(path)==pf['prediction_sha256'],frozen_before_predictions=rec['created_utc']<pf['created_utc']);arrays={p:[] for p in POL};runtime={}
for pol in POL:
 valid=True;gates=True;costs=True;probs=True;retention=True;initial_states=[]
 for row in rows:
  key=keys[row['case_id']];gold=key['evidence'];route=row['routes'][pol];items=route[itemkey];tr=route['trace'];bydoc={}
  for z in items:bydoc.setdefault(z['doc_id'],[]).append(z)
  selected={did:assign(z,t,margin) for did,z in bydoc.items()};selected={d:label for d,label in selected.items() if label!=L[1]};tp=sum(d in gold and gold[d]['label']==label for d,label in selected.items());rel=route['label']!=L[1];ok=rel and any(label==route['label'] and d in gold and gold[d]['label']==label for d,label in selected.items());strict=rel and {z['label'] for z in gold.values()}=={route['label']};arrays[pol].append([tp,len(selected),len(gold),int(rel),int(ok),int(strict),route[costkey]])
  valid &= assign(items,t,margin)==route['label'];costs &= len(items)==route[costkey]==sum(z[costkey] for z in tr);seen=[]
  for k,z in enumerate(tr):
   ids=z['doc_ids'];seen+=ids;current=[s for s in items if s['doc_id'] in seen];valid &= assign(current,t,margin)==z['label']
   if k>0:gates &= len(ids)==1 and route['source_scores'][ids[0]]>=cut and math.isclose(route['source_scores'][ids[0]],z['source_score'],abs_tol=1e-12)
   if pol=='source_active' and k>0:gates &= tr[k-1]['label']==L[1]
  valid &= len(seen)==len(set(seen))==len(bydoc)
  if mode=='v6':
   probs &= all(math.isclose(s['prob_support']+s['prob_neutral']+s['prob_contradict'],1,abs_tol=1e-5) for s in items)
  else:
   probs &= all(math.isclose(sum(s['probabilities']),1,abs_tol=1e-5) and len(s['probabilities'])==3 for s in items);costs &= sum(s['tokens'] for s in items)==route['tokens']
  if pol=='source_active':
   strong=row['routes']['fixed'+str(initial)]['label'];retention &= strong==L[1] or strong==route['label']
 checks[pol+'_all_decisions_and_trace_recompute']=bool(valid);checks[pol+'_source_gate_and_stopping']=bool(gates);checks[pol+'_cost_trace']=bool(costs);checks[pol+'_probabilities']=bool(probs);checks[pol+'_preserves_resolved_initial_route']=bool(retention);arrays[pol]=np.asarray(arrays[pol],float);runtime[pol]={k:sum(r['routes'][pol][k] for r in rows) for k in ['wall_seconds','CPU_seconds']}
metrics={p:dict(summary(x),**runtime[p]) for p,x in arrays.items()};parent=list(range(len(rows)));owner={}
def root(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
for i,row in enumerate(rows):
 for did in keys[row['case_id']]['evidence']:
  if did in owner:parent[root(i)]=root(owner[did])
  owner[did]=i
groups={}
for i in range(len(rows)):groups.setdefault(root(i),[]).append(i)
groups=list(groups.values());ci={}
for kind,units in [('claim',[[i] for i in range(len(rows))]),('source_component',groups)]:
 rng=np.random.default_rng(20261110);zs={p:[] for p in POL if p!='source_active'}
 for _ in range(2000):
  ix=[i for j in rng.integers(0,len(units),len(units)) for i in units[j]];s=summary(arrays['source_active'][ix])['ECAP_F1']
  for pol in zs:zs[pol].append(s-summary(arrays[pol][ix])['ECAP_F1'])
 ci[kind]={p:np.quantile(a,[.025,.975]).tolist() for p,a in zs.items()}
if mode=='v6':
 score=json.load(rawfile.open())
 for p in POL:
  checks[p+'_published_metrics_recompute']=all(score['metrics'][p][k]==val if val is None or isinstance(val,int) else math.isclose(score['metrics'][p][k],val,abs_tol=1e-12) for k,val in metrics[p].items() if k!='neural_items')
 checks['claim_intervals_recompute']=all(np.allclose(ci['claim'][p],score['conditional_claim_bootstrap_ECAP_F1_difference95CI'][p],atol=1e-12) for p in ci['claim'])
else:
 put(rawfile,{'schema':'REVERSOME.B3.SourceContextOpenResults.v10','metrics':metrics,'claims':len(rows),'paired_ECAP_F1_difference95CI':ci,'scope':'Registered candidate; report together with V6. No test-derived model selection. ECAP benchmark annotations are incomplete.'})
audit={'schema':'REVERSOME.B3.SciFactOpenIndependentVerification.'+mode,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(z) for k,z in checks.items()},'metrics':metrics,'claims':len(rows),'annotated_evidence_source_components':len(groups),'paired_ECAP_F1_difference95CI':ci,'scope':'Independent arithmetic/trace reconstruction from original public annotations. Not independent human adjudication; corpus-pooled incomplete labels are not exhaustive scientific truth.'};put(B/'results'/outname,audit);print(json.dumps({k:z for k,z in audit.items() if k not in ['checks','metrics','paired_ECAP_F1_difference95CI']},indent=2));assert all(checks.values()),[k for k,z in checks.items() if not z]
