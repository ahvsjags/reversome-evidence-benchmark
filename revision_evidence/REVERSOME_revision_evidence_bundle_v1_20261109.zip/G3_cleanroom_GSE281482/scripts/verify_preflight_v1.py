import json,hashlib,re,datetime,csv
from pathlib import Path
import h5py
B=Path(__file__).resolve().parents[1]; P=B/'protocol/frozen_protocol_v1.json'; R=B/'results/object_preflight_v1.json'; D=B/'results/download_receipt_v1.json'; M=B/'model_payload'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
p=json.load(open(P));r=json.load(open(R));d=json.load(open(D)); fs=list(csv.DictReader(open(M/'frozen_model_features_v1.tsv'),delimiter='\t')); genes={x['feature'] for x in fs if x['modality']=='RNA'}; bins={x['feature'] for x in fs if x['modality']=='ATAC_10kb'}; result=[]
def add(n,v):result.append({'check':n,'passed':bool(v)})
add('frozen protocol hash',sha(P)==r['protocol_sha256']==d['protocol_sha256'])
add('four expected matrix files',len(p['source']['files'])==len(r['groups'])==len(d['files'])==4)
for e in p['source']['files']:
 f=B/'data'/e['filename']; rec=next(x for x in d['files'] if x['name']==e['filename']); g=next(x for x in r['groups'] if x['filename']==e['filename'])
 with h5py.File(f,'r') as h:
  m=h['matrix']; names=[x.decode() for x in m['features/name'][:]]; types=[x.decode() for x in m['features/feature_type'][:]]; iv=[x.decode() for x in m['features/interval'][:]]; bar=m['barcodes'][:]
  ge={n for n,t in zip(names,types) if t=='Gene Expression'}; covered=set()
  for s,t in zip(iv,types):
   z=re.match(r'^(.+):([0-9]+)-([0-9]+)$',s)
   if t=='Peaks' and z:covered.add(f'{z.group(1)}-{int(z.group(2))//10000*10000}')
  ok=f.stat().st_size==rec['bytes'] and sha(f)==rec['sha256']==g['sha256'] and len(bar)==len(set(bar))==g['n_cells'] and genes<=ge and bins<=covered and tuple(m['shape'][:])==tuple(g['shape'])
 add('independent source/shape/features '+e['sample_label'],ok)
add('preflight did not score counts',r['count_values_scanned'] is False and r['cell_level_scores_created'] is False)
add('restricted-record boundaries',r['hospital_expert_or_clinical_records_accessed'] is False and r['clinical_covariates_read'] is False and r['manuscript_or_rebuttal_changed'] is False)
out={'schema':'REVERSOME.GSE281482.IndependentPreflightVerification.v1','status':'PASS' if all(x['passed'] for x in result) else 'FAIL','checks_passed':sum(x['passed'] for x in result),'checks_total':len(result),'checks':result,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}; O=B/'verification/preflight_independent_verification_v1.json';O.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],out['checks_passed'],'/',out['checks_total'],sha(O));
if out['status']!='PASS':raise SystemExit(2)
