#!/usr/bin/env python3
import json,hashlib,csv,re,datetime
from pathlib import Path
import h5py,numpy as np
from scipy import sparse
B=Path(__file__).resolve().parents[1]; P=B/'protocol/frozen_protocol_v1.json'; R=B/'results/primary_analysis_v1.json'; M=B/'model_payload'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
p=json.load(open(P)); observed=json.load(open(R)); man=json.load(open(M/'manifest_v1.json'))
assert observed['protocol_sha256']==sha(P) and sha(M/'manifest_v1.json')==p['model']['manifest_sha256']
for n,h in man['files'].items():assert sha(M/n)==h
feat=list(csv.DictReader(open(M/'frozen_model_features_v1.tsv'),delimiter='\t')); genes=[x['feature'] for x in sorted([z for z in feat if z['modality']=='RNA'],key=lambda z:int(z['index']))]; bins=[x['feature'] for x in sorted([z for z in feat if z['modality']=='ATAC_10kb'],key=lambda z:int(z['index']))]
prep=list(csv.DictReader(open(M/'frozen_preprocessing_v1.tsv'),delimiter='\t'))
def vec(mod,key):return np.array([float(x[key]) for x in sorted([z for z in prep if z['modality']==mod],key=lambda z:int(z['index']))])
rc,rs=vec('RNA','center'),vec('RNA','scale');ac,ass=vec('ATAC_10kb','center'),vec('ATAC_10kb','scale')
def loadmat(fn):
 rows=list(csv.reader(open(M/fn),delimiter='\t'));return np.array([[float(x) for x in r[1:]] for r in rows[1:]])
W=loadmat('rna_rotation_v1.tsv');V=loadmat('atac_rotation_v1.tsv');Q=loadmat('ridge_beta_v1.tsv')
assert W.shape==(64,16) and V.shape==(64,16) and Q.shape==(16,16)
def cos(x,y):return np.sum(x*y,axis=1)/np.maximum(np.sqrt(np.sum(x*x,axis=1)*np.sum(y*y,axis=1)),np.finfo(float).eps)
checks=[]; recomputed=[]; dl={x['name']:x for x in json.load(open(B/'results/download_receipt_v1.json'))['files']}
for j,e in enumerate(p['source']['files'],1):
 f=B/'data'/e['filename']; assert sha(f)==dl[f.name]['sha256']
 with h5py.File(f,'r') as h:
  g=h['matrix']; shape=tuple(map(int,g['shape'][:])); n=[x.decode() for x in g['features/name'][:]]; t=[x.decode() for x in g['features/feature_type'][:]]; iv=[x.decode() for x in g['features/interval'][:]]; dat=g['data'][:]; ind=g['indices'][:]; ip=g['indptr'][:]
 C=sparse.csc_matrix((dat,ind,ip),shape=shape); ix={}
 for k,(name,typ) in enumerate(zip(n,t)):
  if typ=='Gene Expression':ix.setdefault(name,[]).append(k)
 ri=np.array([ix[x][0] for x in genes]); bmap={x:k for k,x in enumerate(bins)}; rr=[]; cc=[]
 for k,(typ,s) in enumerate(zip(t,iv)):
  if typ=='Peaks':
   m=re.match(r'^(.+):([0-9]+)-([0-9]+)$',s)
   if m:
    q=f'{m.group(1)}-{int(m.group(2))//10000*10000}'
    if q in bmap:rr.append(bmap[q]);cc.append(k)
 S=sparse.csr_matrix((np.ones(len(rr)),(rr,np.arange(len(rr)))),shape=(64,len(rr)))
 x=C[ri,:].T.toarray().astype(float); y=(S@C[np.asarray(cc),:]).T.toarray().astype(float)
 pred=(((x-rc)/rs)@W)@Q; target=((y-ac)/ass)@V; native=float(cos(pred,target).mean()); rng=np.random.default_rng(281482000+j); vals=[]
 for _ in range(100):vals.append(float(cos(pred,target[rng.permutation(len(target))]).mean()))
 shuffled=float(np.mean(vals)); recomputed.append({'sample_label':e['sample_label'],'native_mean_cosine':native,'mean_within_sample_shuffled_cosine':shuffled,'native_minus_shuffled':native-shuffled,'n_cells':len(x)})
 old=next(x for x in observed['sample_results'] if x['sample_label']==e['sample_label'])
 for key,val in [('native_mean_cosine',native),('mean_within_sample_shuffled_cosine',shuffled),('native_minus_shuffled',native-shuffled)]:checks.append({'check':e['sample_label']+' '+key,'passed':abs(val-old[key])<=1e-12,'difference':abs(val-old[key])})
eff=np.array([x['native_minus_shuffled'] for x in recomputed]);rng=np.random.default_rng(281482);boot=eff[rng.integers(0,len(eff),size=(10000,len(eff)))].mean(axis=1);ci=np.quantile(boot,[.025,.975],method='linear');s=observed['summary']
for key,val in [('equal_matrix_mean_effect',float(eff.mean())),('median_matrix_effect',float(np.median(eff))),('positive_matrix_count',int((eff>0).sum())),('min_matrix_effect',float(eff.min())),('max_matrix_effect',float(eff.max()))]:checks.append({'check':'summary '+key,'passed':val==s[key] if isinstance(val,int) else abs(val-s[key])<=1e-12})
checks.append({'check':'descriptive interval','passed':np.allclose(ci,s['descriptive_sample_resampling_95_percentile_interval'],rtol=0,atol=1e-12)})
out={'schema':'REVERSOME.GSE281482.IndependentRecompute.v1','status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','checks_passed':sum(x['passed'] for x in checks),'checks_total':len(checks),'checks':checks,'recomputed_sample_results':recomputed,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uses_same_frozen_inputs_and_independent_code_path':True,'no_hospital_expert_or_clinical_records_accessed':True,'no_manuscript_or_rebuttal_changed':True}
O=B/'verification/independent_recompute_v1.json';O.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],out['checks_passed'],'/',len(checks),sha(O))
if out['status']!='PASS':raise SystemExit(2)
