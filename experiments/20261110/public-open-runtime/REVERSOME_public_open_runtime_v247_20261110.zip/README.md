# Frozen public SciFact-Open prediction and measured-cost replay

278 previously unexposed exact-disjoint original-test claims, a 500,000-abstract
retrieval corpus, five fixed/source-guided policies, three real optimized workload
executions on the same host. No claim or abstract text, patient data, or expert
individual records are distributed here. Gold annotations are reconstructed from
the official public download and pinned by SHA-256.

Python 3.10+ (standard library only):

    python verify_public_open_runtime.py --bundle-dir .

An existing official archive can avoid another 287 MB download:

    python verify_public_open_runtime.py --bundle-dir . --archive /path/scifact_open.tar.gz

This re-scores archived neural outputs; it does not execute a new neural model.
All five ECAP F1 values and every claim-level guard are recomputed, and each
actual inference count is checked against the three physical-run timing records.
The model/threshold/policy were frozen before the original independent test.
Backend optimization was developed afterward and tested for unchanged outputs.
Consequently this bundle is computational validation, not a second independent
accuracy confirmation. Three repeats are not 834 independent scientific claims.

## Interpretation

The source-guided active policy has lower warm workload CPU and elapsed time
than fixed depth 3; its ECAP F1 improvement over fixed depth 3 is not statistically
resolved. Source-guided exhaustive checking has higher ECAP F1 than early stopping.
Actual pool startup and model/index startup remain separately reported; a one-off
startup-inclusive run does not inherit the warm elapsed-time benefit.
Cross-platform strict source-trace comparison failed and remains recorded; a
same-hardware original-versus-optimized diagnostic passed all 4,396 checks.
Incomplete pooled evidence annotation means unannotated predictions are unverified,
not necessarily scientifically false. No researcher-decision improvement is claimed.

SciFact-Open source documentation: https://github.com/dwadden/scifact-open
Paper: https://aclanthology.org/2022.findings-emnlp.347/
Original archive SHA256: 8f4dc238b2eff422bab5c7918fcbddb6996b29d37cb887942ef6ee1a16fb3415
