#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="${PYTHON:-python3.9}"
command -v "$PYTHON_BIN" >/dev/null || { echo "ERROR: Python 3.9.18 is required"; exit 2; }
"$PYTHON_BIN" - <<'PY'
import sys
assert sys.version_info[:3] == (3,9,18), f"required Python 3.9.18, found {sys.version.split()[0]}"
print("Python",sys.version.split()[0])
PY
cd "$ROOT"
sha256sum -c SHA256SUMS
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
grep -v '^python==' "$ROOT/environment/requirements_test_env_py39_lock_v2.txt" > "$TMP/requirements_test_env_py39.txt"
tar -xzf "$ROOT/source/reversome-0.3.1rc7.tar.gz" -C "$TMP"
SRC="$TMP/reversome-0.3.1rc7"
"$PYTHON_BIN" -m venv "$TMP/source-venv"
"$TMP/source-venv/bin/python" -m pip install --disable-pip-version-check --no-input -r "$TMP/requirements_test_env_py39.txt"
"$TMP/source-venv/bin/python" -m pip install --disable-pip-version-check --no-input --no-deps --no-build-isolation -e "$SRC"
(
  cd "$SRC"
  "$TMP/source-venv/bin/python" -m pytest -q tests
)
"$PYTHON_BIN" -m venv "$TMP/wheel-venv"
"$TMP/wheel-venv/bin/python" -m pip install --disable-pip-version-check --no-input -r "$TMP/requirements_test_env_py39.txt"
mkdir -p "$TMP/wheel-site"
"$TMP/wheel-venv/bin/python" -m pip install --disable-pip-version-check --no-input --no-deps --target "$TMP/wheel-site" "$ROOT/wheel/reversome-0.3.1rc7-py3-none-any.whl"
cat > "$TMP/reproduce_origin_plugin.py" <<'PY'
import os
from pathlib import Path
def pytest_sessionstart(session):
    import reversome
    actual=Path(reversome.__file__).resolve()
    expected=Path(os.environ["REVERSOME_EXPECTED_IMPORT_ROOT"]).resolve()
    try:
        actual.relative_to(expected)
    except ValueError:
        raise RuntimeError(f"wheel-origin check failed: {actual} is outside {expected}")
    print(f"wheel-origin check: {actual}")
PY
(
  cd "$SRC"
  PYTHONPATH="$TMP/wheel-site:$TMP" REVERSOME_EXPECTED_IMPORT_ROOT="$TMP/wheel-site" "$TMP/wheel-venv/bin/python" -m pytest -q -c "$SRC/pyproject.toml" --override-ini=pythonpath= --import-mode=importlib -p reproduce_origin_plugin "$SRC/tests"
)
PYTHONPATH="$TMP/wheel-site" "$TMP/wheel-venv/bin/python" - <<'PY'
import reversome
print("installed wheel import:",reversome.__file__)
PY
echo "REPRODUCE_PASS: source and installed-wheel test suites completed."
