"""Independent NumPy mask implementation of all33 sensitivity cells."""
from pathlib import Path
import json,hashlib
import numpy as np
import argparse
p=argparse.ArgumentParser();p.add_argument('--bundle-dir',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args();B=Path(a.bundle_dir);D=Path(a.output_dir);D.mkdir(exist_ok=False);O=B;src=[json.loads(x) for x in (B/'inputs/predictions.jsonl').open()];gold={str(x['id']):x['evidence'] for x in (json.loads(s) for s in (B/'inputs/gold.jsonl').open())};ref=json.load((B/'results.json').open());proto=json.load((B/'protocol.json').open());checks={};maximum=0.
for config in proto['configs']:
 for policy in ['fixed3','source_active','source_fixed_all']:
  TP=P=G=OK=BAD=SUP=RET=POSS=PAIRS=0
  for row in src:
   xs=row['routes']['fixed20']['scored_candidates'];ids=np.array([z['doc_id'] for z in xs]);ranks=np.array([z['rank'] for z in xs]);prob=np.array([[z['prob_support'],z['prob_neutral'],z['prob_contradict']] for z in xs]);passS=(prob[:,0]>=config['relation']) & (prob[:,0]-prob[:,1]>=config['neutral_margin']) & (prob[:,0]-prob[:,2]>=config['opposite_margin']);passC=(prob[:,2]>=config['relation']) & (prob[:,2]-prob[:,1]>=config['neutral_margin']) & (prob[:,2]-prob[:,0]>=config['opposite_margin'])
   def label(mask):
    s=np.any(passS[mask]);c=np.any(passC[mask]);return 'NOT_ENOUGH_INFO' if s==c else 'SUPPORT' if s else 'CONTRADICT'
   scores=row['routes']['source_fixed_all']['source_scores'];names=list(scores);values=np.array([scores[k] for k in names]);offset=1+int(hashlib.sha256(row['case_id'].encode()).hexdigest()[:8],16)%(len(names)-1)
   if config['source_score_binding']!='correct':values=np.roll(values,-offset)
   ss=dict(zip(names,values));depth=3 if policy=='fixed3' else 1;selected=ranks<=depth;d=label(selected)
   if policy=='source_fixed_all' or policy=='source_active' and d=='NOT_ENOUGH_INFO':
    tail=sorted(set(ids[ranks>depth]),key=lambda z:(-ss[z],z))
    for doc in tail:
     if ss[doc]<config['source_threshold']:continue
     selected |= ids==doc;d=label(selected)
     if policy=='source_active' and d!='NOT_ENOUGH_INFO':break
   g=gold[row['case_id']];truths={v['label'] for v in g.values()};truth=next(iter(truths)) if len(truths)==1 else 'NOT_ENOUGH_INFO'
   for doc in set(ids[selected]):
    z=label(selected & (ids==doc))
    if z!='NOT_ENOUGH_INFO':P+=1;TP+=doc in g and g[doc]['label']==z
   G+=len(g);OK+=d==truth;BAD+=d=='SUPPORT' and truth!='SUPPORT';SUP+=d=='SUPPORT';RET+=d==truth=='SUPPORT';POSS+=truth=='SUPPORT';PAIRS+=int(selected.sum())
  got={'ECAP_F1':2*TP/(P+G),'ECAP_TP':TP,'predicted_ECAPs':P,'gold_ECAPs':G,'claim_accuracy':OK/278,'strict_benchmark_false_SUPPORT_count':BAD,'SUPPORT_count':SUP,'strict_benchmark_SUPPORT_FDR':BAD/SUP if SUP else None,'strict_benchmark_valid_SUPPORT_retention':RET/POSS if POSS else None,'replayed_NLI_pairs':PAIRS};old=next(x for x in ref['metrics'] if x['configuration']==config['name'] and x['policy']==policy)
  for k,v in got.items():
   err=0. if v==old[k] else abs(float(v)-float(old[k]));maximum=max(maximum,err);checks[config['name']+'_'+policy+'_'+k]=err<1e-12
checks['default_margin_redundancy_bound']=2*.7-1>=max(.3,.2)
out={'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'max_metric_difference':maximum,'result_sha256':hashlib.sha256((B/'results.json').read_bytes()).hexdigest(),'interpretation':'Default relation>=.7 with normalized3class probabilities already implies each opposing-probability margin>=.4. Tested neutral/opposite margins below.4are algebraically redundant, not separate empirically effective safeguards. Source threshold and binding remain consequential.','scope':'Independent archived-output numerical sensitivity reconstruction, not new inference, independent expert specification or test-driven threshold tuning.'};(D/'independent_verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2));assert out['status']=='PASS'
