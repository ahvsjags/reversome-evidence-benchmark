# REVERSOME revision evidence bundle (9 November 2026)

This is a versioned technical supplement for reviewer-response work. It contains a fresh public-data clean-room replay, aggregate-only external-cohort outputs, a structured requirements-input robustness suite, and a fixture-only aggregate-release validator. It is not the complete manuscript or the full 95-artifact archive.

## Contents

- `G3_cleanroom_GSE281482/`: fresh isolated replay using four public GEO matrices downloaded and hash-checked at run time; frozen-model scoring and independent recomputation; the planner withholds the broad all-four-positive claim. The four GEO input matrices are not redistributed.
- `B6_external_public/`: aggregate-only results from public cohorts. GSE319044 includes 9/9 donor-positive same-cell-minus-within-donor-permutation effects (mean 0.04225; donor bootstrap 95% interval 0.01650–0.07500; exact two-sided sign-test p=0.00390625), independently recomputed. GSE307326 is a distinct external challenge with a near-zero mean same-cell effect (−0.000306; donor bootstrap 95% interval −0.000987 to 0.000149; exact sign-flip p=0.5547), also independently recomputed. These results are heterogeneous and are reported separately, not pooled.
- `B3_robustness/`: generated structured-input fault suite, 80/80 fault cases detected and 40/40 valid controls accepted in the final v4.2 run; zero release authorizations. This is a development diagnostic on generated structured inputs, not an open-ended natural-language or independent expert evaluation.
- `R5m2_validator/`: code, schema, tests, and only a synthetic `TESTFIXTURE_ONLY` packet. No hospital, patient, expert, or clinical records are present. It does not constitute verification of a real restricted-data aggregate.

## Reproduction

For the GSE281482 case, run `bash G3_cleanroom_GSE281482/run_public_case.sh` in an environment with Python 3.9+, `numpy`, `scipy`, `h5py`, and network access to official NCBI GEO; the scripts re-download and verify the four public inputs if absent. See the case protocol and `README_CASE.md` for scope. For B3, run the included tests and scoring verifier from that directory. For R5.m2, run the test suite against the explicitly labeled fixture.

## Scope and licensing

Only public source accessions and derived aggregate summaries are included; no cell barcodes or individual clinical/expert records are included. The project code follows the repository MIT license. Derived summaries are CC BY 4.0. The public GEO source data remain subject to their source archive terms and are not mirrored here. This bundle does not include a DOI, the complete 95-artifact crosswalk, full V14 archive replay, or manuscript edits.
