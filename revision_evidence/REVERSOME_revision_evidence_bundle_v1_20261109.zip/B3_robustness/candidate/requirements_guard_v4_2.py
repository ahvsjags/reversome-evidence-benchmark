#!/usr/bin/env python3
import re
UNIT_MAP={"donor":"donor","donors":"donor","subject":"donor","subjects":"donor","participant":"donor","participants":"donor","cell":"cell","cells":"cell","cellular":"cell","nucleus":"nucleus","nuclei":"nucleus","tissue core":"tissue core","tissue cores":"tissue core"}
UNIT_SCOPE_VARIANTS={"donor":{"donors","subjects","participants"},"cell":{"cells"},"nucleus":{"nuclei"},"tissue core":{"tissue cores"}}
COMPARATOR_MAP={"matched control":"matched control","matched comparator":"matched control","unmatched control":"unmatched control","historical control":"historical control"}
VALIDATORS={"donor":"donor_split_v1","cell":"cell_split_v1","nucleus":"nucleus_split_v1","tissue core":"tissue_core_split_v1"}
def norm(s):return re.sub(r"\s+"," ",str(s or "").strip().lower())
def check(case):
 issues=[];b=case.get("bundle") if isinstance(case,dict) else None
 if not isinstance(b,dict):return {"case_id":case.get("case_id") if isinstance(case,dict) else None,"issue_codes":["BUNDLE_INVALID"],"release_authorized":False}
 reqs=b.get("requirements")
 if not isinstance(reqs,list) or not reqs: return {"case_id":case.get("case_id"),"issue_codes":["REQUIREMENTS_MISSING_OR_INVALID"],"release_authorized":False}
 if not isinstance(b.get("claim_id"),str) or not b.get("claim_id").strip():issues.append("CLAIM_ID_INVALID")
 seen=set()
 for r in reqs:
  if not isinstance(r,dict):issues.append("REQUIREMENT_NOT_OBJECT");continue
  rid=r.get("requirement_id")
  if not isinstance(rid,str) or not rid.strip():issues.append("REQUIREMENT_ID_INVALID")
  elif rid in seen:issues.append("REQUIREMENT_ID_DUPLICATE")
  else:seen.add(rid)
  if not isinstance(r.get("mandatory"),bool):issues.append("MANDATORY_TYPE_INVALID")
  if r.get("missing_policy") not in ("block","escalate","explicitly_not_required"):issues.append("MISSING_POLICY_INVALID")
  if not isinstance(r.get("scientific_rationale"),str) or not r.get("scientific_rationale").strip():issues.append("RATIONALE_MISSING")
  if norm(r.get("category"))!="split":issues.append("CATEGORY_UNSUPPORTED_REQUIRES_REVIEW");continue
  span=r.get("source_span") if isinstance(r.get("source_span"),dict) else {}
  excerpt=norm(span.get("excerpt"));ref=span.get("reference");digest=span.get("sha256")
  if not excerpt or not isinstance(ref,str) or not ref.strip() or not isinstance(digest,str) or not re.fullmatch(r"[0-9a-fA-F]{64}",digest):issues.append("SOURCE_PROVENANCE_INVALID")
  start,end=span.get("start"),span.get("end")
  if not isinstance(start,int) or not isinstance(end,int) or start<0 or end<=start:issues.append("SOURCE_SPAN_INVALID")
  # Ambiguous source expressions are review holds, not guessed into a single value.
  mu=re.search(r"test unit is (?:a |an )?([a-z ]+?)(?: and | or |;|\.)",excerpt)
  mc=re.search(r"registered comparator is (?:a |an )?([a-z ]+?)(?:\.|;|$)",excerpt)
  unit_ambiguous=bool(re.search(r"test unit is .+? or .+? and (?:the )?registered comparator",excerpt))
  source_unit=UNIT_MAP.get(norm(mu.group(1))) if mu and not unit_ambiguous else None
  source_comp=COMPARATOR_MAP.get(norm(mc.group(1))) if mc else None
  req_unit=UNIT_MAP.get(norm(r.get("unit")))
  req_comp=COMPARATOR_MAP.get(norm(r.get("comparator")))
  if not source_unit:issues.append("UNIT_AMBIGUOUS_OR_UNRESOLVED")
  elif not req_unit:issues.append("UNIT_VALUE_UNSUPPORTED")
  elif source_unit!=req_unit:issues.append("UNIT_SOURCE_CONTRADICTION")
  if not source_comp:issues.append("COMPARATOR_AMBIGUOUS_OR_UNRESOLVED")
  elif not req_comp:issues.append("COMPARATOR_VALUE_UNSUPPORTED")
  elif source_comp!=req_comp:issues.append("COMPARATOR_SOURCE_CONTRADICTION")
  t=r.get("threshold") if isinstance(r.get("threshold"),dict) else {}
  tr=norm(t.get("rationale"));mt=re.search(r"held-out ([a-z ]+?) must not occur in training",tr)
  t_unit=UNIT_MAP.get(norm(mt.group(1))) if mt else None
  if not t_unit or norm(t.get("operator"))!="eq" or norm(t.get("value"))!=t_unit+"-disjoint":issues.append("THRESHOLD_INCONSISTENT_OR_AMBIGUOUS")
  elif req_unit and t_unit!=req_unit:issues.append("THRESHOLD_UNIT_CONTRADICTION")
  scope=r.get("scope") if isinstance(r.get("scope"),dict) else {}
  if scope.get("claim_id")!=b.get("claim_id"):issues.append("SCOPE_CLAIM_LINK_INVALID")
  if not t_unit or not req_unit:issues.append("SCOPE_REQUIRES_REVIEW")
  elif norm(scope.get("statement")) not in {f"generalizes to held-out {x} only." for x in UNIT_SCOPE_VARIANTS[t_unit]}:issues.append("SCOPE_NOT_BOUNDED")
  if not req_unit or VALIDATORS.get(req_unit)!=r.get("validator_id"):issues.append("VALIDATOR_NOT_REGISTERED")
 return {"case_id":case.get("case_id"),"issue_codes":sorted(set(issues)),"release_authorized":False,"status":"REQUIRES_REVIEW" if issues else "SOURCE_CONSISTENT_REQUIRES_REVIEW"}
