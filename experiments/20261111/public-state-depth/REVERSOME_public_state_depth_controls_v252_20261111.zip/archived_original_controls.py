"""Frozen exploratory target control using RNA-only clusters and read-depth strata.

All four controls use the same eligible cells. No model or feature refit occurs.
"""
from pathlib import Path
import os,json,csv,gzip,hashlib,datetime,time
import numpy as np
import h5py
from scipy.sparse import csc_matrix
E=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation/05_evidence_updates');P=E/'b6_gse286182_full_cohort_raw_reprocess_v1_20261108/cellranger_full_cohort_v2_20261110';B=E/'b6_state_depth_control_v2_20261111';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wire(o):
 if isinstance(o,np.generic):return o.item()
 if isinstance(o,np.ndarray):return o.tolist()
 raise TypeError(type(o).__name__)
def put(p,d):p.write_text(json.dumps(d,indent=2,default=wire))
def prepare():
 B.mkdir(exist_ok=False);(B/'metadata').mkdir();proto={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'Post-hoc scientific robustness of the already frozen GSE286182 model. Cohort already inspected, new conditional-control outputs not yet calculated.','source_score_sha256':sha(P/'results/raw_reprocessed_frozen_score_v1.json'),'controls':['global_same_eligible_cells','RNA_graph_state_only','RNA_UMI_ATAC_fragment_depth_only','RNA_state_and_depth'],'state':'CellRangerARC RNA-only graph clustering, never ATAC/joint clustering; not expert cell-type labels.','depth':['H5.sum_all_GeneExpression_counts_by_joint_barcode','per_barcode_metrics.atac_fragments'],'depth_bins':'Two within-library log1p quantiles at1/3,2/3, searchsorted(side=right); no jitter or outcome-selected binning.','eligible':'Common set of cells in RNA-state x RNA-depth-tercile x ATAC-depth-tercile strata of size>=2; all four controls on this exact set. Require>=90% coverage of each library; otherwise classify insufficient instead of dropping libraries or changing bins.','permutation':'100 random within-stratum Hamiltonian-cycle derangements; each target uniformly different from the same cell in its stratum; no self-targets.','seed':[20261111,'sorted_sample_index','control_index','draw_index'],'unit':'Equal library mean within each donor, equal8donor mean;20000donor bootstrap;256exact two-sided sign-flip assignments; all4 p-values plus Holm context.','claim':'Frozen predictions retain same-cell correspondence after RNA-state and joint sequencing-depth matching.','decision_rule':'Release conditional association only if all source/unit/coverage/derangement checks pass, donor-bootstrap lower bound>0 and exact two-sided signflip<=.05; otherwise withhold the stronger conditional claim. This is not independent human scientific judgment validation.','scientific_boundary':'Conditional sensitivity, not causal adjustment; conditioning on ATAC depth can remove biological as well as technical variation. Original global primary result is retained unchanged.','data_boundary':'Only public GSE286182 files; no protected hospital/expert records.'};put(B/'protocol.json',proto);print('CONTROL_PROTOCOL_FROZEN',sha(B/'protocol.json'),flush=True)
def summary(rows):
 by={}
 for r in rows:by.setdefault(r['subject_ref'],[]).append(r['delta'])
 vals={k:float(np.mean(v)) for k,v in sorted(by.items())};a=np.array(list(vals.values()));assert len(a)==8;boot=np.random.default_rng(20261111).choice(a,size=(20000,8),replace=True).mean(1);signs=1-2*((np.arange(256)[:,None]>>np.arange(8))&1);return {'donor_effects':vals,'mean':float(a.mean()),'donor_bootstrap95CI':np.quantile(boot,[.025,.975]).tolist(),'exact_two_sided_signflip_p':float((np.abs((signs*a).mean(1))>=abs(a.mean())-1e-15).mean())}
def run():
 proto=json.load((B/'protocol.json').open());src=json.load((P/'results/raw_reprocessed_frozen_score_v1.json').open());assert sha(P/'results/raw_reprocessed_frozen_score_v1.json')==proto['source_score_sha256'];assert json.load((P/'results/raw_score_independent_verification_v1.json').open())['status']=='PASS';allrows=[];checks={};provenance=[]
 for sample_index,r in enumerate(src['samples']):
  k=r['sample_ref'];outs=P/'results/cellranger'/('GSE286182_'+k)/'outs';cp=outs/'analysis/clustering/gex/graphclust/clusters.csv';mp=outs/'per_barcode_metrics.csv';start=time.perf_counter()
  with np.load(r['prediction_npz'],allow_pickle=False) as z:pred=z['predicted_atac_latent'];obs=z['observed_atac_latent'];bc=z['barcodes'].astype(str);native=z['native_cosine'];n=len(bc)
  need=set(bc);clusters={}
  with cp.open() as f:
   for x in csv.DictReader(f):
    if x['Barcode'] in need:clusters[x['Barcode']]=int(x['Cluster'])
  depths={}
  with mp.open() as f:
   for x in csv.DictReader(f):
    if x['barcode'] in need:
     assert x['barcode'] not in depths;depths[x['barcode']]=(int(x['gex_umis_count']),int(x['atac_fragments']))
  assert set(clusters)==set(depths)==need
  hp=outs/'filtered_feature_bc_matrix.h5'
  with h5py.File(hp,'r') as h:
   m=h['matrix'];hbc=[x.decode() for x in m['barcodes'][:]];types=np.array([x.decode() for x in m['features']['feature_type'][:]]);mat=csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(map(int,m['shape'][:])));totals=np.asarray(mat[types=='Gene Expression',:].sum(axis=0)).ravel();umi=dict(zip(hbc,map(int,totals)))
  state=np.array([clusters[x] for x in bc]);rna=np.array([umi[x] for x in bc]);atac=np.array([depths[x][1] for x in bc]);assert (rna>0).all() and (atac>0).all()
  with np.load(r['input_npz'],allow_pickle=False) as raw:checks[k+'_RNA_depth_covers_all64_raw_gene_counts']=bool(np.all(rna>=raw['rna_raw_counts'].sum(axis=0)))
  rbin=np.searchsorted(np.quantile(np.log1p(rna),[1/3,2/3]),np.log1p(rna),side='right');abin=np.searchsorted(np.quantile(np.log1p(atac),[1/3,2/3]),np.log1p(atac),side='right');depth=rbin*3+abin;joint=state*9+depth;u,c=np.unique(joint,return_counts=True);eligible=np.isin(joint,u[c>=2]);idx=np.flatnonzero(eligible);fraction=len(idx)/n;checks[k+'_coverage_atleast90pct']=fraction>=.9;checks[k+'_RNA_graph_and_depth_all_barcodes']=set(clusters)==set(depths)==need
  meta=B/'metadata'/(k+'.csv.gz')
  with gzip.open(meta,'wt') as f:
   w=csv.writer(f);w.writerow(['barcode','RNA_graph_state','RNA_UMIs','ATAC_fragments','RNA_depth_bin','ATAC_depth_bin','eligible'])
   w.writerows((str(bc[i]),int(state[i]),int(rna[i]),int(atac[i]),int(rbin[i]),int(abin[i]),int(eligible[i])) for i in range(n))
  pnorm=np.linalg.norm(pred,axis=1);onorm=np.linalg.norm(obs,axis=1);native2=np.sum(pred*obs,axis=1)/np.maximum(pnorm*onorm,np.finfo(float).eps);checks[k+'_native_matches_original']=float(np.max(np.abs(native-native2)))<=1e-12;labels=[np.zeros(n,int),state,depth,joint];controlrows=[]
  for ci,name in enumerate(proto['controls']):
   lab=labels[ci];groups=[idx[lab[idx]==g] for g in np.unique(lab[idx])];assert all(len(g)>=2 for g in groups);means=[];valid=True
   for draw in range(100):
    rng=np.random.default_rng(np.random.SeedSequence([20261111,sample_index,ci,draw]));permutation=np.arange(n)
    for group in groups:order=rng.permutation(group);permutation[order]=np.roll(order,1)
    valid &= np.all(permutation[idx]!=idx) and np.array_equal(labels[ci][idx],labels[ci][permutation[idx]]) and set(permutation[idx])==set(idx);v=np.sum(pred[idx]*obs[permutation[idx]],axis=1)/np.maximum(pnorm[idx]*onorm[permutation[idx]],np.finfo(float).eps);means.append(float(v.mean()))
   native_mean=float(native[idx].mean());rec={'sample_ref':k,'subject_ref':r['subject_ref'],'control':name,'cells_all':n,'cells_eligible':len(idx),'coverage':fraction,'native_mean':native_mean,'permuted_mean':float(np.mean(means)),'delta':native_mean-float(np.mean(means)),'permutation_means':means,'strata':len(groups)};allrows.append(rec);controlrows.append(rec);checks[k+'_'+name+'_100_valid_derangements']=bool(valid)
  provenance.append({'sample_ref':k,'prediction_sha256':sha(Path(r['prediction_npz'])),'cluster_source_sha256':sha(cp),'metrics_source_sha256':sha(mp),'RNA_UMI_H5_source_sha256':sha(hp),'zero_csv_RNA_field_cells':sum(v[0]==0 for v in depths.values()),'released_metadata_sha256':sha(meta)});print('MATCHED_CONTROL_SAMPLE_DONE',k,n,len(idx),round(time.perf_counter()-start,2),flush=True)
 results={name:summary([r for r in allrows if r['control']==name]) for name in proto['controls']};difference=[]
 for r in allrows:
  if r['control']==proto['controls'][0]:difference.append({**r,'delta':r['delta']-next(x['delta'] for x in allrows if x['sample_ref']==r['sample_ref'] and x['control']==proto['controls'][-1])})
 attenuation=summary(difference);pvals=np.array([results[n]['exact_two_sided_signflip_p'] for n in proto['controls']]);order=np.argsort(pvals);adjusted=np.maximum.accumulate([min(1.,(4-i)*pvals[j]) for i,j in enumerate(order)])
 for j,v in zip(order,adjusted):results[proto['controls'][int(j)]]['Holm4_p']=float(v)
 conditional=results[proto['controls'][-1]];decision='RELEASE' if all(checks.values()) and conditional['donor_bootstrap95CI'][0]>0 and conditional['exact_two_sided_signflip_p']<=.05 else 'WITHHOLD';res={'schema':'REVERSOME.PublicStateDepthConditionalControl.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution_status':'PASS' if all(checks.values()) else 'INPUT_OR_COVERAGE_FAILURE','checks':{k:bool(v) for k,v in checks.items()},'samples':allrows,'results':results,'global_minus_state_depth_effect':attenuation,'conditional_claim_decision':decision,'provenance':provenance,'protocol_sha256':sha(B/'protocol.json'),'scope':proto['scientific_boundary']+' Post-hoc frozen-model robustness, not an independent new cohort, human judgment study or training-pairing benefit.'};put(B/'results.json',res);print(json.dumps({k:v for k,v in res.items() if k not in ['checks','samples','provenance']},indent=2));assert all(checks.values())
if __name__=='__main__':prepare() if len(os.sys.argv)>1 and os.sys.argv[1]=='prepare' else run()
