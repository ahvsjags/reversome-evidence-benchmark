"""Learn the value of an additional context check, rather than threshold confidence."""
from pathlib import Path
import json,hashlib,pickle,datetime,sys,time,importlib.util,collections
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';P=E/'b3_context_verifier_v7_20261110';V8=E/'b3_frozen_context_adapter_v8_1_20261110';B=E/'b3_learned_context_value_v9_20261110';SRC=E/'b3_frozen_context_adapter_v8_1_20261110.py';sp=importlib.util.spec_from_file_location('verifier',SRC);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);L=v.L;POL=['fixed2','fixed6','fixed_full','confidence_active','learned_active','random_active']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2)
def write(p,rows):
 with Path(p).open('x') as f:
  for r in rows:f.write(json.dumps(r)+'\n')
def feat(first,case,full_tokens):
 p=np.array(first['probabilities'],float);s=np.sort(p);idx=first['sentence_indices'];n=max(len(case['sentences']),1);return np.r_[np.round(p,4),round(float(-sum(p*np.log(np.maximum(p,1e-12)))),6),round(float(s[-1]-s[-2]),6),round(first['tokens']/384,6),round(full_tokens/384,6),round(first['tokens']/max(full_tokens,1),6),round(float(np.log1p(n)),6),round(float(np.log1p(len(case['claim'].split()))),6),round(float(np.mean(idx))/n,6),round((max(idx)-min(idx))/n,6),round(len(idx)/n,6)]
def reg(X,y):return HistGradientBoostingRegressor(max_iter=60,max_leaf_nodes=4,min_samples_leaf=40,l2_regularization=10,learning_rate=.05,random_state=20261110).fit(X,y)
def setup():
 B.mkdir(exist_ok=False)
 for x in ['protocol','models','results']:(B/x).mkdir()
 proto={'schema':'REVERSOME.B3.LearnedContextValueProtocol.v9','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'V8 official-dev confidence stopping has no feasible advantage over fixed_full. Test whether action-conditional expected correction/risk explains continuation better than confidence alone.','verifier_unchanged':'Use V8.1 encoder, chosen head and all5974 training/940 official-dev pairs; no new encoder/head fitting or external test tuning.','controller':'HistGradientBoostingRegressor60 iterations4 leaves,minleaf40,l2=10,lr.05,seed20261110;13 features using only observed prefix posterior and cheap source/input metadata. Probabilities quantized4decimal for numerical stability.','target':'Fit-fold class-balanced correctness(full)-correctness(prefix), minus risk_lambda*(falseSUPPORT(full)-falseSUPPORT(prefix)), minus cost_price*(full_tokens/384)^2.','meta_validation':'5-fold claim-group-disjoint OOF; all pairs from each dev claim stay together. Source corpus is fixed/shared, not independent-study validation. Fold utility weights use fit-fold labels only.','risk_grid':[0,.5,1,2,4],'cost_grid':[0,.01,.05,.1],'selection':'Max OOF BA subject to BA/FDR/support retention not worse than official-dev-selected fixed. Tie fewer token-squared proxy units. Equal-quality dominated active policy=>fixed fallback.','random_comparator':'Independently run random-prefix dev neural checks and fit the same controller/grid to its own observed states; not an uncalibrated straw-man.','no_oracle':'Runtime never reads future full-context NN outcome; full-token count is computed cheaply from known source text.','no_op_guard':'If the prefix already contains every source sentence, no extra check is executed.','actual_live_arms':POL,'external_test_scores_opened_for_design':False,'v8_external_score_files_present_at_freeze':{n:(V8/'results'/f'{n}_score_v8_1.json').exists() for n in ['healthver_test','covidfact_test']},'runtime_code_sha256':sha(__file__),'parent_verifier_code_sha256':sha(SRC),'scope':'Action-policy development and heldout transport, not independent human-researcher evaluation; all results retained.'};put(B/'protocol/protocol_v9.json',proto);print(json.dumps(proto,indent=2))
def fit():
 parent=json.load((V8/'results/policy_freeze_v8_1.json').open());cal=v.jl(P/'inputs/calibration.jsonl');states=v.jl(V8/'results/calibration_predictions_v8_1.jsonl');lookup={r['case_id']:r for r in states};enc=v.Encoder();enc.head=pickle.load((V8/'models/domain_adapter_v8_1.pkl').open('rb'));enc.mode=parent['decoder'];random_states=[]
 for i in range(0,len(cal),16):
  batch=cal[i:i+16];X,tokens,indices=enc.embed(batch,2,True);adapt=enc.head.predict_proba(X);adapt=adapt[:,[list(enc.head.classes_).index(k) for k in L]];base=np.exp(X[:,-3:]-X[:,-3:].max(1)[:,None]);base=base/base.sum(1)[:,None];pp=base if parent['decoder']=='native' else adapt
  for j,p in enumerate(pp):random_states.append({'label':L[int(p.argmax())],'probabilities':p.tolist(),'tokens':tokens[j],'sentence_indices':indices[j]})
 write(B/'results/random_prefix_dev_v9.jsonl',random_states);y=np.array([r['label'] for r in cal]);g=np.array([r['claim_group'] for r in cal]);full=[lookup[r['case_id']]['states']['fixed_full'] for r in cal];df=np.array([r['label'] for r in full]);strong=parent['strong_fixed'];db=np.array([lookup[r['case_id']]['states'][strong]['label'] for r in cal]);base=v.quality(y,db);basecost=sum(lookup[r['case_id']]['states'][strong]['tokens']**2 for r in cal);controllers={};allfits={};proto=json.load((B/'protocol/protocol_v9.json').open())
 for mode in ['lexical','random']:
  first=[]
  for i,r in enumerate(cal):
   if mode=='random':s=dict(random_states[i])
   else:s={**lookup[r['case_id']]['states']['fixed2'],'sentence_indices':enc.text(r,2)[1]}
   first.append(s)
  X=np.array([feat(first[i],r,full[i]['tokens']) for i,r in enumerate(cal)]);d0=np.array([s['label'] for s in first]);complete=np.array([len(s['sentence_indices'])==len(r['sentences']) for s,r in zip(first,cal)]);options=[]
  for risk in proto['risk_grid']:
   for price in proto['cost_grid']:
    oof=np.zeros(len(y))
    for a,b in GroupKFold(5).split(X,y,g):
     assert not set(g[a])&set(g[b]);freq=collections.Counter(y[a]);weights=np.array([len(a)/(len(L)*freq[z]) for z in y[a]]);target=weights*((df[a]==y[a]).astype(float)-(d0[a]==y[a]).astype(float))-risk*(((df[a]=='SUPPORT')&(y[a]!='SUPPORT')).astype(float)-((d0[a]=='SUPPORT')&(y[a]!='SUPPORT')).astype(float))-price*np.array([(full[i]['tokens']/384)**2 for i in a]);model=reg(X[a],target);oof[b]=model.predict(X[b])
    expand=(oof>0)&~complete;pred=np.where(expand,df,d0);q=v.quality(y,pred);q.update(risk_lambda=risk,cost_price=price,proxy=sum(first[i]['tokens']**2+(full[i]['tokens']**2 if expand[i] else 0) for i in range(len(y))),expansions=int(expand.sum()),feasible=q['BA']>=base['BA']-1e-12 and q['FDR']<=base['FDR']+1e-12 and q['retention']>=base['retention']-1e-12);options.append(q)
  feasible=[q for q in options if q['feasible']];best=max(feasible,key=lambda q:(q['BA'],-q['proxy'])) if feasible else None
  if best and best['BA']<=base['BA']+1e-12 and best['proxy']>=basecost:best=None
  controllers[mode]={'selected':best,'fallback':best is None,'strong_fixed':strong}
  if best:
   freq=collections.Counter(y);w=np.array([len(y)/(len(L)*freq[z]) for z in y]);target=w*((df==y).astype(float)-(d0==y).astype(float))-best['risk_lambda']*(((df=='SUPPORT')&(y!='SUPPORT')).astype(float)-((d0=='SUPPORT')&(y!='SUPPORT')).astype(float))-best['cost_price']*np.array([(r['tokens']/384)**2 for r in full]);controllers[mode]['model']=reg(X,target)
  allfits[mode]={'baseline':base,'candidates':options,'selected':best,'fallback':best is None}
 # Negative control: future outcomes have no route-feature input.
 a=first[0];case=cal[0];z=feat(a,case,full[0]['tokens']);future={**full[0],'probabilities':[1,0,0],'label':'SUPPORT'};assert np.array_equal(z,feat(a,case,future['tokens']))
 with (B/'models/controllers_v9.pkl').open('xb') as f:pickle.dump(controllers,f)
 freeze={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decoder':parent['decoder'],'baseline_strong_fixed':strong,'fits':allfits,'controllers_sha256':sha(B/'models/controllers_v9.pkl'),'head_sha256':sha(V8/'models/domain_adapter_v8_1.pkl'),'parent_policy_sha256':sha(V8/'results/policy_freeze_v8_1.json'),'runtime_code_sha256':sha(__file__),'negative_control_future_outcome_invariance':True,'external_test_key_opened_for_selection':False};put(B/'results/controller_freeze_v9.json',freeze);print(json.dumps({'lexical':allfits['lexical']['selected'],'random':allfits['random']['selected'],'decoder':parent['decoder']},indent=2))
def live():
 freeze=json.load((B/'results/controller_freeze_v9.json').open());assert freeze['runtime_code_sha256']==sha(__file__) and freeze['controllers_sha256']==sha(B/'models/controllers_v9.pkl');models=pickle.load((B/'models/controllers_v9.pkl').open('rb'));parent=json.load((V8/'results/policy_freeze_v8_1.json').open());enc=v.Encoder();enc.head=pickle.load((V8/'models/domain_adapter_v8_1.pkl').open('rb'));enc.mode=parent['decoder']
 for name in ['healthver_test','covidfact_test']:
  rows=v.jl(P/'inputs'/f'{name}_label_free.jsonl');out=[]
  for i,r in enumerate(rows):
   routes={};order=POL[i%len(POL):]+POL[:i%len(POL)]
   for policy in order:
    start=time.perf_counter();ct=time.process_time();gain=None
    if policy.startswith('fixed') or policy=='confidence_active' and parent['fallback'] or policy in ['learned_active','random_active'] and models['random' if policy=='random_active' else 'lexical']['fallback']:
     key=policy if policy.startswith('fixed') else parent['strong_fixed'];trace=[enc.predict(r,2 if key=='fixed2' else 6 if key=='fixed6' else None)]
    else:
     first=enc.predict(r,2,policy=='random_active');trace=[first];complete=len(first['sentence_indices'])==len(r['sentences']);expand=False
     if not complete:
      if policy=='confidence_active':expand=max(first['probabilities'])<parent['selected']['threshold']
      else:
       fulltext=enc.text(r)[0];ft=len(enc.tok(fulltext,r['claim'],truncation=True,max_length=384)['input_ids']);model=models['random' if policy=='random_active' else 'lexical']['model'];gain=float(model.predict(feat(first,r,ft)[None,:])[0]);expand=gain>0
     if expand:trace.append(enc.predict(r))
    routes[policy]={'label':trace[-1]['label'],'wall_seconds':time.perf_counter()-start,'CPU_seconds':time.process_time()-ct,'neural_calls':len(trace),'tokens':sum(s['tokens'] for s in trace),'predicted_continuation_value':gain,'trace':trace}
   out.append({'case_id':r['case_id'],'claim_group':r['claim_group'],'doc_id':r['doc_id'],'execution_order':order,'routes':routes})
   if (i+1)%100==0:print('CONTEXT_VALUE_LIVE',name,i+1,len(rows),flush=True)
  p=B/'results'/f'{name}_predictions_v9.jsonl';write(p,out);put(B/'results'/f'{name}_prediction_freeze_v9.json',{'prediction_sha256':sha(p),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'test_keys_opened':False})
def score():
 for name in ['healthver_test','covidfact_test']:
  p=B/'results'/f'{name}_predictions_v9.jsonl';assert sha(p)==json.load((B/'results'/f'{name}_prediction_freeze_v9.json').open())['prediction_sha256'];rows=v.jl(p);keys={r['case_id']:r for r in v.jl(P/'keys'/f'{name}.jsonl')};y=[keys[r['case_id']]['label'] for r in rows];metrics={};checks={'all_pairs_kept':len(rows)==len(keys)==len({r['case_id'] for r in rows})}
  for policy in POL:
   q=v.quality(y,[r['routes'][policy]['label'] for r in rows]);q.update({k:sum(r['routes'][policy][k] for r in rows) for k in ['wall_seconds','CPU_seconds','tokens','neural_calls']});metrics[policy]=q;checks[policy+'_trace']=all(all(L[int(np.argmax(s['probabilities']))]==s['label'] for s in r['routes'][policy]['trace']) and r['routes'][policy]['label']==r['routes'][policy]['trace'][-1]['label'] for r in rows)
  groups={}
  for i,r in enumerate(rows):groups.setdefault(r['claim_group'],[]).append(i)
  groups=list(groups.values());mat=np.array([[np.mean([rows[i]['routes'][pol]['label']==y[i] for i in ix]) for pol in POL] for ix in groups]);rng=np.random.default_rng(20261110);boot=np.array([mat[rng.integers(0,len(groups),len(groups))].mean(0) for _ in range(2000)]);ai=POL.index('learned_active');res={'schema':'REVERSOME.B3.LearnedContextValueEvaluation.v9','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'dataset':name,'source_pairs':len(rows),'natural_claims':len(groups),'metrics':metrics,'equal_claim_accuracy':dict(zip(POL,map(float,mat.mean(0)))),'paired_claim_accuracy_difference95CI':{pol:np.quantile(boot[:,ai]-boot[:,j],[.025,.975]).tolist() for j,pol in enumerate(POL) if pol!='learned_active'},'prediction_sha256':sha(p),'scope':'Official-dev-only controller learning; no test parameter tuning. Code PASS is not a superiority claim; fixed-corpus claim-cluster uncertainty and all negatives retained.'};put(B/'results'/f'{name}_score_v9.json',res);print(json.dumps(res,indent=2));assert all(checks.values())
if __name__=='__main__':{'setup':setup,'fit':fit,'live':live,'score':score}[sys.argv[1]]()
