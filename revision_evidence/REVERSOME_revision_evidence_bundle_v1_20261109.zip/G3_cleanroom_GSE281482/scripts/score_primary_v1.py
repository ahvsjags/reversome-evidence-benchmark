#!/usr/bin/env python3
import csv,json,hashlib,datetime,platform,os
from pathlib import Path
import h5py,numpy as np,scipy
from scipy import sparse
B=Path(__file__).resolve().parents[1]; P=B/'protocol/frozen_protocol_v1.json'; A=B/'protocol/addenda/analysis_parameters_v1.json'; PRE=B/'results/object_preflight_v1.json'; VER=B/'verification/preflight_independent_verification_v1.json'; DL=B/'results/download_receipt_v1.json'; M=B/'model_payload'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for c in iter(lambda:f.read(1<<20),b''):h.update(c)
 return h.hexdigest()
p=json.loads(P.read_text());a=json.loads(A.read_text());pre=json.loads(PRE.read_text());ver=json.loads(VER.read_text());dl=json.loads(DL.read_text());man=json.loads((M/'manifest_v1.json').read_text())
assert pre['status']=='PASS_STRUCTURAL_PREFLIGHT' and ver['status']=='PASS' and sha(P)==a['parent_protocol_sha256']==pre['protocol_sha256']==dl['protocol_sha256']
assert sha(M/'manifest_v1.json')==p['model']['manifest_sha256']
for n,h in man['files'].items():assert sha(M/n)==h
features=sorted(csv.DictReader((M/'frozen_model_features_v1.tsv').open(),delimiter='\t'),key=lambda r:(r['modality'],int(r['index'])))
rna=[r['feature'] for r in features if r['modality']=='RNA']; bins=[r['feature'] for r in features if r['modality']=='ATAC_10kb']
prep=list(csv.DictReader((M/'frozen_preprocessing_v1.tsv').open(),delimiter='\t'))
def par(mod,field):return np.array([float(x[field]) for x in sorted([r for r in prep if r['modality']==mod],key=lambda r:int(r['index']))])
rc,rs=par('RNA','center'),par('RNA','scale'); ac,ass=par('ATAC_10kb','center'),par('ATAC_10kb','scale')
def nm(name):
 with (M/name).open() as f:
  rows=list(csv.reader(f,delimiter='\t'))
 return np.asarray([[float(v) for v in r[1:]] for r in rows[1:]],dtype=np.float64)
xr=nm('rna_rotation_v1.tsv'); yr=nm('atac_rotation_v1.tsv'); beta=nm('ridge_beta_v1.tsv'); assert xr.shape==(64,16) and yr.shape==(64,16) and beta.shape==(16,16)
def cosine(x,y):
 return np.einsum('ij,ij->i',x,y)/np.maximum(np.sqrt(np.einsum('ij,ij->i',x,x)*np.einsum('ij,ij->i',y,y)),np.finfo(float).eps)
by={x['name']:x for x in dl['files']}; groups=[]
for j,e in enumerate(p['source']['files'],1):
 f=B/'data'/e['filename']; z=by[e['filename']]; assert f.stat().st_size==z['bytes'] and sha(f)==z['sha256']
 with h5py.File(f,'r') as h:
  g=h['matrix']; shape=tuple(map(int,g['shape'][:])); names=[x.decode() for x in g['features/name'][:]]; types=[x.decode() for x in g['features/feature_type'][:]]; intervals=[x.decode() for x in g['features/interval'][:]]; data=g['data'][:]; inds=g['indices'][:]; ptr=g['indptr'][:]
 if np.any(data<0):raise ValueError('NEGATIVE_COUNTS:'+f.name)
 mat=sparse.csc_matrix((data,inds,ptr),shape=shape); lookup={}
 for i,(n,t) in enumerate(zip(names,types)):
  if t=='Gene Expression':lookup.setdefault(n,[]).append(i)
 if any(len(lookup.get(x,[]))!=1 for x in rna):raise ValueError('FROZEN_GENE_AMBIGUITY:'+f.name)
 ri=np.array([lookup[x][0] for x in rna]); bi={x:i for i,x in enumerate(bins)}; pr=[]; pb=[]
 for i,(t,iv) in enumerate(zip(types,intervals)):
  if t!='Peaks':continue
  import re
  m=re.match(r'^(.+):([0-9]+)-([0-9]+)$',iv)
  if m:
   k=f'{m.group(1)}-{int(m.group(2))//10000*10000}'
   if k in bi:pr.append(i);pb.append(bi[k])
 if set(pb)!=set(range(64)):raise ValueError('ATAC_BIN_COVERAGE:'+f.name)
 agg=sparse.csr_matrix((np.ones(len(pr),dtype=np.int8),(pb,np.arange(len(pr)))),shape=(64,len(pr)))
 X=mat[ri,:].T.toarray().astype(np.float64); Y=(agg@mat[np.asarray(pr),:]).T.toarray().astype(np.float64)
 xz=(X-rc)/rs; yz=(Y-ac)/ass; pred=(xz@xr)@beta; target=yz@yr
 native=float(np.mean(cosine(pred,target))); rng=np.random.default_rng(281482000+j); perm=[]
 for _ in range(100):perm.append(float(np.mean(cosine(pred,target[rng.permutation(len(target))]))))
 groups.append({'sample_label':e['sample_label'],'filename':f.name,'n_cells':len(X),'native_mean_cosine':native,'mean_within_sample_shuffled_cosine':float(np.mean(perm)),'native_minus_shuffled':native-float(np.mean(perm)),'n_target_shuffles':100,'input_sha256':z['sha256']})
eff=np.array([g['native_minus_shuffled'] for g in groups]); rng=np.random.default_rng(281482); boot=eff[rng.integers(0,len(eff),size=(10000,len(eff)))].mean(axis=1); ci=np.quantile(boot,[.025,.975],method='linear')
out={'schema':'REVERSOME.GSE281482.FrozenV14PairedTransportResult.v1','protocol_id':p['protocol_id'],'protocol_sha256':sha(P),'parameter_addendum_sha256':sha(B/'protocol/addenda/analysis_parameters_v1.json'),'preflight_sha256':sha(PRE),'independent_preflight_sha256':sha(VER),'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_accession':'GSE281482','training_source':'GSE241468','model_manifest_sha256':sha(M/'manifest_v1.json'),'model_refit':False,'external_feature_selection':False,'external_scaling_fit':False,'all_four_source_matrices_included':len(groups)==4,'sample_results':groups,'summary':{'n_source_matrices':len(groups),'equal_matrix_mean_effect':float(eff.mean()),'median_matrix_effect':float(np.median(eff)),'positive_matrix_count':int(np.sum(eff>0)),'min_matrix_effect':float(eff.min()),'max_matrix_effect':float(eff.max()),'descriptive_sample_resampling_95_percentile_interval':[float(ci[0]),float(ci[1])],'bootstrap_resamples':10000,'no_inferential_p_value_reported':True},'scope':{'interpretation':'Frozen-model same-cell RNA-to-ATAC latent correspondence relative to within-matrix shuffled targets in four public BAL mesenchymal-cell multiome matrices; source-domain-shift challenge.','donor_independence_assumed':False,'clinical_covariates_read':False,'cell_barcodes_or_cell_level_scores_persisted':False,'hospital_expert_or_clinical_records_accessed':False,'restricted_records_accessed':False,'manuscript_or_rebuttal_changed':False,'not_evidence_for':['causality','clinical utility','disease prediction','independent donor-level inference','universal transfer','researcher decision improvement','prospective confirmation']},'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'h5py':h5py.__version__,'slurm_job_id':os.environ.get('SLURM_JOB_ID','direct')}}
O=B/'results/primary_analysis_v1.json';O.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print('SCORE_COMPLETE',out['summary'],'SHA256',sha(O))
