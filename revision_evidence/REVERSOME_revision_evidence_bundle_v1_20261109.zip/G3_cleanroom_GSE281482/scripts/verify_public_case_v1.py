#!/usr/bin/env python3
import hashlib,json,math,os,subprocess,sys,tempfile
from pathlib import Path
B=Path(__file__).resolve().parents[1]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
checks=[]
def ck(name,ok,detail=None):checks.append({'check':name,'passed':bool(ok),'detail':detail})
p=json.load(open(B/'protocol/frozen_protocol_v1.json')); a=json.load(open(B/'protocol/addenda/analysis_parameters_v1.json')); fr=json.load(open(B/'protocol/freeze_receipt_v1.json')); dl=json.load(open(B/'results/download_receipt_v1.json'))
model=json.load(open(B/'model_payload/manifest_v1.json')); result=json.load(open(B/'results/primary_analysis_v1.json')); indep=json.load(open(B/'verification/independent_recompute_v1.json')); pre=json.load(open(B/'verification/preflight_independent_verification_v1.json')); pf=json.load(open(B/'results/object_preflight_v1.json'))
ck('frozen protocol lineage',sha(B/'protocol/frozen_protocol_v1.json')==a['parent_protocol_sha256']==fr['protocol_sha256']==dl['protocol_sha256'])
ck('frozen model manifest',sha(B/'model_payload/manifest_v1.json')==p['model']['manifest_sha256'])
model_files=True
for name,digest in model['files'].items():model_files &= (B/'model_payload'/name).is_file() and sha(B/'model_payload'/name)==digest
ck('all frozen model payload hashes',model_files)
source_ok=True
for item in dl['files']:
 f=B/'data'/item['name']; source_ok &= f.is_file() and f.stat().st_size==item['bytes'] and sha(f)==item['sha256']
ck('all public GEO source files',source_ok)
ck('structural preflight',pf['status']=='PASS_STRUCTURAL_PREFLIGHT' and pre['status']=='PASS' and pre['checks_passed']==pre['checks_total']==8)
ck('independent score recomputation',indep['status']=='PASS' and indep['checks_passed']==indep['checks_total']==18)
rows=result['sample_results']; rows2=indep['recomputed_sample_results']; compare=len(rows)==len(rows2)==4
for x,y in zip(rows,rows2):
 compare &= x['sample_label']==y['sample_label'] and x['n_cells']==y['n_cells']
 for k in ['native_mean_cosine','mean_within_sample_shuffled_cosine','native_minus_shuffled']: compare &= math.isclose(x[k],y[k],rel_tol=0,abs_tol=1e-12)
ck('four matrix statistics independently match',compare)
s=result['summary']; interval=s['descriptive_sample_resampling_95_percentile_interval']
ck('observed outcome classification',s['n_source_matrices']==4 and s['positive_matrix_count']==3 and s['min_matrix_effect']<0 and interval[0]<0<interval[1] and s['no_inferential_p_value_reported'] is True)
contract=json.load(open(B/'decision/claim_contract_v1.json')); manifest=json.load(open(B/'decision/source_manifest_v1.json')); audit=json.load(open(B/'decision/contract_audit_v1.json'))
body={k:v for k,v in audit.items() if k not in {'receipt_sha256','receipt_verified'}}
ck('claim contract preflight receipt',audit['status']=='READY_FOR_PLANNER' and audit['receipt_verified'] is True and hashlib.sha256(canon(body)).hexdigest()==audit['receipt_sha256'] and not audit['audit']['issue_codes'])
for req in contract['requirements']:
 ref=req['provenance']['reference']; ck('requirement source manifest '+req['category'],manifest.get(ref)==req['provenance']['sha256'])
plan=json.load(open(B/'decision/planner_request_v1.json')); pres=json.load(open(B/'decision/planner_result_v1.json'))
expected=['R_ALL_FOUR_SOURCE_MATRICES_POSITIVE','R_DESCRIPTIVE_INTERVAL_EXCLUDES_ZERO']
ck('planner withholds failed broad claim',pres['receipt_verified'] is True and pres['result']['decision']=='WITHHOLD' and pres['result']['reason']=='mandatory_requirement_failed' and pres['result']['failed_requirements']==expected)
# Independent rerun through the installed wheel; compare decision and content receipt.
env=os.environ.copy();env['PYTHONPATH']=str(B/'software/site')
with tempfile.TemporaryDirectory(prefix='reversome_public_case_') as td:
 out=Path(td)/'rerun.json'; cmd=[sys.executable,'-m','reversome.planning.cli_v8','--input',str(B/'decision/planner_request_v1.json'),'--protocol',str(B/'protocol/reversome_v8_milp_residual_cover.yaml'),'--output',str(out)]
 rr=subprocess.run(cmd,env=env,capture_output=True,text=True); same=False
 if rr.returncode==0 and out.exists():
  d=json.load(open(out)); same=d['result']['decision']==pres['result']['decision'] and d['result']['receipt_sha256']==pres['result']['receipt_sha256'] and d['input_sha256']==pres['input_sha256']
ck('independent installed-wheel planner rerun',same,rr.stderr[-300:] if rr.returncode else None)
record=json.load(open(B/'decision/case_record_v1.json'))
ck('boundary and honest case provenance',record['no_hospital_expert_or_clinical_records_accessed'] is True and record['no_manuscript_or_rebuttal_changed'] is True and 'not independent expert adjudication' in record['timing_and_scope'])
out={'schema':'REVERSOME.GSE281482.PublicEndToEndIndependentVerification.v1','status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','checks_passed':sum(x['passed'] for x in checks),'checks_total':len(checks),'checks':checks,'claim_ceiling':'Retrospective analyst-authored public worked example; verifies a frozen-model transport stress test and fail-closed planner disposition. It is not a blinded expert benchmark, confirmatory cohort, proof of population generalization, or researcher-benefit study.','no_hospital_expert_or_clinical_records_accessed':True,'no_manuscript_or_rebuttal_changed':True}
q=B/'verification/public_case_independent_verification_v1.json';q.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],out['checks_passed'],'/',out['checks_total'],sha(q))
if out['status']!='PASS':raise SystemExit(2)
