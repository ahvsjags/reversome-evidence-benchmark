from pathlib import Path
import json,hashlib,datetime,collections,itertools
import numpy as np
E=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation/05_evidence_updates');B=E/'review_gap_breakthrough_v252_20261111';D=B/'matched';protocol=json.load((B/'benchmark/protocol.json').open());wanted=protocol['sampling']['stability_claims'];seeds=[20261111,20261129,20261207];P=['fixed3','source_active','qwen_react_same_tools'];V=['shared_NLI','fresh_Qwen_only','Qwen_NLI_source_consensus'];L=['SUPPORT','CONTRADICT','NOT_ENOUGH_INFO'];gold={str(r['id']):r['evidence'] for r in (json.loads(x) for x in (E/'b3_scifact_open_locked_v1_20261110/keys/claims_key.jsonl').open())};data={};checks={};files=[]
for seed in seeds:
 rr={}
 for p in sorted((D/'runs').glob(f'seed_{seed}_shard_*/*.json')):
  if p.name=='execution_receipt.json':continue
  r=json.load(p.open())
  if r['case_id'] in wanted:rr[r['case_id']]=r;files.append(p)
 assert set(rr)==set(wanted) and len(rr)==32,'Wait for all prespecified stability cases';data[seed]=rr;checks[str(seed)+'_all32_cases']=True
 if seed!=20261111:
  receipts=[json.load(p.open()) for p in (D/'runs').glob(f'seed_{seed}_shard_*/execution_receipt.json')];checks[str(seed)+'_4complete_owned_server_receipts']=len(receipts)==4 and all(r['completed']==8 and r['owned_server_stopped'] for r in receipts)
 for cid,r in rr.items():
  for pol in P:
   z=r['routes'][pol];checks[f'{seed}_{cid}_{pol}_pair_and_doc_integrity']=z['NLI_pairs']==len(z['scored_candidates']) and len(z['read_document_ids'])==len(set(z['read_document_ids'])) and set(x['doc_id'] for x in z['scored_candidates'])<=set(z['read_document_ids'])
def truth(cid):
 labs={x['label'] for x in gold[cid].values()};return next(iter(labs)) if len(labs)==1 else L[-1]
def stats(rows,pol,ver):
 tp=pn=gn=correct=0
 for cid,r in rows.items():
  z=r['routes'][pol];g=gold[cid];pred={k:v for k,v in z['verifier_source_labels'][ver].items() if v!=L[-1]};tp+=sum(k in g and g[k]['label']==v for k,v in pred.items());pn+=len(pred);gn+=len(g);correct+=z['verifier_global_decisions'][ver]==truth(cid)
 return {'ECAP_TP':tp,'predicted_ECAPs':pn,'gold_ECAPs':gn,'ECAP_F1':2*tp/(pn+gn),'claim_accuracy':correct/len(rows)}
metrics={str(seed):{p:{v:stats(data[seed],p,v) for v in V} for p in P} for seed in seeds};stability={}
for p,v in itertools.product(P,V):
 lab={cid:[data[s][cid]['routes'][p]['verifier_global_decisions'][v] for s in seeds] for cid in wanted};unanim=sum(len(set(z))==1 for z in lab.values());stability[p+' | '+v]={'unanimous_cases':unanim,'denominator':32,'unanimous_fraction':unanim/32,'disagreeing_ids':[cid for cid,z in lab.items() if len(set(z))!=1],'pairwise_agreement':{str(a)+'_'+str(b):sum(z[i]==z[j] for z in lab.values())/32 for i,a in enumerate(seeds) for j,b in enumerate(seeds) if i<j}}
allprimary={}
for p in (D/'runs').glob('seed_20261111_shard_*/*.json'):
 if p.name!='execution_receipt.json':r=json.load(p.open());allprimary[r['case_id']]=r
native={'primary96_accuracy':sum(r['routes']['qwen_react_same_tools'].get('native_agent_decision',L[-1])==truth(cid) for cid,r in allprimary.items())/96,'stability32_accuracy_by_seed':{str(s):sum(data[s][cid]['routes']['qwen_react_same_tools'].get('native_agent_decision',L[-1])==truth(cid) for cid in wanted)/32 for s in seeds},'note':'Native ReAct final answer after actual NLI tool feedback, not a no-tool or no-NLI-input baseline.'};check_cleanup={'all_extra_case_outputs':sum(len(data[s]) for s in seeds[1:])==64};checks.update(check_cleanup);out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(checks.values()),'total':len(checks),'checks':checks,'independent_components':32,'seeds':seeds,'additional_stochastic_case_runs':64,'metrics_on_identical32':metrics,'decision_stability':stability,'native_ReAct_final_answer':native,'inference_failure_cases':[{'seed':s,'case_id':cid,'errors':r['errors']} for s,rr in data.items() for cid,r in rr.items() if r['errors']],'output_sha256':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'scope':'Three stochastic model runs on the same32claims, not96independent stability claims. Deterministic acquisition reference and stochastic verification recorded separately. No selection/tuning from these results.'};(D/'independent_stability_score.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['checks','output_sha256','metrics_on_identical32']},indent=2));assert out['status']=='PASS'
