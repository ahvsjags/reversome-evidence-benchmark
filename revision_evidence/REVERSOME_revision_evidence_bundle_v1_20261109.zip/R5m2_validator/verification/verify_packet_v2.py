import json,hashlib,datetime,sys
from pathlib import Path
D=Path(__file__).resolve().parents[1];P=D/'results/evidence_packet_v2.json';p=json.load(open(P));checks=[]
def ck(n,b):checks.append({'check':n,'pass':bool(b)})
for a in p['artifacts']:
 q=Path(a['path']);ck('artifact:'+q.name,q.is_file() and q.stat().st_size==a['bytes'] and hashlib.sha256(q.read_bytes()).hexdigest()==a['sha256'])
u=(D/'logs/unit_tests.log').read_text();v=json.load(open(D/'verification/independent_verification_v2.json'))
ck('23 unit tests',p['checks']['unit_tests']==23 and 'Ran 23 tests' in u and '\nOK' in u)
ck('independent check count',v['status']=='PASS' and v['passed']==16 and p['checks']['independent_verification']=='PASS 16/16')
ck('six CLI negative controls',p['checks']['CLI_negative_controls']==6)
ck('no actual aggregate',p['status']=='IMPLEMENTATION_TESTED_ONLY_AWAITING_AUTHORIZED_AGGREGATE_PACKET' and 'No authorized aggregate' in p['scope'])
ck('restricted data and manuscript untouched',p['no_restricted_records_accessed'] is True and p['no_manuscript_or_rebuttal_modified'] is True)
ck('explicit no gate closure','remain open' in p['result'])
ck('fixture-only release id',json.load(open(D/'fixtures/aggregate_packet_TESTFIXTURE_ONLY.json'))['release_id']=='TESTFIXTURE_ONLY_V0')
ck('unsigned receipt scope','UNSIGNED_HASH_RECEIPT'==json.load(open(D/'fixtures/receipt_TESTFIXTURE_ONLY.json'))['signature_status'])
out={'schema':'REVERSOME.R5m2AggregateReleasePacketVerification.v2','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL','packet_sha256':hashlib.sha256(P.read_bytes()).hexdigest()};q=D/'verification/packet_verification_v2.json';q.write_text(json.dumps(out,indent=2)+'\n');print(out['status'],out['passed'],'/',out['total'],'sha',out['packet_sha256']);[print(x) for x in checks if not x['pass']];sys.exit(0 if out['status']=='PASS' else 1)
