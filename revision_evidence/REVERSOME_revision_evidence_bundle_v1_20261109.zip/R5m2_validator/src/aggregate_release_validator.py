#!/usr/bin/env python3
"""Validate/hash a custodian-supplied aggregate-only release. Never reads individual records."""
import argparse,hashlib,json,re,sys,math
from pathlib import Path
from datetime import datetime
SCHEMA='REVERSOME.ControlledAggregateRelease.v1'; HEX=re.compile(r'^[0-9a-f]{64}$'); TOK=re.compile(r'^[A-Za-z0-9._-]{1,64}$')
TOP={'schema','release_id','scope','privacy_policy','provenance','summary_rows'}
SCOPE={'dataset_class','raw_data_included','source_accession','endpoint_code','analysis_version'}
POL={'minimum_cell_size','suppression_rule'}
PROV={'analysis_code_manifest_sha256','environment_lock_sha256','run_timestamp_utc','producer_role'}
ROW={'metric_code','group_code','n','suppressed','estimate','ci_lower','ci_upper','p_value','denominator'}
DENY={'patient_id','subject_id','specimen_id','case_id','mrn','record_id','barcode','clinical_note','raw_data','individual_records','row_level_data','participant_id'}
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def reject(msg): raise ValueError(msg)
def scan(o,path='$'):
 if isinstance(o,dict):
  for k,v in o.items():
   if str(k).lower() in DENY: reject('forbidden raw/identifier field: '+path+'.'+str(k))
   scan(v,path+'.'+str(k))
 elif isinstance(o,list):
  for i,v in enumerate(o): scan(v,f'{path}[{i}]')
def validate(d):
 if not isinstance(d,dict) or set(d)!=TOP: reject('top-level keys mismatch')
 scan(d)
 if d['schema']!=SCHEMA or not TOK.fullmatch(d['release_id']): reject('schema or release_id invalid')
 s=d['scope']; p=d['privacy_policy']; v=d['provenance']; rows=d['summary_rows']
 if not isinstance(s,dict) or set(s)!=SCOPE or s['dataset_class']!='controlled_aggregate_only' or s['raw_data_included'] is not False: reject('scope invalid or raw data declared')
 if any(not isinstance(s[k],str) or not TOK.fullmatch(s[k]) for k in ('source_accession','endpoint_code','analysis_version')): reject('scope token invalid')
 if not isinstance(p,dict) or set(p)!=POL or not isinstance(p['minimum_cell_size'],int) or isinstance(p['minimum_cell_size'],bool) or p['minimum_cell_size']<2 or p['suppression_rule']!='suppress_all_values_when_n_below_minimum': reject('privacy policy invalid')
 if not isinstance(v,dict) or set(v)!=PROV or any(not isinstance(v[k],str) or not HEX.fullmatch(v[k]) for k in ('analysis_code_manifest_sha256','environment_lock_sha256')): reject('provenance hashes invalid')
 try: datetime.fromisoformat(v['run_timestamp_utc'].replace('Z','+00:00'))
 except Exception: reject('timestamp must be ISO-8601 UTC')
 if not (v['run_timestamp_utc'].endswith('Z') or v['run_timestamp_utc'].endswith('+00:00')) or v['producer_role']!='authorized_data_custodian': reject('provenance role/time invalid')
 if not isinstance(rows,list) or not rows: reject('summary_rows must be nonempty')
 seen=set(); suppressed=0
 for i,r in enumerate(rows):
  if not isinstance(r,dict) or not {'metric_code','group_code','n','suppressed'}<=set(r) or not set(r)<=ROW: reject(f'row {i} schema invalid')
  if not isinstance(r['metric_code'],str) or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,31}',r['metric_code']) or not isinstance(r['group_code'],str) or not re.fullmatch(r'(G[0-9]{1,3}|ALL|COMBINED|SUPPRESSED)',r['group_code']): reject(f'row {i} token invalid')
  key=(r['metric_code'],r['group_code'])
  if key in seen: reject('duplicate metric/group row')
  seen.add(key); n=r['n']; sup=r['suppressed']; m=p['minimum_cell_size']
  if not isinstance(sup,bool): reject('suppressed must be boolean')
  if sup:
   suppressed+=1
   if n is not None or any(k in r for k in ('estimate','ci_lower','ci_upper','p_value','denominator')): reject(f'row {i} suppressed values leaked')
  else:
   if not isinstance(n,int) or isinstance(n,bool) or n<m: reject(f'row {i} unsuppressed below threshold')
   if any(k not in r or not isinstance(r[k],(int,float)) or isinstance(r[k],bool) or not math.isfinite(r[k]) for k in ('estimate','denominator')) or not isinstance(r['denominator'],int) or r['denominator']<n: reject(f'row {i} estimate/denominator invalid')
   if ('ci_lower' in r)!=('ci_upper' in r) or ('ci_lower' in r and (not isinstance(r['ci_lower'],(int,float)) or not isinstance(r['ci_upper'],(int,float)) or not math.isfinite(r['ci_lower']) or not math.isfinite(r['ci_upper']) or r['ci_lower']>r['ci_upper'])): reject(f'row {i} interval invalid')
   if 'p_value' in r and (not isinstance(r['p_value'],(int,float)) or not math.isfinite(r['p_value']) or not 0<=r['p_value']<=1): reject(f'row {i} p_value invalid')
 return {'rows':len(rows),'suppressed':suppressed,'reported':len(rows)-suppressed,'minimum_cell_size':p['minimum_cell_size']}
def code_manifest(path,root):
 d=json.load(open(path,encoding='utf-8'))
 if set(d)!={'schema','files'} or d['schema']!='REVERSOME.CodeHashManifest.v1' or not isinstance(d['files'],list) or not d['files']: reject('code manifest invalid')
 root=Path(root).resolve(); out=[]
 for e in d['files']:
  if set(e)!={'relative_path','sha256'} or not HEX.fullmatch(e['sha256']): reject('manifest entry invalid')
  q=(root/e['relative_path']).resolve()
  if root not in q.parents or not q.is_file() or digest(q)!=e['sha256']: reject('code path/hash invalid')
  out.append({'relative_path':e['relative_path'],'sha256':e['sha256'],'bytes':q.stat().st_size})
 return {'files':out,'manifest_sha256':digest(path)}
def main():
 a=argparse.ArgumentParser();
 for name in ('aggregate-json','code-manifest','code-root','environment-lock','output'): a.add_argument('--'+name,required=True)
 x=a.parse_args()
 try:
  d=json.load(open(x.aggregate_json,encoding='utf-8')); counts=validate(d); cm=code_manifest(x.code_manifest,x.code_root); env=Path(x.environment_lock).resolve()
  outpath=Path(x.output).resolve(); root=Path(x.code_root).resolve(); protected={Path(x.aggregate_json).resolve(),Path(x.code_manifest).resolve(),env}
  protected.update((root/e['relative_path']).resolve() for e in json.load(open(x.code_manifest,encoding='utf-8'))['files'])
  if outpath in protected or root in outpath.parents: reject('output path would overwrite an input/code artifact or reside inside code root')
  if not env.is_file() or digest(env)!=d['provenance']['environment_lock_sha256'] or cm['manifest_sha256']!=d['provenance']['analysis_code_manifest_sha256']: reject('provenance hash mismatch')
  receipt={'schema':'REVERSOME.AggregateReleaseReceipt.v1','release_id':d['release_id'],'packet_sha256':digest(x.aggregate_json),'canonical_packet_sha256':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),'code_manifest':cm,'environment_lock_sha256':digest(env),'privacy_policy':d['privacy_policy'],'aggregate_row_counts':counts,'raw_data_included':False,'signature_status':'UNSIGNED_HASH_RECEIPT','validation_status':'STRUCTURE_AND_HASH_CHECKS_PASS_NOT_PRIVACY_OR_ETHICS_CERTIFICATION'}
  outpath.parent.mkdir(parents=True,exist_ok=True);tmp=outpath.with_name(outpath.name+'.tmp');tmp.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8');tmp.replace(outpath);print(json.dumps({'status':'PASS_STRUCTURE_AND_HASH_ONLY','release_id':d['release_id'],'receipt_sha256':digest(x.output)}));return 0
 except Exception as e: print(json.dumps({'status':'REJECTED','reason':str(e)}),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
