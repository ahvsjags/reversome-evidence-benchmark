# GSE281482 public end-to-end REVERSOME case

This is a reproducible, post-result public-data worked example built from the frozen V14 model trained on GSE241468 and four public human lung multiome matrices in GEO GSE281482. The frozen model is applied without refitting, feature reselection or external scaling fit. The analysis pairs RNA and ATAC by the exact shared 10x barcode within each source matrix; its negative control permutes ATAC targets within the same matrix.

## Re-run on IBEX

Use Python 3.9.18 with `numpy==2.0.2`, `scipy==1.13.1`, `h5py==3.14.0` (plus the bundled wheel's runtime requirements). From this directory run:

```bash
bash run_public_case.sh
```

The script fetches four GEO files from the official NCBI GEO FTP endpoints if missing, verifies each file's byte count and SHA-256, performs structural preflight, scores all eligible matrices, independently recomputes the statistics, checks the human-authored claim contract against a hash-pinned source manifest, invokes the installed REVERSOME wheel's V9 contract audit and V8 evidence planner, and verifies the final receipts. No clinical covariates, hospital data, expert records or restricted records are used. The four H5 files total approximately 873 MB; no cell-level scores or barcodes are retained in result JSON.

## Result

Three of four source-matrix effects were positive. The equal-matrix mean native-minus-shuffled cosine was 0.03013; the fourth matrix effect was −0.01669. The descriptive four-matrix resampling interval was [−0.00196, 0.05489]. No inferential p-value is reported and donor independence is not assumed. The V8 planner therefore returns **WITHHOLD** for the worked-example claim that all four matrices show positive correspondence; it reports the two failed predicates (all-four-positive and interval-excludes-zero). This is a conservative, executable disposition—not a claim that REVERSOME improves researchers' decisions.

## Provenance and scope

- Frozen V14 model and analysis protocol are hash-bound in `protocol/frozen_protocol_v1.json` and `protocol/freeze_receipt_v1.json`.
- Public source hashes and URLs are in `protocol/download_receipt_v1.json`.
- Sample-level results and the independent 18-check recomputation are in `results/primary_analysis_v1.json` and `verification/independent_recompute_v1.json`.
- The claim contract is analyst-authored retrospectively after seeing the public-source result. It is not expert-adjudicated, prospectively preregistered or a blind confirmatory cohort.
- `READY_FOR_PLANNER` means only that the structured claim contract passed the registered completeness/provenance preflight. The V8 planner's `WITHHOLD` is the case disposition for the stated claim; neither status establishes broad scientific accuracy or population generalization.
- This source is a post-transplant BAL/culture-expanded mesenchymal-cell domain-shift challenge, not a replication of native lung tissue. Donor independence is not inferred from matrix labels.

Official source: [GEO GSE281482](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE281482); source article: [JCI Insight](https://pmc.ncbi.nlm.nih.gov/articles/PMC13460852/).
