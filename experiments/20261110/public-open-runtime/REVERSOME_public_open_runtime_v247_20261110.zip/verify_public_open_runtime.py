"""Audit released predictions; this does not run new neural inference.

Python standard library only. Read annotations from the original public archive,
not from an author-written answer sheet. No clinical/private source is required.
"""
from pathlib import Path
import argparse,json,hashlib,gzip,tarfile,urllib.request,statistics
A=argparse.ArgumentParser();A.add_argument('--bundle-dir',required=True);A.add_argument('--archive');A.add_argument('--output');a=A.parse_args();B=Path(a.bundle_dir)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=json.load((B/'manifest.json').open());checks={}
for n,h in manifest['files'].items():checks['sha_'+n]=sha(B/n)==h
arc=Path(a.archive) if a.archive else B/'scifact_open.tar.gz'
if not arc.exists():urllib.request.urlretrieve('https://scifact.s3.us-west-2.amazonaws.com/scifact-open/latest/scifact_open.tar.gz',arc)
checks['official_archive_sha256']=sha(arc)=='8f4dc238b2eff422bab5c7918fcbddb6996b29d37cb887942ef6ee1a16fb3415'
with tarfile.open(arc,'r:gz') as tar:
 names=[x for x in tar.getnames() if x.endswith('/claims.jsonl') or x=='claims.jsonl'];assert len(names)==1,names
 allkeys={str(r['id']):r for r in map(json.loads,tar.extractfile(names[0]))}
reference=json.load((B/'scientific_reference.json').open());execution=json.load((B/'execution_freeze.json').open());POL=['fixed1','fixed3','fixed20','source_fixed_all','source_active'];out={}
def label(xs):
 support=any(x['prob_support']>=.7 and x['prob_support']-x['prob_neutral']>=.2 and x['prob_support']-x['prob_contradict']>=.1 for x in xs)
 contra=any(x['prob_contradict']>=.7 and x['prob_contradict']-x['prob_neutral']>=.2 and x['prob_contradict']-x['prob_support']>=.1 for x in xs)
 return 'NOT_ENOUGH_INFO' if support==contra else 'SUPPORT' if support else 'CONTRADICT'
for repeat in range(3):
 with gzip.open(B/f'predictions_repeat_{repeat}.jsonl.gz','rt') as f:rows=[json.loads(x) for x in f]
 checks[f'r{repeat}_frozen278claim_ids']=len(rows)==len({r['case_id'] for r in rows})==278 and set(r['case_id'] for r in rows)==set(reference['case_ids'])
 for pol in POL:
  TP=pred=gold=pairs=0;valid=True
  for row in rows:
   z=row['routes'][pol];xs=z['scored_candidates'];valid &= label(xs)==z['label'] and len(xs)==z['NLI_pairs'];pairs+=len(xs);evidence=allkeys[row['case_id']]['evidence'];gold+=len(evidence)
   for did in {x['doc_id'] for x in xs}:
    decision=label([x for x in xs if x['doc_id']==did])
    if decision!='NOT_ENOUGH_INFO':pred+=1;TP+=did in evidence and evidence[did]['label']==decision
  actual={'ECAP_TP':TP,'predicted_ECAPs':pred,'gold_ECAPs':gold,'ECAP_F1':2*TP/(pred+gold),'NLI_pairs':pairs};ref=reference['metrics'][pol]
  checks[f'r{repeat}_{pol}_scientific_metrics']=all(abs(actual[k]-ref[k])<1e-12 for k in ['ECAP_TP','predicted_ECAPs','gold_ECAPs','ECAP_F1'])
  checks[f'r{repeat}_{pol}_all_guards']=valid
  t=next(x for x in execution['timings'] if x['repeat']==repeat and x['policy']==pol)
  checks[f'r{repeat}_{pol}_workload_cost']=pairs==t['logical_NLI_pairs']<=t['actual_NLI_pairs_including_numeric_fallbacks'] and t['wall_seconds']>0 and t['CPU_seconds']>0
  out[f'{repeat}_{pol}']=actual
warm={pol:{k:statistics.median(t[k] for t in execution['timings'] if t['policy']==pol) for k in ['wall_seconds','CPU_seconds']} for pol in POL};fixed=warm['fixed3'];active=warm['source_active'];savings={k:1-active[k]/fixed[k] for k in fixed};checks['positive_warm_measured_cost_improvement']=all(v>0 for v in savings.values())
diag=json.load((B/'same_hardware_diagnostic_summary.json').open());checks['same_hardware_checks_passed']=diag['status']=='PASS' and diag['passed']==diag['total']==4396;checks['strict_cross_platform_failure_not_hidden']=diag['strict_cross_machine_reproduction_status_retained']=='FAIL'
result={'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(checks.values()),'total':len(checks),'checks':checks,'metrics':out,'warm_medians':warm,'warm_savings_vs_fixed3':savings,'scope':'Numerical replay of archived actual neural outputs and timings, not new neural inference, independent expert review, universal active-policy superiority, or OS-cold speedup. ECAP scores use incomplete pooled published annotations; unannotated evidence is unverified, not proven false.'}
outpath=Path(a.output) if a.output else B/'public_verification.json';outpath.write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['checks','metrics']},indent=2));assert all(checks.values()),[k for k,v in checks.items() if not v]
