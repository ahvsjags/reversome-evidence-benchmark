"""Separate graph/BFS and independent metric implementation for source audit."""
from pathlib import Path
from collections import defaultdict,deque
import json,hashlib,tarfile,datetime
import numpy as np
import argparse,gzip
A=argparse.ArgumentParser();A.add_argument('--audit-dir',required=True);A.add_argument('--runtime-dir',required=True);A.add_argument('--archive',required=True);args=A.parse_args();B=Path(args.audit_dir);V=Path(args.runtime_dir);read=lambda p:[json.loads(x) for x in p.open() if x.strip()];d=json.load((B/'source_unit_robustness_v1.json').open());parts=json.load((B/'component_case_ids.json').open());pred={r['case_id']:r for r in map(json.loads,gzip.open(V/'predictions_repeat_0.jsonl.gz','rt'))};ids=set(pred)
assert hashlib.sha256(Path(args.archive).read_bytes()).hexdigest()=='8f4dc238b2eff422bab5c7918fcbddb6996b29d37cb887942ef6ee1a16fb3415'
manifest=json.load((B/'manifest.json').open());assert all(hashlib.sha256((B/n).read_bytes()).hexdigest()==h for n,h in manifest['files'].items())
with tarfile.open(args.archive,'r:gz') as t:
 get=lambda suffix:t.extractfile(next(n for n in t.getnames() if n.endswith(suffix)))
 official={str(x['id']):x for x in map(json.loads,get('claims.jsonl'))};metadata={str(x['id']):x for x in map(json.loads,get('claims_metadata.jsonl'))}
source_memberships=json.load((B/'source_membership_sets.json').open());seen=set().union(*map(set,source_memberships.values()));unseen={cid for cid in ids if not(set(official[cid]['evidence'])&seen)};adj={cid:set() for cid in ids};buckets=defaultdict(set)
for cid in ids:
 buckets[('origin',str(metadata[cid]['source_doc_id']))].add(cid)
 for did in official[cid]['evidence']:buckets[('evidence',did)].add(cid)
for members in buckets.values():
 for cid in members:adj[cid].update(members-{cid})
remaining=set(ids);bfs=[]
while remaining:
 start=min(remaining);todo=deque([start]);found={start};remaining.remove(start)
 while todo:
  cid=todo.popleft()
  for nxt in adj[cid]-found:found.add(nxt);remaining.discard(nxt);todo.append(nxt)
 bfs.append(found)
POL=['fixed1','fixed3','fixed20','source_fixed_all','source_active'];counts={p:{} for p in POL}
for p in POL:
 for cid,r in pred.items():
  bydoc=defaultdict(list)
  for x in r['routes'][p]['scored_candidates']:bydoc[x['doc_id']].append(x)
  selected={}
  for did,xs in bydoc.items():
   flags=[]
   for target,opposite in [('prob_support','prob_contradict'),('prob_contradict','prob_support')]:flags.append(any(x[target]>=.7 and x[target]-x['prob_neutral']>=.2 and x[target]-x[opposite]>=.1 for x in xs))
   if flags==[True,False]:selected[did]='SUPPORT'
   if flags==[False,True]:selected[did]='CONTRADICT'
  gold=official[cid]['evidence'];counts[p][cid]=np.asarray([sum(did in gold and gold[did]['label']==label for did,label in selected.items()),len(selected),len(gold)])
checks={'all_official278_claims':len(ids)==278 and ids<=set(official),'connected_components_BFS_independent_match':{frozenset(x) for x in bfs}=={frozenset(x) for x in parts},'224_source_components':len(bfs)==d['origin_or_gold_evidence_connected_components']==224,'230_origin_papers':len({metadata[cid]['source_doc_id'] for cid in ids})==d['unique_originating_papers']==230,'159_all_gold_source_unseen_claims':len(unseen)==d['all_annotated_gold_sources_unseen_in_fit_and_calibration']['claims']==159,'75_NLI_seen_claims':sum(bool(set(official[cid]['evidence'])&set(source_memberships['NLI_labelled_training_evidence'])) for cid in ids)==d['claims_with_any_gold_evidence_in_NLI_labelled_training_sources']==75}
for p in POL:
 s=sum((counts[p][cid] for cid in unseen),np.zeros(3,int));ref=d['all_annotated_gold_sources_unseen_in_fit_and_calibration']['metrics'][p];checks[p+'_unseen_metrics_independent']=list(map(int,s))==[ref['TP'],ref['predicted'],ref['gold']] and abs(2*s[0]/(s[1]+s[2])-ref['ECAP_F1'])<1e-12
group={p:np.asarray([sum((counts[p][cid] for cid in members),np.zeros(3,int)) for members in parts]) for p in POL};rng=np.random.default_rng(20261110);diff={p:[] for p in POL if p!='source_active'}
for _ in range(5000):
 draws=rng.integers(0,len(parts),len(parts));ss={p:z[draws].sum(0) for p,z in group.items()};af=2*ss['source_active'][0]/(ss['source_active'][1]+ss['source_active'][2])
 for p in diff:diff[p].append(af-2*ss[p][0]/(ss[p][1]+ss[p][2]))
for p,v in diff.items():checks[p+'_cluster_CI_recompute']=np.allclose(np.quantile(v,[.025,.975]),d['source_cluster_bootstrap5000_active_minus_fixed_ECAP_F1_95CI'][p],atol=1e-14,rtol=0)
out={'schema':'REVERSOME.B3.SourceUnitRobustnessIndependentAudit.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'source_membership_sha256':hashlib.sha256((B/'source_membership_sets.json').read_bytes()).hexdigest(),'scope':'Independent computational reconstruction using original public archive, distinct BFS grouping and metric implementation; post-hoc robustness, not human adjudication or a new test.'};(B/'public_source_unit_verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert all(checks.values())
