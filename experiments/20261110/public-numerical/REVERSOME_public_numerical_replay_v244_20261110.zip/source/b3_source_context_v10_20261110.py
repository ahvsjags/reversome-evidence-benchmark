"""Context-aware source acquisition, anchored to the calibration-best fixed route."""
from pathlib import Path
import json,pickle,hashlib,datetime,time,sys,importlib.util,collections
import numpy as np
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';B=E/'b3_source_context_v10_20261110';P=E/'b3_sourceheldout_utility_v3_20261110';V=E/'b3_incremental_sourceguard_v6_20261110';C=E/'b3_frozen_context_adapter_v8_1_20261110';O=E/'b3_scifact_open_locked_v1_20261110'
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
v=load('v6',E/'b3_incremental_sourceguard_v6_20261110.py');encmod=load('context',E/'b3_frozen_context_adapter_v8_1_20261110.py');openmod=load('openruntime',E/'run_scifact_open_locked_v1_20261110.py');L=encmod.L;POL=['fixed1','fixed3','fixed20','source_fixed_all','source_active']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return [json.loads(s) for s in Path(p).open() if s.strip()]
def put(p,d):
 with Path(p).open('x') as f:json.dump(d,f,indent=2)
def write(p,rows):
 with Path(p).open('x') as f:
  for r in rows:f.write(json.dumps(r)+'\n')
def doclabel(x,t,m):
 p=x['probabilities'];i=int(np.argmax(p));return L[i] if i!=1 and p[i]>=t and p[i]-max(p[j] for j in range(3) if j!=i)>=m else 'NOT_ENOUGH_INFO'
def decide(xs,t,m):
 states={doclabel(x,t,m) for x in xs};s='SUPPORT' in states;c='CONTRADICT' in states
 return 'NOT_ENOUGH_INFO' if s==c else 'SUPPORT' if s else 'CONTRADICT'
def replay(xs,scores,n,cut,t,m,early=True):
 current=[x for x in xs if x['rank']<=n];d=decide(current,t,m)
 if early and d!='NOT_ENOUGH_INFO':return d,len(current)
 for did in sorted({x['doc_id'] for x in xs if x['rank']>n and scores[x['doc_id']]>=cut},key=lambda k:(-scores[k],k)):
  current.extend(x for x in xs if x['doc_id']==did);d=decide(current,t,m)
  if early and d!='NOT_ENOUGH_INFO':break
 return d,len(current)
def setup():
 B.mkdir(exist_ok=False)
 for n in ['protocol','results']:(B/n).mkdir()
 proto={'schema':'REVERSOME.B3.SourceContextPlanning.v10','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rationale':['V6 source selection limits irrelevant-document poisoning, but its initial depth1 does not guarantee retention relative to fixed3. Anchor active acquisition to the official-calibration-best fixed route rather than a cheaper weaker baseline.','The HealthVer context upgrade showed that sentence-only verification loses cross-sentence information. Use the frozen V8.1 full-source encoder/head for all arms, without any new test-label model fitting.'],'frozen_head_sha256':sha(C/'models/domain_adapter_v8_1.pkl'),'frozen_encoder_sha256':sha(encmod.BASE/'model.safetensors'),'source_model_sha256':sha(V/'models_v6.pkl'),'code_sha256':sha(__file__),'guard_calibration':'Only cited documents of204 source-disjoint SciFact calibration claims have official document labels. Select confidence in [.34,.5,.6,.7,.8,.9,.95] and posterior margin[0,.1,.2] by highest3-class document BA, tie larger confidence then margin. Never label uncited training/calibration docs scientifically negative.','anchor':'Choose depth1/3/20 by highest claim-level calibration BA, tie fewer documents. All5 arms share one frozen context verifier and decision guard.','active_calibration':'Source threshold grid[0,.2,.4,.6,.8,.85,.9,.95,.97,.99,1.01]. Must meet or exceed strong fixed BA and true-support retention and not increase false-release fraction on204 calibration claims. Max BA, tie fewer document checks. If no feasible gain or equal-quality dominated cost, use strong-fixed fallback.','safety_mechanism':'Keep all initial strong-fixed evidence and stop if resolved. Additional checks occur only from initially unresolved states; therefore already supported true findings are preserved by construction. Unknown may still become wrong; report errors and FPR/FDR separately.','fresh_evaluation':'All exact-disjoint SciFact-Open claims and full500K corpus, same frozen original lexical transforms as preregistered V6 transport. Both V6 and V10 candidates are reported; no choice of winning model based on test results.','policies':POL,'unit':'Claims conditional on a fixed corpus; not studies, human judges or improved researcher judgments.','no_hospital_records':True,'open_predictions_present_at_freeze':(O/'results/predictions_v1.jsonl').exists()};put(B/'protocol/protocol_v10.json',proto);print(json.dumps(proto,indent=2))
def encoder():
 e=encmod.Encoder();e.head=pickle.load((C/'models/domain_adapter_v8_1.pkl').open('rb'));e.mode='adapted';return e
def calibration():
 proto=json.load((B/'protocol/protocol_v10.json').open());assert sha(__file__)==proto['code_sha256'];lex=v.Lexical();e=encoder();artifact=pickle.load((V/'models_v6.pkl').open('rb'));claims=read(P/'inputs/calibration_claims_label_free.jsonl');keys={r['case_id']:r for r in read(P/'inputs/calibration_scoring_key.jsonl')};raw={str(r['id']):r for r in read(E/'b3_scifact_supervised_nli_dev_v2_dedup_20261110/inputs/claims_train.jsonl')};out=[];annotated=[]
 for i,r in enumerate(claims):
  fs=lex.features(r['claim']);scores=dict(zip(fs,map(float,artifact['source_model'].predict_proba(np.stack(list(fs.values())))[:,1])));docids=list(fs);rows=[{'case_id':r['case_id']+'|'+did,'claim':r['claim'],'sentences':lex.docs[lex.index[did]]['abstract']} for did in docids];sc=[]
  for a in range(0,len(rows),16):
   X,tok,idx=e.embed(rows[a:a+16]);pp=e.head.predict_proba(X);pp=pp[:,[list(e.head.classes_).index(k) for k in L]]
   for j,p in enumerate(pp):sc.append({'doc_id':docids[a+j],'rank':a+j+1,'probabilities':p.tolist(),'tokens':tok[j]})
  item=raw[r['case_id']];ev=item.get('evidence',{})
  for did in item.get('cited_doc_ids',[]):
   did=str(did)
   if did not in lex.index:continue
   cand=next((z for z in sc if z['doc_id']==did),None)
   if cand is None:
    rr={'case_id':r['case_id']+'|'+did,'claim':r['claim'],'sentences':lex.docs[lex.index[did]]['abstract']};s=e.predict(rr);cand={'doc_id':did,'probabilities':s['probabilities'],'tokens':s['tokens']}
   labels={z['label'] for z in ev.get(did,[])};assert len(labels)<=1;annotated.append({'case_id':r['case_id'],'doc_id':did,'label':next(iter(labels)) if labels else 'NOT_ENOUGH_INFO','state':cand})
  out.append({'case_id':r['case_id'],'label':keys[r['case_id']]['label'],'source_scores':scores,'documents':sc})
  if (i+1)%25==0:print('SOURCE_CONTEXT_CAL',i+1,len(claims),flush=True)
 write(B/'results/calibration_contexts_v10.jsonl',out);write(B/'results/annotated_document_calibration_v10.jsonl',annotated);candidates=[]
 for t in [.34,.5,.6,.7,.8,.9,.95]:
  for margin in [0,.1,.2]:
   q=encmod.quality([r['label'] for r in annotated],[doclabel(r['state'],t,margin) for r in annotated]);q.update(confidence=t,margin=margin);candidates.append(q)
 guard=max(candidates,key=lambda q:(q['BA'],q['confidence'],q['margin']));t=guard['confidence'];margin=guard['margin'];y=[r['label'] for r in out];fixed={n:encmod.quality(y,[decide([s for s in r['documents'] if s['rank']<=n],t,margin) for r in out]) for n in [1,3,20]};n=max([1,3,20],key=lambda k:(fixed[k]['BA'],-k));base=fixed[n];options=[]
 for cut in [0,.2,.4,.6,.8,.85,.9,.95,.97,.99,1.01]:
  z=[replay(r['documents'],r['source_scores'],n,cut,t,margin) for r in out];q=encmod.quality(y,[s[0] for s in z]);q.update(source_threshold=cut,document_checks=sum(s[1] for s in z),feasible=q['BA']>=base['BA']-1e-12 and q['FDR']<=base['FDR']+1e-12 and q['retention']>=base['retention']-1e-12);options.append(q)
 feasible=[r for r in options if r['feasible']];best=max(feasible,key=lambda q:(q['BA'],-q['document_checks'])) if feasible else None
 if best and best['BA']<=base['BA']+1e-12:best=None
 rec={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_sha256':sha(__file__),'guard_candidates':candidates,'guard':guard,'fixed':fixed,'initial_depth':n,'candidates':options,'selected':best,'fallback':best is None,'calibration_claims':len(out),'annotated_cited_documents':len(annotated),'calibration_sha256':sha(B/'results/calibration_contexts_v10.jsonl'),'no_external_keys_opened':True};put(B/'results/policy_freeze_v10.json',rec);print(json.dumps({k:rec[k] for k in ['guard','fixed','initial_depth','selected','fallback']},indent=2))
def live():
 rec=json.load((B/'results/policy_freeze_v10.json').open());assert rec['code_sha256']==sha(__file__);run=openmod.OpenRuntime();e=encoder();artifact=pickle.load((V/'models_v6.pkl').open('rb'));rows=read(O/'inputs/claims_label_free.jsonl');t=rec['guard']['confidence'];margin=rec['guard']['margin'];n=rec['initial_depth'];cut=rec['selected']['source_threshold'] if rec['selected'] else 1.01;out=[]
 def infer(ids,claim):
  rr=[{'case_id':did,'claim':claim,'sentences':run.docs[run.index[did]]['abstract']} for did in ids];sc=[]
  for a in range(0,len(rr),16):
   X,tok,idx=e.embed(rr[a:a+16]);pp=e.head.predict_proba(X);pp=pp[:,[list(e.head.classes_).index(k) for k in L]]
   for j,p in enumerate(pp):sc.append({'doc_id':ids[a+j],'probabilities':p.tolist(),'tokens':tok[j]})
  return sc
 for i,r in enumerate(rows):
  routes={};order=POL[i%5:]+POL[:i%5]
  for policy in order:
   wt=time.perf_counter();ct=time.process_time();c,fs=run.retrieve(r['claim']);ids=list(fs);scores={}
   if policy.startswith('source_'):scores=dict(zip(fs,map(float,artifact['source_model'].predict_proba(np.stack(list(fs.values())))[:,1])))
   depth=1 if policy=='fixed1' else 3 if policy=='fixed3' else 20 if policy=='fixed20' else n;sc=infer(ids[:depth],r['claim']);d=decide(sc,t,margin);trace=[{'action':'initial_fixed','depth':depth,'doc_ids':ids[:depth],'document_checks':len(sc),'label':d}]
   if not rec['fallback'] and (policy=='source_fixed_all' or policy=='source_active' and d=='NOT_ENOUGH_INFO'):
    extra=sorted([did for did in ids[depth:] if scores[did]>=cut],key=lambda k:(-scores[k],k))
    for did in extra:
     sc+=infer([did],r['claim']);d=decide(sc,t,margin);trace.append({'action':'source_aligned_check','doc_ids':[did],'document_checks':1,'source_score':scores[did],'label':d})
     if policy=='source_active' and d!='NOT_ENOUGH_INFO':break
   routes[policy]={'label':d,'document_checks':len(sc),'tokens':sum(z['tokens'] for z in sc),'wall_seconds':time.perf_counter()-wt,'CPU_seconds':time.process_time()-ct,'trace':trace,'documents':sc,'source_scores':scores}
  out.append({'case_id':r['case_id'],'execution_order':order,'routes':routes})
  if (i+1)%25==0:print('SOURCE_CONTEXT_OPEN',i+1,len(rows),flush=True)
 write(B/'results/open_predictions_v10.jsonl',out);put(B/'results/open_prediction_freeze_v10.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prediction_sha256':sha(B/'results/open_predictions_v10.jsonl'),'claims':len(out),'corpus':len(run.ids),'scoring_keys_opened':False})
if __name__=='__main__':{'setup':setup,'calibration':calibration,'live':live}[sys.argv[1]]()
