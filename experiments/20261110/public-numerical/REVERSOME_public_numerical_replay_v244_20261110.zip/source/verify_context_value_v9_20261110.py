"""Independently verify frozen-controller selection, actual actions and results."""
from pathlib import Path
import json,hashlib,datetime,math,collections
import numpy as np
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';B=E/'b3_learned_context_value_v9_20261110';P=E/'b3_context_verifier_v7_20261110';V=E/'b3_frozen_context_adapter_v8_1_20261110';L=['SUPPORT','NOT_ENOUGH_INFO','CONTRADICT'];POL=['fixed2','fixed6','fixed_full','confidence_active','learned_active','random_active']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:[json.loads(s) for s in Path(p).open() if s.strip()]
proto=json.load((B/'protocol/protocol_v9.json').open());freeze=json.load((B/'results/controller_freeze_v9.json').open());parent=json.load((V/'results/policy_freeze_v8_1.json').open());checks={'runtime_hash':sha(E/'b3_learned_context_value_v9_20261110.py')==proto['runtime_code_sha256']==freeze['runtime_code_sha256'],'controller_hash':sha(B/'models/controllers_v9.pkl')==freeze['controllers_sha256'],'head_unchanged':sha(V/'models/domain_adapter_v8_1.pkl')==freeze['head_sha256'],'parent_policy_hash':sha(V/'results/policy_freeze_v8_1.json')==freeze['parent_policy_sha256'],'no_test_scores_at_freeze':not any(proto['v8_external_score_files_present_at_freeze'].values()),'future_outcome_invariance_control':freeze['negative_control_future_outcome_invariance'],'decoder_unchanged':freeze['decoder']==parent['decoder']}
for mode in ['lexical','random']:
 fit=freeze['fits'][mode];base=fit['baseline'];feasible=[]
 for c in fit['candidates']:
  ok=c['BA']>=base['BA']-1e-12 and c['FDR']<=base['FDR']+1e-12 and c['retention']>=base['retention']-1e-12
  checks[f'{mode}_risk{c["risk_lambda"]}_cost{c["cost_price"]}_feasibility']=c['feasible']==ok
  if ok:feasible.append(c)
 checks[mode+'_all20_candidates_retained']=len(fit['candidates'])==20
 # Both live candidates selected fixed-full fallback; explicitly check that the
 # fallback is required by all20 infeasible OOF candidates, not test outcomes.
 checks[mode+'_fallback_matches_calibration']=not feasible and fit['selected'] is None and fit['fallback']
results={}
def metric(y,h):
 cm=np.zeros((3,3),int)
 for a,b in zip(y,h):cm[L.index(a),L.index(b)]+=1
 n=int(cm[:,0].sum());present=cm.sum(1)>0
 return {'accuracy':float(cm.trace()/cm.sum()),'BA':float(np.mean(cm.diagonal()[present]/cm.sum(1)[present])),'FDR':float((n-cm[0,0])/n) if n else 1.,'retention':float(cm[0,0]/cm[0].sum()) if cm[0].sum() else None,'support_n':n,'false_support_n':int(n-cm[0,0]),'CM':cm.tolist()}
for name in ['healthver_test','covidfact_test']:
 rows=read(B/'results'/f'{name}_predictions_v9.jsonl');inputs={r['case_id']:r for r in read(P/'inputs'/f'{name}_label_free.jsonl')};keys={r['case_id']:r for r in read(P/'keys'/f'{name}.jsonl')};score=json.load((B/'results'/f'{name}_score_v9.json').open());pf=json.load((B/'results'/f'{name}_prediction_freeze_v9.json').open());checks[name+'_all_pairs']=len(rows)==len(inputs)==len(keys)==len({r['case_id'] for r in rows});checks[name+'_prediction_hash']=sha(B/'results'/f'{name}_predictions_v9.jsonl')==pf['prediction_sha256']==score['prediction_sha256'];checks[name+'_selection_precedes_predictions']=freeze['created_utc']<pf['created_utc'];y=[keys[r['case_id']]['label'] for r in rows];out={}
 for pol in POL:
  met=metric(y,[r['routes'][pol]['label'] for r in rows]);out[pol]=met
  checks[name+'_'+pol+'_metrics']=all(score['metrics'][pol][k]==val if val is None or isinstance(val,(int,list)) else math.isclose(score['metrics'][pol][k],val,abs_tol=1e-12) for k,val in met.items())
  checks[name+'_'+pol+'_costs']=all(math.isclose(score['metrics'][pol][k],sum(r['routes'][pol][k] for r in rows),abs_tol=1e-8) for k in ['wall_seconds','CPU_seconds','tokens','neural_calls'])
  expected_mode=pol if pol.startswith('fixed') else parent['strong_fixed'];n=2 if expected_mode=='fixed2' else 6 if expected_mode=='fixed6' else None;valid=True
  for r in rows:
   case=inputs[r['case_id']];z=r['routes'][pol];tr=z['trace'];valid &= len(tr)==z['neural_calls']==1 and z['tokens']==tr[0]['tokens'] and z['label']==tr[0]['label'] and z['predicted_continuation_value'] is None
   valid &= L[int(np.argmax(tr[0]['probabilities']))]==tr[0]['label'] and tr[0]['decoder']==freeze['decoder'] and math.isclose(sum(tr[0]['probabilities']),1,abs_tol=1e-6)
   if n is None:valid &= tr[0]['sentence_indices']==list(range(len(case['sentences'])))
   else:valid &= len(tr[0]['sentence_indices'])==min(n,len(case['sentences']))
  checks[name+'_'+pol+'_actual_actions_and_explicit_fallback']=bool(valid)
 checks[name+'_all_fallback_decisions_match_full']=all(r['routes'][p]['label']==r['routes']['fixed_full']['label'] for r in rows for p in POL[3:])
 groups={}
 for i,r in enumerate(rows):groups.setdefault(r['claim_group'],[]).append(i)
 groups=list(groups.values());mat=np.array([[np.mean([rows[i]['routes'][p]['label']==y[i] for i in ix]) for p in POL] for ix in groups]);rng=np.random.default_rng(20261110);boot=np.array([mat[rng.integers(0,len(groups),len(groups))].mean(0) for _ in range(2000)]);ci={p:np.quantile(boot[:,4]-boot[:,j],[.025,.975]).tolist() for j,p in enumerate(POL) if p!='learned_active'};checks[name+'_claim_bootstrap']=all(np.allclose(ci[p],score['paired_claim_accuracy_difference95CI'][p],atol=1e-12,rtol=0) for p in ci);results[name]={'pairs':len(rows),'claims':len(groups),'metrics':out,'fallback_equals_fixed_full':checks[name+'_all_fallback_decisions_match_full']}
out={'schema':'REVERSOME.B3.ContextValueIndependentAudit.v9','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'results':results,'scope':'Computational verification; no active-policy superiority demonstrated by fixed-full fallback. No human/clinical expert data.'}
with (B/'results/independent_verification_v9.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','results']},indent=2));assert all(checks.values()),[k for k,v in checks.items() if not v]
