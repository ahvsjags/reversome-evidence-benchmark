"""Public frozen-model inference + matched-control reconstruction (NumPy only)."""
from pathlib import Path
import argparse,json,gzip,csv,hashlib,importlib.util,itertools
import numpy as np
A=argparse.ArgumentParser();A.add_argument('--bundle-dir',required=True);A.add_argument('--external-bundle-dir',required=True);A.add_argument('--output-dir',required=True);a=A.parse_args();B=Path(a.bundle_dir);X=Path(a.external_bundle_dir);D=Path(a.output_dir);D.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.load((B/'manifest.json').open());checks={'matched_bundle_hashes':all(sha(B/k)==v for k,v in manifest['files'].items())};ext=json.load((X/'manifest.json').open());checks['external_bundle_hashes']=all(sha(X/k)==v for k,v in ext['files'].items());assert all(checks.values());sp=importlib.util.spec_from_file_location('frozen_math',X/'frozen_score_math.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);model=json.load((X/'model.json').open());src=json.load((X/'source_results.json').open());ref=json.load((B/'source_results.json').open());proto=json.load((B/'protocol.json').open());deltas={c:{} for c in proto['controls']};maxerr=0.;n_total=0
for si,s in enumerate(src['samples']):
 k=s['sample_ref'];meta=list(csv.DictReader(gzip.open(B/'metadata'/(k+'.csv.gz'),'rt')));bc=[z['barcode'] for z in meta]
 with np.load(X/'inputs'/(k+'.npz'),allow_pickle=False) as raw:
  pred,obs=m.transform(raw,model);checks[k+'_source_order']=list(raw['barcodes'].astype(str))==bc
 with np.load(X/'golden'/(k+'.npz'),allow_pickle=False) as g:checks[k+'_actual_inference_exact']=np.allclose(pred,g['predicted_atac_latent'],atol=1e-10,rtol=0) and np.allclose(obs,g['observed_atac_latent'],atol=1e-10,rtol=0)
 state=np.array([int(z['RNA_graph_state']) for z in meta]);rna=np.array([int(z['RNA_UMIs']) for z in meta]);atac=np.array([int(z['ATAC_fragments']) for z in meta]);n=len(bc);rb=np.searchsorted(np.quantile(np.log1p(rna),[1/3,2/3]),np.log1p(rna),side='right');ab=np.searchsorted(np.quantile(np.log1p(atac),[1/3,2/3]),np.log1p(atac),side='right');dep=rb*3+ab;joint=state*9+dep;counts={v:int(np.sum(joint==v)) for v in np.unique(joint)};idx=np.array([i for i in range(n) if counts[joint[i]]>=2]);n_total+=len(idx);mask=np.zeros(n,int);mask[idx]=1;checks[k+'_metadata_bins_eligibility']=np.array_equal(mask,[int(z['eligible']) for z in meta]) and len(idx)>=.9*n;pa=pred/np.linalg.norm(pred,axis=1)[:,None];oa=obs/np.linalg.norm(obs,axis=1)[:,None];native=np.einsum('ij,ij->i',pa[idx],oa[idx]).mean()
 for ci,c in enumerate(proto['controls']):
  lab=[np.zeros(n,int),state,dep,joint][ci];groups=[idx[lab[idx]==v] for v in sorted(set(lab[idx]))];means=[];valid=True
  for draw in range(100):
   rng=np.random.default_rng([20261111,si,ci,draw]);dest=np.arange(n)
   for group in groups:
    seq=rng.permutation(group)
    for j,cell in enumerate(seq):dest[cell]=seq[j-1]
   valid &= np.all(dest[idx]!=idx) and np.array_equal(np.sort(dest[idx]),idx) and np.array_equal(lab[dest[idx]],lab[idx]);means.append(float(np.einsum('ij,ij->i',pa[idx],oa[dest[idx]]).mean()))
  old=next(z for z in ref['samples'] if z['sample_ref']==k and z['control']==c);err=float(np.max(np.abs(np.array(means)-old['permutation_means'])));maxerr=max(maxerr,err);delta=float(native-np.mean(means));deltas[c].setdefault(s['subject_ref'],[]).append(delta);checks[k+'_'+c+'_100_actual_controls']=valid and err<1e-12 and abs(delta-old['delta'])<1e-12
def stat(a):
 a=np.array(a);assert len(a)==8;rr=np.random.default_rng(20261111);boot=a[rr.integers(0,8,size=(20000,8))].mean(1);p=sum(abs(np.dot(sign,a)/8)>=abs(a.mean())-1e-15 for sign in itertools.product([-1,1],repeat=8))/256;return float(a.mean()),np.quantile(boot,[.025,.975]),p
donors={c:{k:float(np.mean(v)) for k,v in sorted(x.items())} for c,x in deltas.items()};ps=[]
for c in proto['controls']:
 mean,ci,p=stat(list(donors[c].values()));old=ref['results'][c];ps.append(p);checks[c+'_donor_summary']=abs(mean-old['mean'])<1e-12 and np.allclose(ci,old['donor_bootstrap95CI'],atol=1e-12,rtol=0) and p==old['exact_two_sided_signflip_p']
rank=sorted(range(4),key=lambda j:ps[j]);running=0.
for i,j in enumerate(rank):running=max(running,min(1.,(4-i)*ps[j]));checks[proto['controls'][j]+'_Holm4']=running==ref['results'][proto['controls'][j]]['Holm4_p']
mean,ci,p=stat([donors[proto['controls'][0]][k]-donors[proto['controls'][-1]][k] for k in sorted(donors[proto['controls'][0]])]);old=ref['global_minus_state_depth_effect'];checks['paired_attenuation']=abs(mean-old['mean'])<1e-12 and np.allclose(ci,old['donor_bootstrap95CI'],atol=1e-12,rtol=0) and p==old['exact_two_sided_signflip_p'];checks['all10_libraries_70357_eligible']=len(src['samples'])==10 and n_total==70357;out={'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'max_permutation_mean_error':maxerr,'eligible_cells':n_total,'results':ref['results'],'scope':'Actual frozen-model inference and4000conditional derangement replays on public released derived arrays/metadata. Original rawH5binding separately independently verified. Already inspected cohort, post-hoc conditional sensitivity, not causal adjustment or independent confirmation.'};(D/'reproduction_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['checks','results']},indent=2));assert out['status']=='PASS'
