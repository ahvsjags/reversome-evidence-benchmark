#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 -m pip install --no-deps --upgrade --target software/site software/reversome-0.3.1rc7-py3-none-any.whl >/dev/null
python3 scripts/fetch_inputs.py
cp protocol/download_receipt_v1.json results/download_receipt_v1.json
python3 scripts/preflight_v1.py
python3 scripts/verify_preflight_v1.py
python3 scripts/score_primary_v1.py
python3 scripts/independent_recompute_v1.py
python3 scripts/build_decision_inputs.py
python3 scripts/run_contract_audit.py
PYTHONPATH="$ROOT/software/site" python3 -m reversome.planning.cli_v8 --input decision/planner_request_v1.json --protocol protocol/reversome_v8_milp_residual_cover.yaml --output decision/planner_result_v1.json --overwrite
python3 scripts/verify_public_case_v1.py
