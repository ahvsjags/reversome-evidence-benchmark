# Requirement/threshold origin and perturbation sensitivity

The source-membership cutoff0.85 was fitted on204source-disjoint calibration claims using603source-model fit claims. NLI0.7/0.2/0.1 are declared design constants, not independent expert-derived thresholds. Original values remain unchanged. The ledger binds each origin to its sourcehash.

All278existing public SciFact-Open outputs are retained;11frozen sensitivity configurations x3policies are reconstructed from archived actual neural outputs, not fresh inference. Source-score/document-binding destruction preserves the score distribution; omitted eligibility gate preserves the source-ranked order. Source annotation is incomplete, so benchmark-unverified sources are not independently proven scientifically false.

Run `python reproduce.py --bundle-dir THIS_FOLDER --output-dir NEW_EMPTY_OUTPUT`. Independent NumPy implementation reproduces331/331metrics/checks exactly. Includes only public IDs, model probabilities, source scores and official evidence labels; no abstract text, hospital or expert records.

Active ECAPF1 is0.1836066 at frozenprimary;0.1728045with extra source gate omitted and0.1162791with score/source binding destroyed. The tested margin changes have no effect because at relation>=0.7 normalized3class probabilities already imply pairwise margins>=0.4. They are not separate empirically effective safeguards. No primary threshold is retuned from this exposed benchmark. This does not replace independent human requirement specification/adjudication.
