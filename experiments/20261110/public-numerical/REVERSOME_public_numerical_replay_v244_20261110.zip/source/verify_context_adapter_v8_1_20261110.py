"""Independent source-label, route, statistical and model-selection verification."""
from pathlib import Path
import json,hashlib,pickle,datetime,importlib.util,math,collections
import numpy as np
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';B=E/'b3_frozen_context_adapter_v8_1_20261110';P=E/'b3_context_verifier_v7_20261110';S=E/'b3_frozen_context_adapter_v8_1_20261110.py';sp=importlib.util.spec_from_file_location('candidate',S);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);L=m.L;read=m.jl;sha=m.sha;rec=json.load((B/'results/policy_freeze_v8_1.json').open());fit=json.load((B/'results/fit_receipt_v8_1.json').open());proto=json.load((B/'protocol/protocol_v8_1.json').open());head=pickle.load((B/'models/domain_adapter_v8_1.pkl').open('rb'));train=read(P/'inputs/train.jsonl');cal=read(P/'inputs/calibration.jsonl');checks={'protocol_code_hash':sha(S)==proto['code_sha256']==rec['code_sha256']==fit['code_sha256'],'encoder_hash':sha(m.BASE/'model.safetensors')==proto['encoder_sha256']==fit['encoder_sha256'],'head_hash':sha(B/'models/domain_adapter_v8_1.pkl')==rec['head_sha256']==fit['head_sha256'],'training_input_hash':sha(P/'inputs/train.jsonl')==fit['train_sha256'],'training5974':len(train)==5974,'official_dev940':len(cal)==940,'head_C_point1':head.named_steps['logisticregression'].C==.1,'head_3by771':head.named_steps['logisticregression'].coef_.shape==(3,771),'optimizer_converged':bool(np.max(head.named_steps['logisticregression'].n_iter_)<1500)}
def metric(y,h):
 cm=np.zeros((3,3),int)
 for a,b in zip(y,h):cm[L.index(a),L.index(b)]+=1
 n=int(cm[:,0].sum());present=cm.sum(1)>0;return {'accuracy':float(cm.trace()/cm.sum()),'BA':float(np.mean(cm.diagonal()[present]/cm.sum(1)[present])),'FDR':float((n-cm[0,0])/n) if n else 1.,'retention':float(cm[0,0]/cm[0].sum()) if cm[0].sum() else None,'support_n':n,'false_support_n':int(n-cm[0,0]),'CM':cm.tolist()}
calpred=read(B/'results/calibration_predictions_v8_1.jsonl');truth={r['case_id']:r['label'] for r in cal};checks['calibration_keys_exact']=all(truth[r['case_id']]==r['label'] for r in calpred) and len(calpred)==len(truth);fixed={k:metric([truth[r['case_id']] for r in calpred],[r['states'][k]['label'] for r in calpred]) for k in ['fixed2','fixed6','fixed_full']};strong=max(fixed,key=lambda k:(fixed[k]['BA'],-['fixed2','fixed6','fixed_full'].index(k)));checks['calibration_strong_fixed_recomputes']=strong==rec['strong_fixed'];q=[]
for t in proto['thresholds']:
 selected=[r['states']['fixed2'] if max(r['states']['fixed2']['probabilities'])>=t else r['states']['fixed_full'] for r in calpred];mm=metric([r['label'] for r in calpred],[r['label'] for r in selected]);cost=sum(r['states']['fixed2']['tokens']**2+(0 if max(r['states']['fixed2']['probabilities'])>=t else r['states']['fixed_full']['tokens']**2) for r in calpred);base=fixed[strong];mm.update(threshold=t,proxy=cost,feasible=mm['BA']>=base['BA']-1e-12 and mm['FDR']<=base['FDR']+1e-12 and mm['retention']>=base['retention']-1e-12);q.append(mm)
feasible=[x for x in q if x['feasible']];best=max(feasible,key=lambda x:(x['BA'],-x['proxy'])) if feasible else None;basecost=sum(r['states'][strong]['tokens']**2 for r in calpred)
if best and best['BA']<=fixed[strong]['BA']+1e-12 and best['proxy']>=basecost:best=None
checks['calibration_policy_and_fallback_recompute']=(best is None)==rec['fallback'] and (best is None or best['threshold']==rec['selected']['threshold'])
# Verify extraction represents the original pretrained sequence-classifier output.
enc=m.Encoder();enc.head=head;enc.mode=rec['decoder'];sample=train[:3];X,_,_=enc.embed(sample);texts=[enc.text(r)[0] for r in sample];tokens=enc.tok(texts,[r['claim'] for r in sample],truncation=True,max_length=384,padding=True,return_tensors='pt')
with enc.torch.inference_mode():direct=enc.model(**tokens).logits.numpy()
checks['manual_encoder_logits_match_original_classifier']=bool(np.allclose(X[:,-3:],direct,atol=1e-6,rtol=0))
# Independent recomputation of the global head choice from all940 full dev contexts.
native=[];adapted=[]
for i in range(0,len(cal),16):
 X,_,_=enc.embed(cal[i:i+16]);native.extend(L[int(j)] for j in X[:,-3:].argmax(1));adapted.extend(head.predict(X).tolist())
ym=[r['label'] for r in cal];dm={'native':metric(ym,native),'adapted':metric(ym,adapted)};chosen=max(['native','adapted'],key=lambda k:dm[k]['BA']);checks['global_decoder_choice_official_dev_only_recomputes']=chosen==rec['decoder'];norm=lambda s:' '.join(s.lower().split());oldclaims={norm(r['claim']) for r in train};oldcontexts={hashlib.sha256(' '.join(' '.join(r['sentences']).lower().split()).encode()).hexdigest() for r in train};results={}
for name in ['healthver_test','covidfact_test']:
 rows=read(B/'results'/f'{name}_predictions_v8_1.jsonl');inputs={r['case_id']:r for r in read(P/'inputs'/f'{name}_label_free.jsonl')};keys={r['case_id']:r for r in read(P/'keys'/f'{name}.jsonl')};score=json.load((B/'results'/f'{name}_score_v8_1.json').open());freeze=json.load((B/'results'/f'{name}_prediction_freeze_v8_1.json').open());checks[name+'_all_cases']=len(rows)==len(inputs)==len(keys)==len({r['case_id'] for r in rows});checks[name+'_hash']=sha(B/'results'/f'{name}_predictions_v8_1.jsonl')==freeze['prediction_sha256']==score['prediction_sha256'];checks[name+'_policy_frozen_before_prediction']=rec['created_utc']<freeze['created_utc'];checks[name+'_no_exact_train_claim_overlap']=not any(norm(r['claim']) in oldclaims for r in inputs.values());y=[keys[r['case_id']]['label'] for r in rows];mets={}
 for policy in m.POL:
  met=metric(y,[r['routes'][policy]['label'] for r in rows]);mets[policy]=met
  for k,v in met.items():checks[name+'_'+policy+'_'+k]=(score['metrics'][policy][k]==v) if v is None or isinstance(v,(int,list)) else math.isclose(v,score['metrics'][policy][k],abs_tol=1e-12)
  checks[name+'_'+policy+'_costs_sum']=all(math.isclose(score['metrics'][policy][k],sum(r['routes'][policy][k] for r in rows),abs_tol=1e-9) for k in ['wall_seconds','CPU_seconds','tokens','neural_calls']);traceok=True;inputsok=True;stopok=True
  for r in rows:
   case=inputs[r['case_id']];z=r['routes'][policy];tr=z['trace'];traceok &= len(tr)==z['neural_calls'] and sum(t['tokens'] for t in tr)==z['tokens'] and z['label']==tr[-1]['label']
   for t in tr:traceok &= L[int(np.argmax(t['probabilities']))]==t['label'] and math.isclose(sum(t['probabilities']),1,abs_tol=1e-6) and t['decoder']==rec['decoder']
   if policy.startswith('fixed') or rec['fallback']:
    mode=policy if policy.startswith('fixed') else rec['strong_fixed'];n=2 if mode=='fixed2' else 6 if mode=='fixed6' else None;expected=enc.text(case,n)[1];inputsok &= len(tr)==1 and tr[0]['sentence_indices']==expected
   else:
    first=enc.text(case,2,policy=='random_active')[1];inputsok &= tr[0]['sentence_indices']==first;expand=max(tr[0]['probabilities'])<rec['selected']['threshold'];stopok &= len(tr)==(2 if expand else 1)
    if expand:inputsok &= tr[1]['sentence_indices']==list(range(len(case['sentences'])))
  checks[name+'_'+policy+'_trace_labels']=bool(traceok);checks[name+'_'+policy+'_actual_source_inputs']=bool(inputsok);checks[name+'_'+policy+'_frozen_stopping_rule']=bool(stopok)
 groups={}
 for i,r in enumerate(rows):groups.setdefault(r['claim_group'],[]).append(i)
 groups=list(groups.values());mat=np.array([[np.mean([rows[i]['routes'][p]['label']==y[i] for i in ix]) for p in m.POL] for ix in groups]);rng=np.random.default_rng(20261110);boot=np.array([mat[rng.integers(0,len(groups),len(groups))].mean(0) for _ in range(2000)]);ci={p:np.quantile(boot[:,3]-boot[:,j],[.025,.975]).tolist() for j,p in enumerate(m.POL) if p!='active'};checks[name+'_claim_cluster_CIs']=all(np.allclose(ci[k],score['paired_claim_accuracy_difference95CI'][k],atol=1e-12,rtol=0) for k in ci)
 strata={}
 for seen in [False,True]:
  ix=[i for i,r in enumerate(rows) if (hashlib.sha256(' '.join(' '.join(inputs[r['case_id']]['sentences']).lower().split()).encode()).hexdigest() in oldcontexts)==seen];strata['source_seen' if seen else 'source_unseen']={'pairs':len(ix),'claims':len({rows[i]['claim_group'] for i in ix}),'metrics':{p:metric([y[i] for i in ix],[rows[i]['routes'][p]['label'] for i in ix]) for p in m.POL} if ix else None}
 trunc=sum(len(enc.tok(' '.join(c['sentences']),c['claim'],truncation=False)['input_ids'])>384 for c in inputs.values());results[name]={'all_pair_metrics':mets,'source_overlap_strata_all_retained':strata,'full_input_pairs_truncated_at384':trunc,'truncation_note':'fixed_full receives full context input but shares max384 encoder limit; ranked partial inputs can select a different subset. fixed6 is retained as a stronger fixed retrieval-budget comparator.','source_pairs':len(rows),'natural_claims':len(groups),'claim_CIs':ci}
out={'schema':'REVERSOME.B3.ContextAdapterIndependentAudit.v8.1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(v) for v in checks.values()),'total':len(checks),'checks':{k:bool(v) for k,v in checks.items()},'calibration_head_recalculated_full_source_metrics':dm,'chosen_global_decoder':chosen,'test_results':results,'scope':'Independent computational code, original public labels, actual inputs/costs and official-dev-only selection. Not independent human evaluation or proof of improved researcher judgments.'}
with (B/'results/independent_verification_v8_1.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','test_results']},indent=2));assert all(checks.values())
