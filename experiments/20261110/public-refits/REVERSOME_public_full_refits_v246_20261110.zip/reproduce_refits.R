#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("usage: Rscript fit_full_qc_pairing_sensitivity_v3.R <public_training_rds> <output_dir> <golden_model_dir>")
input <- normalizePath(args[[1]], mustWork = TRUE)
out <- args[[2]]
golden <- normalizePath(args[[3]], mustWork = TRUE)
if (dir.exists(out)) stop("output directory already exists; refusing overwrite")
dir.create(out, recursive = TRUE)
suppressPackageStartupMessages({ library(Matrix); library(SeuratObject); library(jsonlite) })
seed <- 20260812L
n_features <- 64L
n_components <- 16L
ridge_alpha <- 1.0
bin_size <- 10000
obj <- readRDS(input)
rna <- obj@assays$RNA@counts
atac <- obj@assays$ATAC@counts
meta <- obj@meta.data
if (!inherits(rna,"sparseMatrix") || !inherits(atac,"sparseMatrix")) stop("RNA/ATAC counts must be sparse matrices")
if (!identical(colnames(rna),colnames(atac)) || !identical(colnames(rna),rownames(meta))) stop("RNA/ATAC/meta cell order mismatch")
if (!all(c("Sample","nFeature_RNA","nFeature_ATAC") %in% colnames(meta))) stop("required metadata fields missing")
if (!all(c("CellType","wsnn_res.0.8") %in% colnames(meta))) stop("frozen cell-type/state metadata fields missing")
sample_id <- as.character(meta$Sample)
samples <- sort(unique(sample_id))
if (length(samples) != 16L) stop("expected16 released public assay/specimen-pool codes")
qc <- is.finite(meta$nFeature_RNA) & is.finite(meta$nFeature_ATAC) & meta$nFeature_RNA >= 20L & meta$nFeature_ATAC >= 20L
eligible <- which(qc)
if (length(eligible) < 32000L) stop("full-QC set smaller than the frozen paired subset")
sampled <- data.frame(
  paired_cell_id=colnames(rna)[eligible],
  barcode=sub("^[^_]+_", "", colnames(rna)[eligible]),
  specimen=sample_id[eligible],
  cell_type=as.character(meta$CellType[eligible]),
  nfeature_rna=as.numeric(meta$nFeature_RNA[eligible]),
  nfeature_atac=as.numeric(meta$nFeature_ATAC[eligible]),
  source_accession="GSE241468",
  pair_evidence="same_released_10x_multiome_barcode",
  state_wsnn_res_0_8=as.character(meta$wsnn_res.0.8[eligible]),
  stringsAsFactors=FALSE
)
if (anyNA(sampled$specimen) || anyNA(sampled$cell_type) || anyNA(sampled$state_wsnn_res_0_8)) stop("missing sample/type/state; do not silently discard eligible cells")
if (anyDuplicated(sampled$paired_cell_id) || any(sampled$pair_evidence != "same_released_10x_multiome_barcode")) stop("full-QC pairing manifest identity check failed")
cell_idx <- match(sampled$paired_cell_id,colnames(rna))
if (anyNA(cell_idx) || anyDuplicated(cell_idx)) stop("manifest cell IDs are missing or duplicated")
sampled$specimen <- as.character(sampled$specimen)
paired_path <- file.path(out,"full_qc_eligible_paired_cell_manifest_v3.csv")
write.csv(sampled,paired_path,row.names=FALSE)
manifest_receipt <- list(schema="REVERSOME.GSE241468.FullQCManifestReceipt.v3",rows=nrow(sampled),specimens=length(samples),sample_counts=as.list(table(factor(sampled$specimen,levels=samples))),qc_rule="finite nFeature_RNA and nFeature_ATAC; both >=20; all such cells included, no random subsampling or cap",pairing="same cell columns in RNA and ATAC assays; same released 10x multiome barcode",source_accession="GSE241468")
write_json(manifest_receipt,file.path(out,"full_qc_manifest_receipt_v3.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
chosen <- lapply(samples,function(s) cell_idx[sampled$specimen==s])
names(chosen) <- samples
if (any(vapply(chosen,length,integer(1)) < 100L)) stop("registered specimen below 100 cells")
peak_to_bin <- function(value) {
  m <- regmatches(value,regexec("^([^:]+):([0-9]+)-([0-9]+)$",value))[[1]]
  if (length(m)!=4L) m <- regmatches(value,regexec("^([^-]+)-([0-9]+)-([0-9]+)$",value))[[1]]
  if (length(m)!=4L) return(NA_character_)
  midpoint <- (as.numeric(m[[3]])+as.numeric(m[[4]]))/2
  paste0(m[[2]],"-",floor(midpoint/bin_size)*bin_size)
}
peak_bins <- vapply(rownames(atac),peak_to_bin,character(1))
if (mean(!is.na(peak_bins)) < 0.99) stop("fewer than 99% of training peaks map to 10-kb bins")
row_cosine <- function(a,b) { num <- rowSums(a*b); den <- sqrt(rowSums(a*a))*sqrt(rowSums(b*b)); num/pmax(den,1e-8) }
top1_retrieval <- function(pred,target) {
  a <- pred/pmax(sqrt(rowSums(pred*pred)),1e-8); b <- target/pmax(sqrt(rowSums(target*target)),1e-8)
  mean(max.col(a%*%t(b),ties.method="first")==seq_len(nrow(a)))
}
stratified_derangement <- function(indices,strata,seed_value) {
  set.seed(seed_value); out <- indices; groups <- split(seq_along(indices),as.character(strata))
  for (j in seq_along(groups)) { pos <- groups[[j]]; if(length(pos)>1L) { shift <- sample.int(length(pos)-1L,1L); src <- c((shift+1L):length(pos),seq_len(shift)); out[pos] <- indices[pos[src]] } }
  out
}
select_features <- function(train_cells) {
  gs <- Matrix::rowSums(rna[,train_cells,drop=FALSE])
  gi <- order(-as.numeric(gs),rownames(rna),method="radix")[seq_len(n_features)]
  ps <- Matrix::rowSums(atac[,train_cells,drop=FALSE])
  valid <- !is.na(peak_bins)
  bs <- tapply(ps[valid],peak_bins[valid],sum)
  bi <- order(-as.numeric(bs),names(bs),method="radix")[seq_len(n_features)]
  bins <- names(bs)[bi]
  br <- lapply(bins,function(b) which(peak_bins==b))
  if(any(vapply(br,length,integer(1))==0L)) stop("selected ATAC bin has no peaks")
  list(gene_rows=gi,bins=bins,bin_rows=br)
}
build_features <- function(cells,feat) {
  rt <- as.numeric(Matrix::colSums(rna[,cells,drop=FALSE]))
  at <- as.numeric(Matrix::colSums(atac[,cells,drop=FALSE]))
  x <- as.matrix(t(rna[feat$gene_rows,cells,drop=FALSE]))
  x <- log1p(sweep(x,1,pmax(rt,1),"/")*10000)
  # Disjoint10-kb bin indicator; sums exactly the same nonnegative integer counts.
  A <- Matrix::sparseMatrix(i=rep(seq_along(feat$bin_rows),lengths(feat$bin_rows)),j=unlist(feat$bin_rows,use.names=FALSE),x=1,dims=c(length(feat$bin_rows),nrow(atac)))
  y <- as.matrix(t(A %*% atac[,cells,drop=FALSE]))
  y <- log1p(sweep(y,1,pmax(at,1),"/")*10000)
  list(rna=x,atac=y)
}
fit_scaler <- function(x) {
  center <- colMeans(x); scale <- apply(x,2,sd)
  scale[!is.finite(scale)|scale<1e-8] <- 1
  list(center=center,scale=scale)
}
apply_scaler <- function(x,f) sweep(sweep(x,2,f$center,"-"),2,f$scale,"/")
fit_pca <- function(x) {
  p <- prcomp(x,center=FALSE,scale.=FALSE,rank.=n_components)
  list(train=p$x[,seq_len(n_components),drop=FALSE],rotation=p$rotation[,seq_len(n_components),drop=FALSE])
}

repeats <- as.integer(Sys.getenv("REV_REPEATS","20"))
if (!(repeats %in% c(2L,20L))) stop("frozen repeat counts are2 smoke or20 full")
set.seed(20261110L)
split_sets <- list(); seen <- character()
while(length(split_sets)<20L) {
 a <- sort(sample(samples,8L)); b <- setdiff(samples,a); key <- paste(a,collapse=";"); keyb <- paste(b,collapse=";")
 if(key %in% seen || keyb %in% seen) next
 split_sets[[length(split_sets)+1L]] <- a; split_sets[[length(split_sets)+1L]] <- b; seen <- c(seen,key,keyb)
}
split_sets <- split_sets[seq_len(repeats)]
held_counts <- table(unlist(lapply(split_sets,function(a)setdiff(samples,a))))
if(length(held_counts)!=16L || any(held_counts!=repeats/2)) stop("unbalanced heldout release_unit coverage")
summary_rows <- list(); vector_paths <- character(); model_paths <- character()
for(si in seq_along(split_sets)) {
 train_samples <- split_sets[[si]]; test_samples <- setdiff(samples,train_samples)
 if(length(intersect(train_samples,test_samples)) || length(train_samples)!=8L || length(test_samples)!=8L) stop("invalid release_unit split")
 tr <- unlist(chosen[train_samples],use.names=FALSE); te <- unlist(chosen[test_samples],use.names=FALSE)
 feat <- select_features(tr); tv <- build_features(tr,feat); ev <- build_features(te,feat)
 xf <- fit_scaler(tv$rna); yf <- fit_scaler(tv$atac)
 xt <- apply_scaler(tv$rna,xf); yt <- apply_scaler(tv$atac,yf); xe <- apply_scaler(ev$rna,xf); ye <- apply_scaler(ev$atac,yf)
 xp <- fit_pca(xt); yp <- fit_pca(yt)
 beta <- solve(crossprod(xp$train)+ridge_alpha*diag(n_components),crossprod(xp$train,yp$train))
 predicted <- xe%*%xp$rotation%*%beta; target <- ye%*%yp$rotation
 native <- row_cosine(predicted,target)
 trmeta <- sampled[match(colnames(rna)[tr],sampled$paired_cell_id),,drop=FALSE]; temeta <- sampled[match(colnames(rna)[te],sampled$paired_cell_id),,drop=FALSE]
 if(anyNA(trmeta$paired_cell_id)||anyNA(temeta$paired_cell_id))stop("metadata join")
 strata <- paste(trmeta$specimen,trmeta$cell_type,trmeta$state_wsnn_res_0_8,sep="::")
 vectors <- list(); betas <- list()
 for(k in seq_len(5L)) {
  ps <- 20261110L+si*1000L+k; perm <- stratified_derangement(seq_len(nrow(yp$train)),strata,ps)
  if(any(strata[perm]!=strata)||!identical(sort(perm),seq_along(perm))||mean(perm!=seq_along(perm))<.995) stop("invalid pairing control")
  bb <- solve(crossprod(xp$train)+ridge_alpha*diag(n_components),crossprod(xp$train,yp$train[perm,,drop=FALSE]));betas[[k]]<-bb
  broken <- row_cosine(xe%*%xp$rotation%*%bb,target)
  vectors[[k]] <- data.frame(split=si,seed=ps,release_unit=temeta$specimen,paired_cell_id=temeta$paired_cell_id,native_cosine=native,broken_cosine=broken,delta=native-broken,stringsAsFactors=FALSE)
  for(d in test_samples) { ix<-which(temeta$specimen==d);summary_rows[[length(summary_rows)+1L]]<-data.frame(split=si,seed=ps,heldout_release_unit=d,training_release_units=paste(train_samples,collapse=";"),n_test_cells=length(ix),native_cosine=mean(native[ix]),broken_cosine=mean(broken[ix]),delta=mean(native[ix]-broken[ix]),pair_break_fraction=mean(perm!=seq_along(perm)),stringsAsFactors=FALSE) }
 }
 vp<-file.path(out,sprintf("split_%02d_per_cell.csv.gz",si)); con<-gzfile(vp,"wt");write.csv(do.call(rbind,vectors),con,row.names=FALSE);close(con);vector_paths<-c(vector_paths,vp)
 mp<-file.path(out,sprintf("split_%02d_refitted_models.rds",si));saveRDS(list(train_release_units=train_samples,heldout_release_units=test_samples,features=feat,rna_scaler=xf,atac_scaler=yf,rna_rotation=xp$rotation,atac_rotation=yp$rotation,native_beta=beta,broken_betas=betas),mp);model_paths<-c(model_paths,mp)
 cat("REFIT_SPLIT",si,"/",repeats,"training8 heldout8 all fullQC cells\n");flush.console()
 if(si<=2L) {
  previous <- readRDS(file.path(golden,sprintf("split_%02d_refitted_models.rds",si)))
  # Legacy checkpoint field names are compatibility aliases for released
  # assay/pool units. They do not establish independent individual donors.
  if(!identical(previous$train_donors,train_samples) || !identical(previous$heldout_donors,test_samples)) stop("golden split unit identity mismatch")
  feature_equal <- identical(previous$features,feat)
  scale_equal <- isTRUE(all.equal(previous$rna_scaler,xf,tolerance=1e-12,check.attributes=FALSE)) && isTRUE(all.equal(previous$atac_scaler,yf,tolerance=1e-12,check.attributes=FALSE))
  if(!feature_equal||!scale_equal) stop("frozen training feature/scaler mismatch")
  ref_target <- ye %*% previous$atac_rotation
  ref_native <- row_cosine(xe %*% previous$rna_rotation %*% previous$native_beta,ref_target)
  err <- max(abs(native-ref_native))
  for(k in seq_len(5L)) {
   ref_broken <- row_cosine(xe %*% previous$rna_rotation %*% previous$broken_betas[[k]],ref_target)
   err <- max(err,max(abs(vectors[[k]]$native_cosine-ref_native)),max(abs(vectors[[k]]$broken_cosine-ref_broken)),max(abs(vectors[[k]]$delta-(ref_native-ref_broken))))
  }
  if(!is.finite(err)||err>1e-10) stop("golden model prediction tolerance failed")
  write_json(list(status="PASS",split=si,max_abs_per_cell_difference=err,feature_selection_exact=feature_equal,scalers_equal=scale_equal,source="Public golden checkpoint, never a server-private prediction file"),file.path(out,sprintf("public_golden_equivalence_split_%02d.json",si)),auto_unbox=TRUE,pretty=TRUE,digits=NA)
  cat("PUBLIC_GOLDEN_MODEL_EQUIVALENCE_PASS",si,"max_error",err,"\n");flush.console()
 }


}
result<-do.call(rbind,summary_rows);write.csv(result,file.path(out,"repeated_refit_release_unit_results.csv"),row.names=FALSE)
split_effect<-aggregate(delta~split,result,mean)$delta
se_corrected<-sqrt((1/length(split_effect)+1)*var(split_effect));mu<-mean(split_effect);crit<-qt(.975,df=length(split_effect)-1)
stats<-list(schema="REVERSOME.GSE241468.RepeatedRefitSensitivity.v1",status="REFITTED_PENDING_INDEPENDENT_CHECK",split_n=repeats,training_release_units=8,heldout_release_units=8,unique_release_units=16,each_release_unit_heldout=repeats/2,pairing_seeds_per_split=5,mean_delta=mu,corrected_repeated_holdout_95CI=c(mu-crit*se_corrected,mu+crit*se_corrected),corrected_t_p=if(se_corrected>0)2*pt(-abs(mu/se_corrected),df=repeats-1)else 1,variance_formula="(1/repeats+n_test/n_train)*sample_variance(split mean effects); ratio1 for8/8 splits",source="GSE241468 public data",unit="released Sample-coded assay/specimen-pool unit",independent_individual_donor_count_established=FALSE,refit_feature_selection_scaling_PCA_ridge_each_split=TRUE,all_fullQC_cells=TRUE,model_refit=TRUE,per_cell_paths=vector_paths,model_paths=model_paths,scope="Secondary repeated-release_unit-holdout sensitivity; 8-release_unit training differs from original15-release_unit LOSO. Original primary test unchanged; no claim of Agent efficacy or untouched external confirmation.")
write_json(stats,file.path(out,"repeated_refit_summary.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
