import sys,unittest,tempfile,json,hashlib,shutil,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import aggregate_release_validator as v

def packet():
 return {'schema':v.SCHEMA,'release_id':'AGG.v1','scope':{'dataset_class':'controlled_aggregate_only','raw_data_included':False,'source_accession':'PUBLIC.1','endpoint_code':'ENDPOINT.1','analysis_version':'A.1'},'privacy_policy':{'minimum_cell_size':5,'suppression_rule':'suppress_all_values_when_n_below_minimum'},'provenance':{'analysis_code_manifest_sha256':'a'*64,'environment_lock_sha256':'b'*64,'run_timestamp_utc':'2026-11-01T00:00:00Z','producer_role':'authorized_data_custodian'},'summary_rows':[{'metric_code':'M1','group_code':'G1','n':12,'suppressed':False,'estimate':0.75,'ci_lower':0.50,'ci_upper':0.90,'p_value':0.04,'denominator':20}]}
class Tests(unittest.TestCase):
 def bad(self,mut):
  d=packet();mut(d)
  with self.assertRaises(ValueError):v.validate(d)
 def test_valid(self):self.assertEqual(v.validate(packet())['reported'],1)
 def test_suppressed_low_n(self):
  d=packet();d['summary_rows']=[{'metric_code':'M1','group_code':'G1','n':None,'suppressed':True}];self.assertEqual(v.validate(d)['suppressed'],1)
 def test_unsuppressed_below_threshold(self):self.bad(lambda d:d['summary_rows'][0].update(n=4))
 def test_suppressed_estimate_leak(self):self.bad(lambda d:d['summary_rows'][0].update(n=None,suppressed=True))
 def test_forbidden_patient_id(self):self.bad(lambda d:d.update(patient_id='x'))
 def test_forbidden_nested_identifier(self):self.bad(lambda d:d['summary_rows'][0].update(subject_id='x'))
 def test_extra_top_field(self):self.bad(lambda d:d.update(notes='free text'))
 def test_duplicate_group_metric(self):self.bad(lambda d:d['summary_rows'].append(dict(d['summary_rows'][0])))
 def test_bad_interval(self):self.bad(lambda d:d['summary_rows'][0].update(ci_lower=.9,ci_upper=.2))
 def test_missing_interval_bound(self):self.bad(lambda d:d['summary_rows'][0].pop('ci_upper'))
 def test_bad_p(self):self.bad(lambda d:d['summary_rows'][0].update(p_value=1.1))
 def test_raw_included(self):self.bad(lambda d:d['scope'].update(raw_data_included=True))
 def test_threshold_required(self):self.bad(lambda d:d['privacy_policy'].update(minimum_cell_size=1))
 def test_wrong_role(self):self.bad(lambda d:d['provenance'].update(producer_role='analyst'))
 def test_non_utc_time(self):self.bad(lambda d:d['provenance'].update(run_timestamp_utc='2026-11-01'))
 def test_wrong_schema(self):self.bad(lambda d:d.update(schema='other'))
 def test_code_manifest_hash(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);(root/'code.py').write_text('x=1\n');h=hashlib.sha256((root/'code.py').read_bytes()).hexdigest();m=root/'m.json';m.write_text(json.dumps({'schema':'REVERSOME.CodeHashManifest.v1','files':[{'relative_path':'code.py','sha256':h}]}));self.assertEqual(v.code_manifest(m,root)['files'][0]['sha256'],h)
 def test_code_manifest_tamper(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);(root/'code.py').write_text('x=1\n');m=root/'m.json';m.write_text(json.dumps({'schema':'REVERSOME.CodeHashManifest.v1','files':[{'relative_path':'code.py','sha256':'a'*64}]}))
   with self.assertRaises(ValueError):v.code_manifest(m,root)
 def test_code_path_traversal(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t)/'root';root.mkdir();m=Path(t)/'m.json';m.write_text(json.dumps({'schema':'REVERSOME.CodeHashManifest.v1','files':[{'relative_path':'../outside','sha256':'a'*64}]}))
   with self.assertRaises(ValueError):v.code_manifest(m,root)
 def test_nonfinite_estimate(self):self.bad(lambda d:d['summary_rows'][0].update(estimate=float('nan')))
 def test_nonfinite_p(self):self.bad(lambda d:d['summary_rows'][0].update(p_value=float('inf')))
 def test_group_code_rejects_free_text(self):self.bad(lambda d:d['summary_rows'][0].update(group_code='patientA'))
 def test_cli_refuses_overwriting_aggregate(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);(root/'src').mkdir();code=Path(v.__file__);shutil.copy2(code,root/'src/validator.py');env=root/'env.json';env.write_text('{}');manifest=root/'manifest.json';h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();manifest.write_text(json.dumps({'schema':'REVERSOME.CodeHashManifest.v1','files':[{'relative_path':'validator.py','sha256':h(root/'src/validator.py')}]}));d=packet();d['provenance']['analysis_code_manifest_sha256']=h(manifest);d['provenance']['environment_lock_sha256']=h(env);agg=root/'aggregate.json';agg.write_text(json.dumps(d));before=h(agg);cmd=[sys.executable,str(root/'src/validator.py'),'--aggregate-json',str(agg),'--code-manifest',str(manifest),'--code-root',str(root/'src'),'--environment-lock',str(env),'--output',str(agg)];r=subprocess.run(cmd,capture_output=True,text=True);self.assertEqual(r.returncode,2);self.assertEqual(h(agg),before)
if __name__=='__main__':unittest.main(verbosity=2)
