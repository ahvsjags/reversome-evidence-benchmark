"""Frozen V6 acquisition policies on the entire official SciFact-Open corpus."""
from pathlib import Path
import json,hashlib,pickle,datetime,sys,time,importlib.util,re
import numpy as np
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
R=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation');E=R/'05_evidence_updates';B=E/'b3_scifact_open_locked_v1_20261110';V=E/'b3_incremental_sourceguard_v6_20261110';P=E/'b3_sourceheldout_utility_v3_20261110';sp=importlib.util.spec_from_file_location('v6',E/'b3_incremental_sourceguard_v6_20261110.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);POL=['fixed1','fixed3','fixed20','source_fixed_all','source_active']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for s in iter(lambda:f.read(1048576),b''):h.update(s)
 return h.hexdigest()
def put(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2)
def jl(p):return [json.loads(s) for s in Path(p).open() if s.strip()]
class OpenRuntime:
 def __init__(self):
  self.old=v.Lexical();self.nn=v.lib.Runtime();self.vec=self.old.vec;self.char=self.old.char
  self.docs=jl(B/'source/corpus.jsonl');self.ids=[str(d['doc_id']) for d in self.docs];self.index={d:i for i,d in enumerate(self.ids)};assert len(self.ids)==len(set(self.ids))
  self.X=self.vec.transform([d.get('title','')+' '+' '.join(d.get('abstract',[])) for d in self.docs]);self.sent={};print('OPEN_INDEX',len(self.ids),self.X.nnz,flush=True)
 def retrieve(self,claim):
  q=self.vec.transform([claim]);s=(self.X@q.T).toarray().ravel();idx=np.argpartition(-s,19)[:20];floor=float(s[idx].min());idx=np.flatnonzero(s>=floor);order=sorted(idx,key=lambda i:(-float(s[i]),self.ids[i]))[:20];out=[];features={};cq=self.char.transform([claim]);texts=[self.docs[i].get('title','')+' '+' '.join(self.docs[i].get('abstract',[])) for i in order];titles=[self.docs[i].get('title','') for i in order];cs=(self.char.transform(texts)@cq.T).toarray().ravel();ct=(self.char.transform(titles)@cq.T).toarray().ravel();ts=(self.vec.transform(titles)@q.T).toarray().ravel();words=set(re.findall(r'[a-z0-9]+',claim.lower()))-set(ENGLISH_STOP_WORDS);nums={x for x in words if any(c.isdigit() for c in x)};long={x for x in words if len(x)>=7};acronym={x.lower() for x in re.findall(r'\b[A-Z][A-Z0-9-]{1,}\b',claim)};cover=lambda a,b:len(a&b)/len(a) if a else 1.
  for rank,i in enumerate(order,1):
   ss=self.docs[i].get('abstract',[]) or [''];sx=self.vec.transform(ss);sim=(sx@q.T).toarray().ravel();tok=set(re.findall(r'[a-z0-9]+',texts[rank-1].lower()));title=set(re.findall(r'[a-z0-9]+',titles[rank-1].lower()));features[self.ids[i]]=np.array([s[i],ts[rank-1],cs[rank-1],ct[rank-1],s[i]/max(float(s[order[0]]),1e-12),1/rank,float(sim.max(initial=0)),float(sim.mean()),cover(words,tok),cover(words,title),cover(nums,tok),cover(long,tok),cover(acronym,tok),np.log1p(len(words)),np.log1p(len(tok))],float)
   clean=[x.strip() for x in self.docs[i].get('abstract',[]) if x.strip()]
   if not clean:continue
   scores=(self.vec.transform(clean)@q.T).toarray().ravel()
   for j in sorted(range(len(clean)),key=lambda j:(-float(scores[j]),j))[:2]:out.append({'doc_id':self.ids[i],'rank':rank,'sentence_index':j,'sentence':clean[j],'doc_cosine':float(s[i]),'sentence_cosine':float(scores[j])})
  return out,features
def live():
 protocol=json.load((B/'protocol/protocol_v1.json').open());assert sha(V/'models_v6.pkl')==protocol['models_frozen']['source_model'] and sha(P/'models/scifact_finetuned_v1/model.safetensors')==protocol['models_frozen']['NLI'];artifact=pickle.load((V/'models_v6.pkl').open('rb'));assert artifact['initial_depth']==1;put(B/'protocol/runner_freeze_v1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_sha256':sha(__file__),'policy_protocol_sha256':sha(B/'protocol/protocol_v1.json'),'input_freeze_sha256':sha(B/'protocol/input_freeze_v1.json'),'threshold':artifact['threshold'],'initial_depth':artifact['initial_depth'],'scoring_key_opened':False});run=OpenRuntime();rows=jl(B/'inputs/claims_label_free.jsonl');out=[]
 for i,r in enumerate(rows):
  routes={};order=POL[i%len(POL):]+POL[:i%len(POL)]
  for policy in order:
   wt=time.perf_counter();ct=time.process_time();c,fs=run.retrieve(r['claim']);retrieval_seconds=time.perf_counter()-wt;scores={}
   if policy.startswith('source_'):scores=dict(zip(fs,map(float,artifact['source_model'].predict_proba(np.stack(list(fs.values())))[:,1])))
   n=3 if policy=='fixed3' else 20 if policy=='fixed20' else 1;sc=run.nn.infer([x for x in c if x['rank']<=n],r['claim']);d=v.lib.decide(sc);trace=[{'action':'initial_fixed','depth':n,'doc_ids':sorted({x['doc_id'] for x in sc}),'NLI_pairs':len(sc),'label':d}]
   if policy=='source_fixed_all' or policy=='source_active' and d=='NOT_ENOUGH_INFO':
    extra=sorted({x['doc_id'] for x in c if x['rank']>n and scores[x['doc_id']]>=artifact['threshold']},key=lambda k:(-scores[k],k))
    for did in extra:
     xs=run.nn.infer([x for x in c if x['doc_id']==did],r['claim']);sc+=xs;d=v.lib.decide(sc);trace.append({'action':'source_aligned_check','doc_ids':[did],'NLI_pairs':len(xs),'label':d,'source_score':scores[did]})
     if policy=='source_active' and d!='NOT_ENOUGH_INFO':break
   routes[policy]={'label':d,'NLI_pairs':len(sc),'wall_seconds':time.perf_counter()-wt,'CPU_seconds':time.process_time()-ct,'retrieval_and_features_seconds':retrieval_seconds,'trace':trace,'scored_candidates':sc,'source_scores':scores}
  out.append({'case_id':r['case_id'],'execution_order':order,'routes':routes})
  if (i+1)%25==0:print('OPEN_LIVE',i+1,len(rows),flush=True)
 p=B/'results/predictions_v1.jsonl'
 with p.open('x') as f:
  for r in out:f.write(json.dumps(r)+'\n')
 put(B/'results/prediction_freeze_v1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prediction_sha256':sha(p),'n':len(out),'corpus_n':len(run.ids),'corpus_sha256':sha(B/'source/corpus.jsonl'),'test_keys_opened':False})
def selected_sources(route):
 out={}
 for did in sorted({r['doc_id'] for r in route['scored_candidates']}):
  label=v.lib.decide([x for x in route['scored_candidates'] if x['doc_id']==did])
  if label!='NOT_ENOUGH_INFO':out[did]=label
 return out
def statistics(rows,keys,policy):
 tp=predn=goldn=release=source_verified=strict_correct=0;calls=0;wall=cpu=0.
 for row in rows:
  key=keys[row['case_id']];gold=key['evidence'];z=row['routes'][policy];selected=selected_sources(z);tp+=sum(d in gold and gold[d]['label']==label for d,label in selected.items());predn+=len(selected);goldn+=len(gold);calls+=z['NLI_pairs'];wall+=z['wall_seconds'];cpu+=z['CPU_seconds'];d=z['label']
  if d!='NOT_ENOUGH_INFO':
   release+=1;source_verified+=any(label==d and did in gold and gold[did]['label']==d for did,label in selected.items());labels={a['label'] for a in gold.values()};strict_correct+=labels=={d}
 precision=tp/predn if predn else None;recall=tp/goldn if goldn else None
 return {'ECAP_TP':tp,'predicted_ECAPs':predn,'gold_ECAPs':goldn,'ECAP_precision':precision,'ECAP_recall':recall,'ECAP_F1':2*tp/(predn+goldn) if predn+goldn else None,'released_claims':release,'released_source_verified':source_verified,'released_source_unverified':release-source_verified,'release_source_precision':source_verified/release if release else None,'strict_global_release_correct':strict_correct,'strict_global_release_precision':strict_correct/release if release else None,'NLI_pairs':calls,'wall_seconds':wall,'CPU_seconds':cpu}
def score():
 rows=jl(B/'results/predictions_v1.jsonl');freeze=json.load((B/'results/prediction_freeze_v1.json').open());assert sha(B/'results/predictions_v1.jsonl')==freeze['prediction_sha256'];keys={str(r['id']):r for r in jl(B/'keys/claims_key.jsonl')};official_corpus_rows=sum(1 for line in (B/'source/corpus.jsonl').open() if line.strip());checks={'all_new_claims_retained':len(rows)==len(keys)==len({r['case_id'] for r in rows}),'complete_official_corpus':freeze['corpus_n']==official_corpus_rows};metrics={}
 for policy in POL:
  metrics[policy]=statistics(rows,keys,policy);checks[policy+'_trace']=all(sum(t['NLI_pairs'] for t in r['routes'][policy]['trace'])==r['routes'][policy]['NLI_pairs']==len(r['routes'][policy]['scored_candidates']) and v.lib.decide(r['routes'][policy]['scored_candidates'])==r['routes'][policy]['label'] for r in rows)
 rng=np.random.default_rng(20261110);boot={p:[] for p in POL if p!='source_active'}
 for _ in range(2000):
  sample=[rows[i] for i in rng.integers(0,len(rows),len(rows))];a=statistics(sample,keys,'source_active')['ECAP_F1']
  for pol in boot:boot[pol].append(a-statistics(sample,keys,pol)['ECAP_F1'])
 out={'schema':'REVERSOME.B3.SciFactOpenLockedResults.v1','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'claims':len(rows),'corpus_documents':freeze['corpus_n'],'metrics':metrics,'conditional_claim_bootstrap_ECAP_F1_difference95CI':{k:np.quantile(z,[.025,.975]).tolist() for k,z in boot.items()},'scope':'One locked public benchmark using exact-disjoint original-test claims. Published pooling evidence is incomplete; unannotated predicted sources are unverified under this benchmark, not proven scientifically false. No researcher-benefit or independent-study replication claim.'};put(B/'results/score_v1.json',out);print(json.dumps(out,indent=2));assert all(checks.values())
if __name__=='__main__':{'live':live,'score':score}[sys.argv[1]]()
