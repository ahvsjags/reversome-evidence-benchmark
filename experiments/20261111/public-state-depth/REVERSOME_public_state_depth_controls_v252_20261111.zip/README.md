# Frozen RNA-state/depth matched controls

Public GSE286182 only;10libraries/8donors,70357commoneligible cells of70400. All four controls use the same cells and100within-stratum no-self-target permutations. RNAgraph clusters are RNA-only CellRanger outputs, not expert cell types. The full GeneExpression H5column sums are used for RNAUMIs because the perbarcode CSVGEXfield was zero; unchanged targets, bins and frozen model. Source-binding correction and evidence hashes are retained in protocol and original verifier.

Obtain and verify the previous public frozen-model external bundle from immutable commit cfd2d73f937435f8b7ad60528373e79b79e2f95b, experiments/20261111/public-external/fetch_and_reproduce.py. This bundle reuses those exact derived inputs, executes frozen predictions anew and reconstructs4000controls and donor statistics.

Run: `python reproduce_state_depth_controls.py --bundle-dir THIS_FOLDER --external-bundle-dir EXTRACTED_PREVIOUS_EXTERNAL_BUNDLE --output-dir NEW_EMPTY_OUTPUT`

The RNA-state+depth conditional effect is0.00247518,95%donorbootstrapCI0.00118067–0.00387791; exacttwo-sided donor signflipP0.015625,Holm4P0.03125. The same-eligible global effect is0.01969909. Conditioning substantially attenuates the result; it is not causal adjustment, a training-side pairing experiment or a new independent cohort.

Only public derived cell barcodes/metadata, code and aggregate proofs are included. No hospital/expert/clinical individual record is accessed or released. Original manuscript/figures remain untouched.
