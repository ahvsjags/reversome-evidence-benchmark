import json, pathlib, sys, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/"candidate"))
from requirements_guard_v4_2 import check
class GuardTest(unittest.TestCase):
 def test_all_non_authorizing(self):
  for line in open(pathlib.Path(__file__).resolve().parents[1]/"inputs/cases.jsonl"):
   r=check(json.loads(line)); self.assertFalse(r["release_authorized"])
 def test_bad_bundle_fails_closed(self):
  self.assertFalse(check({"case_id":"x","bundle":None})["release_authorized"])
 def test_empty_req_fails_closed(self):
  self.assertFalse(check({"case_id":"x","bundle":{"claim_id":"x","requirements":[]}})["release_authorized"])
if __name__=="__main__":unittest.main()
