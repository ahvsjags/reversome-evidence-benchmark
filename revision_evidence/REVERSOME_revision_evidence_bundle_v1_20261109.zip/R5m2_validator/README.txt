REVERSOME R5.m2 aggregate-output release validator

Purpose: independently verify the structure and byte hashes of a custodian-prepared aggregate-only JSON, its code-file manifest, and an environment-lock file. The program reads only those explicitly supplied files. It does not inspect individual-level records or establish institutional authorization, ethics compliance, privacy compliance, scientific truth, or data provenance.

The included TESTFIXTURE_ONLY files are generated solely to exercise the CLI. They are not observed study data, not hospital results, and not suitable for manuscript reporting.

Run:
python src/aggregate_release_validator.py --aggregate-json PACKET.json --code-manifest CODE_MANIFEST.json --code-root CODE_ROOT --environment-lock ENVIRONMENT_LOCK.json --output RECEIPT.json

A future custodian-run package must be built from an authorized aggregate-only export and must preserve the exact source, suppression policy, code commit, and locked environment. No actual aggregate export is bundled here; no R5.m2 or G0/B7 gate is closed by this tool.
