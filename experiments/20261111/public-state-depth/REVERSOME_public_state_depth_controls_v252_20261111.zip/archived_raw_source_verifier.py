"""Separately implemented reconstruction; public sources only, no model refit."""
from pathlib import Path
import json,csv,gzip,hashlib,itertools,datetime
import numpy as np
import h5py
E=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation/05_evidence_updates');B=E/'b6_state_depth_control_v2_20261111';P=E/'b6_gse286182_full_cohort_raw_reprocess_v1_20261108/cellranger_full_cohort_v2_20261110'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 r=json.load((B/'results.json').open());proto=json.load((B/'protocol.json').open());src=json.load((P/'results/raw_reprocessed_frozen_score_v1.json').open());checks={};maxerr=0.;deltas={name:{} for name in proto['controls']};coverage=[]
 def check(k,x):checks[k]=bool(x)
 check('protocol_hash',r['protocol_sha256']==sha(B/'protocol.json'));check('original_score_hash',proto['source_score_sha256']==sha(P/'results/raw_reprocessed_frozen_score_v1.json'))
 for si,s in enumerate(src['samples']):
  k=s['sample_ref'];outs=P/'results/cellranger'/('GSE286182_'+k)/'outs';meta=list(csv.DictReader(gzip.open(B/'metadata'/(k+'.csv.gz'),'rt')));bc=[z['barcode'] for z in meta];need=set(bc);state=np.array([int(z['RNA_graph_state']) for z in meta]);rna=np.array([int(z['RNA_UMIs']) for z in meta]);atac=np.array([int(z['ATAC_fragments']) for z in meta]);n=len(bc)
  with np.load(s['prediction_npz'],allow_pickle=False) as z:
   a=z['predicted_atac_latent'].astype(float);b=z['observed_atac_latent'].astype(float);check(k+'_barcode_order',bc==list(z['barcodes'].astype(str)))
  # Independent CSC column-slice sums, no scipy sparse matrix implementation.
  with h5py.File(outs/'filtered_feature_bc_matrix.h5','r') as h:
   m=h['matrix'];hbc=[z.decode() for z in m['barcodes'][:]];pos={v:i for i,v in enumerate(hbc)};typ=np.array([z.decode()=='Gene Expression' for z in m['features']['feature_type'][:]]);ind=m['indices'][:];ip=m['indptr'][:];data=m['data'][:];tot=[]
   for x in bc:
    j=pos[x];lo,hi=ip[j:j+2];tot.append(data[lo:hi][typ[ind[lo:hi]]].sum())
  check(k+'_RNA_H5_direct_column_sums',np.array_equal(rna,tot))
  with (outs/'per_barcode_metrics.csv').open() as f:ad={z['barcode']:int(z['atac_fragments']) for z in csv.DictReader(f) if z['barcode'] in need}
  with (outs/'analysis/clustering/gex/graphclust/clusters.csv').open() as f:st={z['Barcode']:int(z['Cluster']) for z in csv.DictReader(f) if z['Barcode'] in need}
  check(k+'_ATAC_source_and_RNA_graph',all(atac[i]==ad[x] and state[i]==st[x] for i,x in enumerate(bc)))
  rb=np.searchsorted(np.quantile(np.log1p(rna),[1/3,2/3]),np.log1p(rna),side='right');ab=np.searchsorted(np.quantile(np.log1p(atac),[1/3,2/3]),np.log1p(atac),side='right');dep=rb*3+ab;joint=state*9+dep;counts={v:int(np.sum(joint==v)) for v in np.unique(joint)};idx=np.array([i for i in range(n) if counts[joint[i]]>=2]);ok=np.zeros(n,int);ok[idx]=1;coverage.append(len(idx)/n);check(k+'_common_eligibility',list(ok)==[int(z['eligible']) for z in meta] and np.array_equal(rb,[int(z['RNA_depth_bin']) for z in meta]) and np.array_equal(ab,[int(z['ATAC_depth_bin']) for z in meta]) and len(idx)>=.9*n)
  an=a/np.linalg.norm(a,axis=1)[:,None];bn=b/np.linalg.norm(b,axis=1)[:,None];native=np.einsum('ij,ij->i',an[idx],bn[idx]).mean()
  for ci,name in enumerate(proto['controls']):
   lab=[np.zeros(n,int),state,dep,joint][ci];groups=[idx[lab[idx]==v] for v in sorted(set(lab[idx]))];means=[];valid=True
   for draw in range(100):
    rng=np.random.default_rng([20261111,si,ci,draw]);dest=np.arange(n)
    for g in groups:
     seq=rng.permutation(g)
     for j,cell in enumerate(seq):dest[cell]=seq[j-1]
    valid &= np.all(dest[idx]!=idx) and np.array_equal(np.sort(dest[idx]),idx) and np.array_equal(lab[dest[idx]],lab[idx]);means.append(float(np.einsum('ij,ij->i',an[idx],bn[dest[idx]]).mean()))
   old=next(z for z in r['samples'] if z['sample_ref']==k and z['control']==name);err=float(np.max(np.abs(np.array(means)-old['permutation_means'])));maxerr=max(maxerr,err);delta=float(native-np.mean(means));deltas[name].setdefault(s['subject_ref'],[]).append(delta);check(k+'_'+name+'_all100_reconstructed',valid and err<=1e-12 and abs(delta-old['delta'])<=1e-12 and old['cells_eligible']==len(idx))
  prov=next(z for z in r['provenance'] if z['sample_ref']==k);check(k+'_all_source_hashes',all(sha(path)==prov[key] for path,key in [(Path(s['prediction_npz']),'prediction_sha256'),(outs/'filtered_feature_bc_matrix.h5','RNA_UMI_H5_source_sha256'),(outs/'per_barcode_metrics.csv','metrics_source_sha256'),(outs/'analysis/clustering/gex/graphclust/clusters.csv','cluster_source_sha256'),(B/'metadata'/(k+'.csv.gz'),'released_metadata_sha256')]))
  print('INDEPENDENT_MATCHED_CONTROL',k,flush=True)
 def stat(vals):
  a=np.array(vals,float);rng=np.random.default_rng(20261111);boot=a[rng.integers(0,8,size=(20000,8))].mean(1);p=sum(abs(np.dot(sign,a)/8)>=abs(a.mean())-1e-15 for sign in itertools.product([-1,1],repeat=8))/256;return float(a.mean()),np.quantile(boot,[.025,.975]),p
 ps=[];donor={name:{k:float(np.mean(v)) for k,v in sorted(x.items())} for name,x in deltas.items()}
 for name in proto['controls']:
  mean,ci,p=stat(list(donor[name].values()));old=r['results'][name];ps.append(p);check(name+'_8donor_stats',len(donor[name])==8 and abs(mean-old['mean'])<1e-12 and np.allclose(ci,old['donor_bootstrap95CI'],rtol=0,atol=1e-12) and p==old['exact_two_sided_signflip_p'])
 rank=sorted(range(4),key=lambda j:ps[j]);running=0.
 for i,j in enumerate(rank):running=max(running,min(1.,(4-i)*ps[j]));check(proto['controls'][j]+'_Holm',running==r['results'][proto['controls'][j]]['Holm4_p'])
 aa=[donor[proto['controls'][0]][k]-donor[proto['controls'][-1]][k] for k in sorted(donor[proto['controls'][0]])];m,c,p=stat(aa);old=r['global_minus_state_depth_effect'];check('paired_attenuation',abs(m-old['mean'])<1e-12 and np.allclose(c,old['donor_bootstrap95CI'],atol=1e-12,rtol=0) and p==old['exact_two_sided_signflip_p']);last=r['results'][proto['controls'][-1]];decision='RELEASE' if all(checks.values()) and last['donor_bootstrap95CI'][0]>0 and last['exact_two_sided_signflip_p']<=.05 else 'WITHHOLD';check('receipt_decision',decision==r['conditional_claim_decision']);out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'passed':sum(checks.values()),'total':len(checks),'max_permutation_mean_error':maxerr,'min_library_coverage':min(coverage),'eligible_total':sum(z['cells_eligible'] for z in r['samples'][::4]),'result_sha256':sha(B/'results.json'),'verifier_sha256':sha(Path(__file__)),'scientific_result':last,'scope':'Independent computational reconstruction, not independent human adjudication or a new cohort.'};(B/'independent_verification_v252.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2));assert out['status']=='PASS'
if __name__=='__main__':main()
