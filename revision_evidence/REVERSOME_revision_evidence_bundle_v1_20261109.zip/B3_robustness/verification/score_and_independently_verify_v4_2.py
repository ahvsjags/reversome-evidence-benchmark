import hashlib,json,pathlib,sys,collections,subprocess
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"candidate"))
from requirements_guard_v4_2 import check
def h(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
freeze=json.load(open(root/"protocol/freeze_v4_2.json"));cases=[json.loads(x) for x in open(root/"inputs/cases.jsonl")];labels={x["case_id"]:x for x in map(json.loads,open(root/"labels/labels.jsonl"))}
assert len(cases)==freeze["n_cases"]==len(labels)==120
assert h(root/"inputs/cases.jsonl")==freeze["input_sha256"]
assert h(root/"labels/labels.jsonl")==freeze["labels_sha256"]
assert h(root/"candidate/requirements_guard_v4_2.py")==freeze["candidate_sha256"]
preds=[check(c) for c in cases]
with open(root/"results/predictions_v4_2.jsonl","w") as f:
 for x in preds:f.write(json.dumps(x,sort_keys=True)+"\n")
# Independent metric recomputation from label/prediction tables; no candidate import in this block.
byid={x["case_id"]:x for x in preds};tp=fp=tn=fn=auth=0;fault_counts=collections.Counter();misses=[]
for cid,label in labels.items():
 p=byid[cid];flag=bool(p.get("issue_codes"));truth=bool(label["expected_issue"]);auth+=bool(p.get("release_authorized"))
 if truth and flag:tp+=1
 elif truth and not flag:fn+=1;misses.append({"case_id":cid,"defect":label["defect"]})
 elif not truth and flag:fp+=1;fault_counts.update(p.get("issue_codes",[]))
 else:tn+=1
controls=tn+fp;faults=tp+fn
sens=tp/faults if faults else None;spec=tn/controls if controls else None
status="PASS_STRUCTURED_ROBUSTNESS_TARGETS" if sens>=.95 and (1-spec)<=.05 and auth==0 else "FAIL_STRUCTURED_ROBUSTNESS_TARGETS"
report={"schema":"REVERSOME.B3.RequirementsRobustnessResult.v4_2","status":status,"scope":"Structured generated suite only; not natural-language expert labels, independent external cohort, or source-document verification.","n_cases":len(cases),"strata":{"controls":controls,"faults":faults},"confusion":{"tp":tp,"fn":fn,"tn":tn,"fp":fp},"fault_detection_sensitivity":sens,"control_specificity":spec,"release_authorized":auth,"misses":misses,"false_flag_issue_counts":dict(fault_counts),"hashes":{"input":h(root/"inputs/cases.jsonl"),"labels":h(root/"labels/labels.jsonl"),"candidate":h(root/"candidate/requirements_guard_v4_2.py"),"freeze":h(root/"protocol/freeze_v4_2.json"),"predictions":h(root/"results/predictions_v4_2.jsonl")},"criteria":freeze["acceptance_criteria"],"posthoc_note":freeze["development_note"]}
(root/"results/robustness_result_v4_2.json").write_text(json.dumps(report,indent=2)+"\n")
checks={"n_matches_freeze":len(cases)==freeze["n_cases"],"unique_case_ids":len({x["case_id"] for x in cases})==len(cases),"labels_cover_all_cases":set(labels)=={x["case_id"] for x in cases},"predictions_cover_all_cases":set(byid)==set(labels),"input_hash":h(root/"inputs/cases.jsonl")==freeze["input_sha256"],"label_hash":h(root/"labels/labels.jsonl")==freeze["labels_sha256"],"candidate_hash":h(root/"candidate/requirements_guard_v4_2.py")==freeze["candidate_sha256"],"sensitivity_target":sens>=.95,"specificity_target":spec>=.95,"zero_authorized_release":auth==0,"status_consistent":(status=="PASS_STRUCTURED_ROBUSTNESS_TARGETS")}
verify={"schema":"REVERSOME.B3.RequirementsRobustnessIndependentVerification.v4_2","status":"PASS" if all(checks.values()) else "FAIL","passed":sum(checks.values()),"total":len(checks),"checks":checks,"result_sha256":h(root/"results/robustness_result_v4_2.json"),"independence_scope":"Separate metric recomputation over frozen case labels and model predictions; not independent authorship or external expert adjudication."}
(root/"verification/independent_verification_v4_2.json").write_text(json.dumps(verify,indent=2)+"\n")
print(json.dumps({"status":status,"metrics":report["confusion"],"sensitivity":sens,"specificity":spec,"auth":auth,"verification":verify["status"],"passed":verify["passed"],"total":verify["total"]}))
