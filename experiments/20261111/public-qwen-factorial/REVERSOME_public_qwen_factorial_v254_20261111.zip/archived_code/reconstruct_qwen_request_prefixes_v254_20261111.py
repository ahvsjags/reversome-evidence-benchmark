"""Repair trace-only mutable-history aliases; never change inference or scores.

Exact pre-call prefixes are derived from ordered append-only conversation,
validated against recorded prompt-token counts with the same pinned GGUF engine.
Original records are retained unchanged. New files are explicitly reconstructed.
"""
from pathlib import Path
import json,copy,hashlib,datetime,urllib.request
from qwen30b_local_runtime_v252_20261111 import LocalModel,B
D=B/'matched';O=D/'request_prefix_reconstruction_v254';O.mkdir(exist_ok=False);(O/'rows').mkdir();files=[p for p in (D/'runs').glob('seed_*_shard_*/*.json') if p.name!='execution_receipt.json'];assert len(files)==160
checks={};records=[];changed=0;counter=0
def post(llm,endpoint,payload):
 req=urllib.request.Request(llm.base+endpoint,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60) as r:return json.load(r)
with LocalModel(O) as llm:
 for p in sorted(files):
  raw=json.load(p.open());row=copy.deepcopy(raw)
  for pol,z in row['routes'].items():
   stages={'planner':0,'judge':0}
   for i,rec in enumerate(z.get('LLM_request_responses',[])):
    stage='judge' if rec.get('stage')=='fresh_evidence_judge' else 'planner';turn=stages[stage];stages[stage]+=1;req=rec['request'];full=req['messages'];prefix_len=2+2*turn;key=f"{row['seed']}_{row['case_id']}_{pol}_{i}";checks[key+'_prefix_within_appendonly_history']=prefix_len<=len(full);assert checks[key+'_prefix_within_appendonly_history'];orig=hashlib.sha256(json.dumps(req,sort_keys=True).encode()).hexdigest()
    if stage=='planner':checks[key+'_response_matches_recorded_turn']=len(full)>prefix_len and full[prefix_len]['role']=='assistant' and json.loads(full[prefix_len]['content'])==json.loads(rec['response']['choices'][0]['message']['content'])
    elif len(full)>prefix_len:checks[key+'_judge_repair_matches_response']=full[prefix_len]['role']=='assistant' and json.loads(full[prefix_len]['content'])==json.loads(rec['response']['choices'][0]['message']['content'])
    req['messages']=full[:prefix_len];changed+=len(full)!=prefix_len;prompt=post(llm,'/apply-template',req)['prompt'];tokens=post(llm,'/tokenize',{'content':prompt,'add_special':True,'parse_special':True})['tokens'];expected=rec['response']['usage']['prompt_tokens'];checks[key+'_exact_recorded_prompt_token_count']=len(tokens)==expected;newhash=hashlib.sha256(json.dumps(req,sort_keys=True).encode()).hexdigest();rec['request_provenance']={'kind':'DERIVED_PRECALL_PREFIX_NOT_ORIGINAL_WIRE_CAPTURE','parent_raw_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original_aliased_request_sha256':orig,'reconstructed_request_sha256':newhash,'prefix_messages':prefix_len,'recorded_prompt_tokens':expected,'reconstructed_prompt_tokens':len(tokens),'token_sequence_sha256':hashlib.sha256(json.dumps(tokens).encode()).hexdigest()};records.append({'key':key,'recorded_prompt_tokens':expected,'reconstructed_prompt_tokens':len(tokens),'match':len(tokens)==expected});counter+=1
  row['request_trace_reconstruction']={'parent_raw_path':str(p),'parent_raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kind':'Derived exact pre-call prefixes; original files retained. No model generation, evidence, decisions or metrics changed.'};(O/'rows'/f"{row['seed']}_{row['case_id']}.json").write_text(json.dumps(row));print('PREFIX_CASE_VERIFIED',row['seed'],row['case_id'],flush=True)
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(checks.values()),'total':len(checks),'checks':checks,'rows':160,'requests':counter,'aliased_request_histories_reconstructed':changed,'token_count_checks':records,'owned_tokenizer_server_stopped':llm.proc.poll() is not None,'new_generation_calls':0,'scientific_outputs_modified':False,'original_trace_files_modified':False,'scope':'Trace logging alias bug: request.messages referenced the later-mutated history. Request prefixes are derived from append-only turn order and matched to original prompt-token counts with the same pinned GGUF/template engine. These are reconstructed requests, not original wire captures. Inference used serialized request bytes before each append and is unchanged.'};(O/'independent_reconstruction_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['checks','token_count_checks']},indent=2));assert out['status']=='PASS' and out['owned_tokenizer_server_stopped']
