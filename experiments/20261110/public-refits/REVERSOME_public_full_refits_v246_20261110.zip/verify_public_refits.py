from pathlib import Path
import csv,json,sys,gzip,collections,hashlib,math
import numpy as np
from scipy.stats import t
out=Path(sys.argv[1]);bundle=Path(sys.argv[2]);manifest=json.load((bundle/'MANIFEST.json').open());checks={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for r in manifest['files']:checks['hash:'+r['path']]=sha(bundle/r['path'])==r['sha256']
rows=list(csv.DictReader((out/'repeated_refit_release_unit_results.csv').open()));gold=list(csv.DictReader((bundle/'expected_release_unit_results.csv').open()));key=lambda r:(int(r['split']),int(r['seed']),r['heldout_release_unit']);expected={key(r):r for r in gold};checks['all800_unique_unit_seed_rows']=len(rows)==len({key(r) for r in rows})==len(expected)==800;err=0.
for row in rows:
 ref=expected[key(row)];checks['ids:'+str(key(row))]=row['training_release_units']==ref['training_release_units'] and int(row['n_test_cells'])==int(ref['n_test_cells'])
 for k in ['native_cosine','broken_cosine','delta','pair_break_fraction']:err=max(err,abs(float(row[k])-float(ref[k])))
checks['all_unit_summary_values_within1e10']=err<=1e-10
for split in range(1,21):
 agg=collections.defaultdict(lambda:np.zeros(4));count=0
 with gzip.open(out/f'split_{split:02d}_per_cell.csv.gz','rt') as f:
  for row in csv.DictReader(f):
   k=(int(row['split']),int(row['seed']),row['release_unit']);agg[k]+=np.array([1,float(row['native_cosine']),float(row['broken_cosine']),float(row['delta'])]);count+=1
 for k,v in agg.items():
  ref=expected[k];checks['percell:'+str(k)]=v[0]==int(ref['n_test_cells']) and np.max(np.abs(v[1:]/v[0]-[float(ref[x]) for x in ['native_cosine','broken_cosine','delta']]))<=1e-10
 checks[f'model:{split}']=(out/f'split_{split:02d}_refitted_models.rds').is_file()
 if split<=2:checks[f'golden_model_equivalence:{split}']=json.load((out/f'public_golden_equivalence_split_{split:02d}.json').open())['status']=='PASS'
x=np.array([np.mean([float(r['delta']) for r in rows if int(r['split'])==i]) for i in range(1,21)]);mu=float(x.mean());se=float(np.sqrt(1.05*np.var(x,ddof=1)));ci=[mu-t.ppf(.975,19)*se,mu+t.ppf(.975,19)*se];pv=float(2*t.sf(abs(mu/se),19));ref=json.load((bundle/'expected_summary.json').open());checks.update(mean=math.isclose(mu,ref['mean_delta'],abs_tol=1e-12),CI=bool(np.allclose(ci,ref['CI'],atol=1e-12,rtol=0)),p=math.isclose(pv,ref['p'],abs_tol=1e-12));res={'schema':'REVERSOME.PublicFullRefitReproduction.v1','status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(bool(x) for x in checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v],'max_unit_summary_difference':err,'mean_delta':mu,'CI':ci,'p':pv,'unit':'16 released assay/specimen-pool units, not16 established independent individual donors.','scope':'Full20 refits from public raw RDS; complete800row and all per-cell aggregation, model and first2 checkpoint equivalence tests.'};(out/'public_full_refit_reproduction_receipt.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2));assert all(checks.values())
