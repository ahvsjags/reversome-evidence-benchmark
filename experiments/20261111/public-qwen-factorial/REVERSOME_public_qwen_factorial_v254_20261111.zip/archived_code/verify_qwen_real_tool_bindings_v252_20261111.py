"""Gold-free independent claim/source/request binding audit of live tool traces."""
from pathlib import Path
import json,hashlib,datetime
E=Path('/ibex/project/c2378/xup0a/reversome_2_1_validation/05_evidence_updates');B=E/'review_gap_breakthrough_v252_20261111';D=B/'matched';claims={x['case_id']:x['claim'] for x in (json.loads(s) for s in (B/'benchmark/test_claims_label_free.jsonl').open())};assert json.load((D/'request_prefix_reconstruction_v254/independent_reconstruction_receipt.json').open())['status']=='PASS';paths=list((D/'request_prefix_reconstruction_v254/rows').glob('*.json'));rows=[json.load(p.open()) for p in paths];assert len(rows)==160;needed={d for r in rows for z in r['routes'].values() for d in z['read_document_ids']};corpus={}
for line in (E/'b3_scifact_open_locked_v1_20261110/source/corpus.jsonl').open():
 x=json.loads(line);did=str(x['doc_id'])
 if did in needed:corpus[did]=[s.strip() for s in x.get('abstract',[]) if s.strip()]
checks={'all160_actual_stochastic_case_runs':len(rows)==160,'all_inspected_sources_in_official_corpus':set(corpus)==needed};calls=tokens=0;toolpairs=0;example=None
def bound(z):return z['doc_id'] in corpus and 0<=z['sentence_index']<len(corpus[z['doc_id']]) and corpus[z['doc_id']][z['sentence_index']]==z['sentence']
for r in rows:
 key=str(r['seed'])+'_'+r['case_id'];checks[key+'_official_claim_binding']=r['claim']==claims[r['case_id']]
 for pol,z in r['routes'].items():
  xs=z['scored_candidates'];toolpairs+=len(xs);checks[key+'_'+pol+'_all_source_sentence_bindings']=all(bound(x) for x in xs)
  if xs and example is None:example=xs[0]
  for i,rec in enumerate(z.get('LLM_request_responses',[])):
   req=rec['request'];data=json.loads(req['messages'][1]['content']);checks[key+'_'+pol+f'_call{i}_claim_and_sampling']=data['claim']==r['claim'] and req['model']=='reversome-qwen3-30b-a3b-official-q4' and req['temperature']==.7 and req['top_p']==.8 and req['top_k']==20 and req['min_p']==0 and req['chat_template_kwargs']=={'enable_thinking':False};calls+=1;tokens+=rec['response']['usage']['completion_tokens']
   if rec.get('stage')=='fresh_evidence_judge':
    expected=[{'document_id':d,'sentences':[v['sentence'] for v in xs if v['doc_id']==d]} for d in z['read_document_ids']];checks[key+'_'+pol+f'_call{i}_fresh_judge_no_NLI_or_source_scores']=set(data)=={'claim','sources'} and data['sources']==expected and req['messages'][0]['content'].startswith('Judge each inspected scientific source independently')
assert example;badtext={**example,'sentence':example['sentence']+' ALTERED'};badindex={**example,'sentence_index':10**9};baddoc={**example,'doc_id':'NO_SUCH_OFFICIAL_SOURCE'};checks['negative_control_altered_source_text_detected']=not bound(badtext);checks['negative_control_wrong_sentence_index_detected']=not bound(badindex);checks['negative_control_wrong_source_detected']=not bound(baddoc);out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(checks.values()) else 'FAIL','passed':sum(checks.values()),'total':len(checks),'checks':checks,'actual_stochastic_case_runs':160,'distinct_official_sources_read':len(needed),'actual_recorded_LLM_requests':calls,'actual_recorded_completion_tokens':tokens,'actual_recorded_NLI_pairs':toolpairs,'corpus_sha256':hashlib.sha256((E/'b3_scifact_open_locked_v1_20261110/source/corpus.jsonl').read_bytes()).hexdigest(),'scope':'Gold-free reconstruction of claim/source/request provenance and fresh-judge isolation from actual traces; controlled integrity negative controls, not independent human scientific adjudication.'};(D/'independent_tool_binding_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2));assert out['status']=='PASS'
