# Source-unit sensitivity for the frozen SciFact-Open evaluation

278 claims map to 230 originating papers and 224 connected components, joining
claims sharing an originating paper or any annotated gold abstract. 5,000 draws
recompute component-clustered paired ECAP-F1 differences without changing a
scientific model or policy. 119 claims share at least one gold source with the
source-model fit/calibration cited-source sets; 159 have all annotated gold sources
unseen in these memberships. NLI evidence-training overlap is separately recorded.

On the 159-source-unseen-claim sensitivity subset, ECAP F1 is0.18243 fixed3,
0.21014 source-active, and0.23398 source-exhaustive. This subset was inspected
after the frozen test; it is robustness, not a second independent confirmation.
The clustered full-set active-minus-fixed3 interval still crosses zero.

Requires Python3.10+ and NumPy2.0.2. Download/unzip the sibling public-open-runtime
bundle at commit20803eb390fe8d06d5910cfe3e4accc0fcecd74a. Use the unchanged
official SciFact-Open archive, SHA256-pinned by the verifier. For example:

    python verify_source_units.py --audit-dir . --runtime-dir /path/public-open-runtime --archive /path/scifact_open.tar.gz

Gold annotations and originating-paper IDs are read from the original official
archive. Published model input source memberships are an author-derived metadata
artifact from the original public fit/calibration records, not human adjudication.
No claim/abstract text, patient data, or private expert records are redistributed.
The verifier does not run a new neural model. Original primary claim bootstrap
and full-set outputs remain retained; no independent-study claim is made.
